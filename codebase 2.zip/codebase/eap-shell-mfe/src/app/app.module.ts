import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastNotificationsModule } from 'ngx-toast-notifications';

import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { SharedComponentsModule } from '@hipeap/shared-components';
import { FormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { SharedSecurityModule, AuthTokenInterceptorService } from '@hipeap/shared-security';
import { BASE_PATH as SHARED_SERVICE_PATH, context, getConfiguration, ErrorInterceptor, LoaderInterceptorService } from '@hipeap/shared-state';
import { ConfigModule } from './config/config.module';
import { HeaderComponent } from './header/header.component';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { DemoExamplesComponent } from './demo-examples/demo-examples.component';

@NgModule({
  declarations: [AppComponent, HeaderComponent, DemoExamplesComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ConfigModule,
    SharedComponentsModule,
    NgIdleKeepaliveModule.forRoot(),
    MatDialogModule,
    ToastNotificationsModule.forRoot({ duration: 6000, position: 'bottom-center' }),
    SharedSecurityModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthTokenInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: SHARED_SERVICE_PATH, useValue: getConfiguration(context.sharedService) },
    { provide: MatDialogRef, useValue: {} },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
