import { ChangeDetectorRef, Component, Input, Renderer2, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Data, ActivatedRouteSnapshot, NavigationEnd, NavigationCancel } from '@angular/router';
import { SecurityService } from '@hipeap/shared-security';
import { filter, map, mergeMap,  } from 'rxjs/operators';
import { SubSink } from 'subsink';
import { CodeValues, CodesRouterService } from '@hipeap/shared-state';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, OnDestroy {
  private subs = new SubSink();
  @Input() showHeader: boolean;

  hideHeaderButtons: boolean = false;

  linkBtnClick: boolean = false;

  showLinks: boolean = false;

  links: CodeValues[];

  EXTERNAL_WEB_LINKS: string = 'externalWebLinks';

  constructor(
    private ref: ChangeDetectorRef,
    private renderer: Renderer2,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private securityService: SecurityService,
    private codeService: CodesRouterService
  ) {}

  ngOnInit(): void {
    this.getLinks();
    this.activatedRoute.queryParamMap.subscribe((paramMap) => {
      this.hideHeaderButtons = Boolean(paramMap.get('hideHeader')) || false;
      if(!this.hideHeaderButtons){
        this.hideHeaderButtons = Boolean(this.activatedRoute.snapshot.data['hideHeader']) || false;
      }
    });
    this.hideHeaderRouteEvent();
    this.listenToClickOutside();
  }

  private hideHeaderRouteEvent() {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd || event instanceof NavigationCancel),
        map(() => this.activatedRoute),
        map((route) => {
      while (route.firstChild)
        route = route.firstChild;
      return route;
    }), filter((route) => route.outlet === 'primary'), mergeMap((route) => route.data)).subscribe((data: Data) => {
      this.hideHeaderButtons = Boolean(data?.hideHeader) || false;
    });
  }

  logout(): void {
    this.securityService.logout();
    this.showHeader = false;
  }

  toggleLinksDropdownMenu(): void {
    this.showLinks = !this.showLinks;
  }

  preventCloseOnClick(): void {
    this.linkBtnClick = true;
  }

  private listenToClickOutside(): void {
    this.renderer.listen('window', 'click', () => {
      if (!this.linkBtnClick && this.showLinks) {
        this.showLinks = false;
      }
      this.linkBtnClick = false;
    });
  }

  private getLinks(): void {
    this.subs.add(
      this.codeService.getCodesByStatus(this.EXTERNAL_WEB_LINKS, 'false')
      .subscribe(res => {
        this.links = res[0]?.values;
      })
    );
  }

  ngOnDestroy(){
    this.subs.unsubscribe();
  }
}
