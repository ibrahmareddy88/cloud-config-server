import { HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { ConfigLoader } from '@hipeap/shared-security';

export function loadConfiguration(configService: ConfigLoader): any {
  return () => configService.loadConfiguration();
}

@NgModule({
  imports: [HttpClientModule],
  declarations: [],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: loadConfiguration,
      deps: [ConfigLoader],
      multi: true,
    },
  ],
})
export class ConfigModule {}
