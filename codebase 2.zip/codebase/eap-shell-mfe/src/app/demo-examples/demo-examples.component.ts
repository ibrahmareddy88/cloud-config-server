import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-examples',
  templateUrl: './demo-examples.component.html',
  styleUrls: ['./demo-examples.component.scss'],
})
export class DemoExamplesComponent implements OnInit {
  activeSection = 'base';

  gridView = false;

  hideShow = [];

  smsOpen = false;

  today: Date;

  numSequence(n: number): Array<number> {
    return Array(n);
  }

  demoSamplesData = [
    { label: 'name', value: 'Name' },
    { label: 'status', value: 'Status' },
    { label: 'identifier', value: 'Questionnaire ID' },
    { label: 'lastModifiedDate', value: 'Last Modified Date' },
    { label: 'code', value: 'Concept Code' },
    { label: 'Example Label', value: '--------' },
    { label: 'Example Label 1', value: '--------' },
    { label: 'Example Label 2', value: 'Answer 2' },
  ];

  ngOnInit(): void {}

  openSection(sctn: string): void {
    this.activeSection = sctn;
  }

  toggleGridView(val: boolean): void {
    this.gridView = val;
  }

  toggleHideShow(i: number): void {
    this.hideShow[i] = !this.hideShow[i];
  }

  openSMS() {
    this.smsOpen = !this.smsOpen;
  }
}
