import { Component, AfterContentChecked, ChangeDetectorRef, OnInit, OnDestroy } from '@angular/core';

import { NavigationError, NavigationStart, RouteConfigLoadEnd, RouteConfigLoadStart, Router } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import {
  IdleStatusData,
  IdleMonitorService,
  IdlePopupComponent,
  ConfirmationToasterService,
} from '@hipeap/shared-components';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { SecurityService } from '@hipeap/shared-security';
import { LoaderService } from '@hipeap/shared-state';
import { SubSink } from 'subsink';

export let browserRefresh = false;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterContentChecked, OnDestroy {
  title = 'hipeap-shell-mfe';

  private subs = new SubSink();

  showHeader = true;

  elementShown: any;

  showLoader = false;

  showOverlay: boolean = false;

  asyncLoadCount = 0;

  idleState?: string;

  timedOut?: boolean;

  status?: IdleStatusData;

  popRef?: MatDialogRef<IdlePopupComponent>;

  lastPing?: Date;
  // firstSignOn = false;

  constructor(
    private changeDetector: ChangeDetectorRef,
    private router: Router,
    private dialog: MatDialog,
    private keepAlive: Keepalive,
    private idle: Idle,
    private idleMonitorService: IdleMonitorService,
    private securityService: SecurityService,
    private loaderService: LoaderService,
    private overlaySerive: ConfirmationToasterService
  ) {
    idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);

    /* Begin idle code */
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.';
      this.reset();
    });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.status = {
        message: '',
        closeDialog: true,
      };
      this.idleMonitorService.setStatus(this.status);
      // this.showHeader = false;
      // this.router.navigate(['logout'], {state : {data : 'Idle'}});
      // this.router.navigate(['/']);
    });

    this.idle.onIdleStart.subscribe(() => {
      this.popRef = this.dialog.open(IdlePopupComponent, { disableClose: false });
      this.status = {
        message: '120 seconds',
        closeDialog: false,
      };
      this.idleState = "You've gone idle!";
      this.idleMonitorService.setStatus(this.status);
      this.popRef?.afterClosed().subscribe((value: any) => {
        if (value) {
          this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
          this.idle.watch();
          this.reset();
        }
      });
    });

    this.idle.onTimeoutWarning.subscribe((countdown: any) => {
      this.idleState = `${countdown} second`;
      if (countdown !== 1) {
        this.idleState += 's';
      }
      this.status = {
        message: this.idleState,
        closeDialog: false,
      };
      this.idleMonitorService.setStatus(this.status);
      this.idle.clearInterrupts();
    });

    // sets the ping interval to 15 seconds
    this.keepAlive.interval(15);
    this.keepAlive.onPing.subscribe(() => (this.lastPing = new Date()));
    /* End idle code */
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  ngOnInit(): void {
    this.idle.setIdle(1 * 60);
    this.idle.setTimeout(1 * 60);
    //this.idle.watch();
    this.timedOut = false;
    this.showHeader = true;
    this.router.events.subscribe((event: any) => {
      if (event instanceof RouteConfigLoadStart) {
        this.asyncLoadCount++;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.asyncLoadCount--;
      } else if (event instanceof NavigationError) {
        this.asyncLoadCount--;
      } else if (event instanceof NavigationStart) {
        browserRefresh = !this.router.navigated;
      }
      this.showLoader = !!this.asyncLoadCount;
    });

    this.loaderService.showLoader$.subscribe((data) => (this.showLoader = data));
    this.subs.add(this.overlaySerive.showOverlay$.subscribe((data: boolean) => (this.showOverlay = data)));

    // this.login();
  }

  ngAfterContentChecked(): void {
    this.changeDetector.detectChanges();
  }

  reset(): void {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  login(): void {
    if (this.securityService.login()) {
      this.router.navigateByUrl('/');
    } else {
      this.showHeader = false;
    }
  }
}
