import { loadRemoteModule } from '@angular-architects/module-federation';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { config } from '@hipeap/shared-security';
import { LogoutComponent } from '@hipeap/shared-components';
import { DemoExamplesComponent } from './demo-examples/demo-examples.component';

const routes: Routes = [
  {
    path: 'groups',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'groups',
        exposedModule: './Module',
        remoteEntry: config.groupsUrl,
      }).then((m) => m.GroupsShellModule),
  },
  {
    path: 'admin',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'admin',
        exposedModule: './Module',
        remoteEntry: config.adminUrl,
      }).then((m) => m.AdminShellModule),
  },
  {
    path: 'reports',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'reports',
        exposedModule: './Module',
        remoteEntry: config.reportsUrl,
      }).then((m) => m.ReportsShellModule),
  },
  {
    path: 'providers',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'providers',
        exposedModule: './Module',
        remoteEntry: config.providerUrl,
      }).then((m) => m.ProviderShellModule),
  },
  {
    path: 'consultation',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'consultation',
        exposedModule: './Module',
        remoteEntry: config.consultationUrl,
      }).then((m) => m.ConsultationShellModule),
  },
  {
    path: 'referral',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'referral',
        exposedModule: './Module',
        remoteEntry: config.referralUrl,
      }).then((m) => m.ReferralShellModule),
  },
  {
    path: 'member',
    loadChildren: () =>
      loadRemoteModule({
        remoteName: 'member',
        exposedModule: './Module',
        remoteEntry: config.memberUrl,
      }).then((m) => m.MemberShellModule),
  },
  {
    path: 'logout',
    component: LogoutComponent,
  },
  {
    path: 'demo',
    component: DemoExamplesComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
