package com.anthem.eap.repository;

import com.anthem.eap.exception.SequenceException;
import com.anthem.eap.model.DBSequence;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.ReactiveMongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

/** @author Rajesh Bandarupalli */
@Repository
public class ReactiveMongoIdSequenceRepository implements ReactiveIdSequenceRepository {

  private final ReactiveMongoOperations mongoOperations;

  public ReactiveMongoIdSequenceRepository(@Lazy ReactiveMongoOperations mongoOperations) {
    this.mongoOperations = mongoOperations;
  }

  @Override
  public Mono<Long> getNextSequenceId(String key) {
    // get sequence id
    Query query = new Query(Criteria.where("_id").is(key));

    // increase sequence id by one
    Update update = new Update();
    update.inc("seq", 1L);

    // return new increased id
    FindAndModifyOptions options = new FindAndModifyOptions();
    options.returnNew(true);
    options.upsert(true);
    return this.mongoOperations
        .findAndModify(query, update, options, DBSequence.class, "sequence")
        .map(DBSequence::getSeq);
  }

  @Override
  public Mono<Long> getNextSequenceId(String key, Long count) throws SequenceException {
    return generateSequenceIdsByCount(key, count);
  }

  /**
   * Get the sequence for bulk operations
   *
   * @param key
   * @param count
   * @return incremented sequence number
   */
  private Mono<Long> generateSequenceIdsByCount(final String key, final Long count) {
    if (count == null || count.intValue() < 1) {
      throw new SequenceException("Invalid sequence generation for count: " + count);
    }

    // get sequence id
    Query query = new Query(Criteria.where("_id").is(key));

    // increase sequence id by count
    Update update = new Update();
    update.inc("seq", count);

    // return new increased id
    FindAndModifyOptions options = new FindAndModifyOptions();
    options.returnNew(true);
    options.upsert(true);
    return mongoOperations
        .findAndModify(query, update, options, DBSequence.class, "sequence")
        .map(DBSequence::getSeq)
        .switchIfEmpty(
            Mono.error(new SequenceException("Unable to get sequence id for key : " + key)));
  }
}
