package com.anthem.eap.exception;

/** @author Rajesh Bandarupalli */
public class SequenceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public SequenceException(String message) {
    super(message);
  }
}
