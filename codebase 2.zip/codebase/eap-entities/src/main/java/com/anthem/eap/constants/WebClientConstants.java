package com.anthem.eap.constants;

public enum WebClientConstants {
  FIXED_DELAY(2),
  RETRY(1);

  public final int code;

  WebClientConstants(int code) {
    this.code = code;
  }
}
