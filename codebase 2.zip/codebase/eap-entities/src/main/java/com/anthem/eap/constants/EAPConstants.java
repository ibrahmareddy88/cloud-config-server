package com.anthem.eap.constants;

/** @author Sravanti Cherukuri(AF69838) */
public enum EAPConstants {
  CODES_COLLECTION("codes"),
  DEFAULT_AUDIT_USER("System"),
  ISG_FEED_JOB("isgUser"),
  IS_RETIRED("isRetired"),
  ZONE_UTC("UTC"),
  ZONE_EST("EST"),
  CATEGORIES("categories"),
  PAGE_NUMBER_PARAM("pageNo"),
  PAGE_SIZE_PARAM("pageSize"),
  SORT_BY_PARAM("sortBy"),
  QUERY_PARAM("query"),
  SORT_ORDER_PARAM("sortOrder"),
  FIELDS_PARAM("fields"),
  SOURCE_SYSTEM("sourceSystem"),
  FILE_PATH("filePath"),
  COMPLETED("Completed"),
  GROUP("group"),
  SUBGROUP("subGroup");

  public final String code;

  EAPConstants(String code) {
    this.code = code;
  }
}
