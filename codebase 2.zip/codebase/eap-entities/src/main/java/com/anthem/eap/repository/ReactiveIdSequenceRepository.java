package com.anthem.eap.repository;

import com.anthem.eap.exception.SequenceException;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

/**
 * Repository for auto sequence generator (for implementation check {@link
 * ReactiveMongoIdSequenceRepository}) Can be implemented for other data sources
 *
 * @author Rajesh Bandarupalli
 */
@Repository
public interface ReactiveIdSequenceRepository {
  Mono<Long> getNextSequenceId(String key) throws SequenceException;

  Mono<Long> getNextSequenceId(String key, Long count) throws SequenceException;
}
