package com.anthem.eap.config;

import lombok.Setter;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/** @author Sravanti Cherukuri(AF69838) */
@Component
public class EAPBeanResolver implements ApplicationContextAware {
  @Setter private static ApplicationContext appContext;

  public static <R> R getBean(Class<R> clazz) {
    return appContext.getBean(clazz);
  }

  @Override
  public void setApplicationContext(ApplicationContext context) throws BeansException {
    setAppContext(context);
  }
}
