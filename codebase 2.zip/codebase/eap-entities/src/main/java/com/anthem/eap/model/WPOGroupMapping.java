package com.anthem.eap.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

/** @author AH19295 */
@Document(value = "wpoGroupMapping")
@Getter
@Setter
@NoArgsConstructor
public class WPOGroupMapping extends AbstractPersistableEntity.IdLong implements Serializable {
  /** */
  private static final long serialVersionUID = 7461600305162532248L;

  private String wpoGroupId;
  private String groupId;
  private String subgroupId;
}
