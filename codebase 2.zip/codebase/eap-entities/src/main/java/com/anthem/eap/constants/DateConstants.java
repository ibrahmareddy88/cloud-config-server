package com.anthem.eap.constants;

public enum DateConstants {
  DD_MM_YYY("dd/MM/yyyy"),
  YYYY_MM_DD_HH_MM_SS("yyyyMMddHHmmss"),
  DD_MM_YYYY_HH_MM_SS("dd-MM-yyyy HH:mm:ss");

  public final String code;

  DateConstants(String code) {
    this.code = code;
  }
}
