package com.anthem.eap.model;

import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

/** @author Sravanti Cherukuri(AF69838) */
@Document(value = "codes")
@Getter
@Setter
@NoArgsConstructor
public class Codes extends AbstractPersistableEntity.IdString {

  private static final long serialVersionUID = -6526901945252395911L;
  // Label represents display name of a category.
  private String label;
  private String description;
  private List<CodeValues> values;
  private String module;
  // Set doNotManage flag if this Category doesn't need to be managed from drop-down management
  // screen
  private boolean doNotManage;
  // If this category options required additional data to be collected from the UI (Eg: XWalk
  // values)
  private String additionalDataLabel;
  // additionalDataSource refers to another category from codes collection (Eg: prodctType)
  private String additionalDataSource;
}
