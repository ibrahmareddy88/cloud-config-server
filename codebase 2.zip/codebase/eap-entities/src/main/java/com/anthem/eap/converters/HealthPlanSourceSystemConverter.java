package com.anthem.eap.converters;

import com.anthem.eap.model.group.HealthPlan.SourceSystem;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.stereotype.Component;

/** @author Sharanya Ravulapally */
@Component
public class HealthPlanSourceSystemConverter {

  @ReadingConverter
  public static class HealthPlanSourceSystemDeserializer
      implements Converter<String, SourceSystem> {

    @Override
    public SourceSystem convert(String source) {
      return SourceSystem.getSourceSystem(source);
    }
  }

  @WritingConverter
  public static class HealthPlanSourceSystemSerializer implements Converter<SourceSystem, String> {

    @Override
    public String convert(SourceSystem source) {
      return source.getValue();
    }
  }
}
