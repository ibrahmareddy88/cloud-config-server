package com.anthem.eap.helper;

import static com.anthem.eap.constants.DBConstants.ID_ATTRIBUTE;
import static com.anthem.eap.constants.EAPConstants.FIELDS_PARAM;
import static com.anthem.eap.constants.EAPConstants.PAGE_NUMBER_PARAM;
import static com.anthem.eap.constants.EAPConstants.PAGE_SIZE_PARAM;
import static com.anthem.eap.constants.EAPConstants.QUERY_PARAM;
import static com.anthem.eap.constants.EAPConstants.SORT_BY_PARAM;
import static com.anthem.eap.constants.EAPConstants.SORT_ORDER_PARAM;

import com.anthem.eap.model.group.dto.PageRequestDto;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

public class PageRequestHelper {

  private static final int DEFAULTPAGENO = 0;
  private static final int DEFAULTPAGESIZE = 5;

  private PageRequestHelper() {}

  public static PageRequestDto getPageRequest(MultiValueMap<String, String> queryParams) {
    int pageNo = getPageNo(queryParams);
    int pageSize = getPageSize(queryParams);
    Direction sortOrder = getSortOrder(queryParams);
    String sortBy = getSortBy(queryParams);
    return PageRequestDto.builder()
        .pageNo(pageNo)
        .pageSize(pageSize)
        .sortBy(sortBy)
        .query(getQuery(queryParams))
        .sortOrder(sortOrder)
        .fields(getFilterBy(queryParams))
        .pagable(getPagable(sortOrder, sortBy, pageNo, pageSize))
        .build();
  }

  private static Pageable getPagable(Direction sortOrder, String sortBy, int pageNo, int pageSize) {
    Sort sort = Sort.by(sortOrder, sortBy);
    return PageRequest.of(pageNo, pageSize, sort);
  }

  private static List<String> getFilterBy(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, FIELDS_PARAM.code)
        .filter(StringUtils::isNoneBlank)
        .map(a -> Arrays.asList(a.split(",")))
        .orElse(Collections.emptyList());
  }

  private static Direction getSortOrder(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, SORT_ORDER_PARAM.code)
        .filter(StringUtils::isNoneBlank)
        .map(Sort.Direction::valueOf)
        .orElse(Sort.Direction.ASC);
  }

  private static String getQuery(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, QUERY_PARAM.code).filter(StringUtils::isNoneBlank).orElse("");
  }

  private static String getSortBy(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, SORT_BY_PARAM.code)
        .filter(StringUtils::isNoneBlank)
        .orElse(ID_ATTRIBUTE);
  }

  private static int getPageNo(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, PAGE_NUMBER_PARAM.code)
        .map(Integer::parseInt)
        .orElse(DEFAULTPAGENO);
  }

  private static int getPageSize(MultiValueMap<String, String> queryParams) {
    return getQueryParam(queryParams, PAGE_SIZE_PARAM.code)
        .map(Integer::parseInt)
        .orElse(DEFAULTPAGESIZE);
  }

  private static Optional<String> getQueryParam(
      MultiValueMap<String, String> queryParams, String name) {
    List<String> queryParamValues = queryParams.get(name);
    if (CollectionUtils.isEmpty(queryParamValues)) {
      return Optional.empty();
    } else {
      String value = queryParamValues.get(0);
      if (value == null) {
        value = "";
      }
      return Optional.of(value);
    }
  }
}
