package com.anthem.eap.event;

import com.anthem.eap.model.AbstractPersistableEntity;
import com.anthem.eap.repository.ReactiveIdSequenceRepository;
import org.reactivestreams.Publisher;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.mongodb.core.mapping.event.ReactiveBeforeConvertCallback;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/** @author Rajesh Bandarupalli */
@Component
public class DomainModelBeforeConvertCallbackEvent
    implements ReactiveBeforeConvertCallback<AbstractPersistableEntity.IdLong> {
  private final ReactiveIdSequenceRepository idSequenceRepository;

  public DomainModelBeforeConvertCallbackEvent(
      @Lazy ReactiveIdSequenceRepository idSequenceRepository) {
    this.idSequenceRepository = idSequenceRepository;
  }

  @Override
  public Publisher<AbstractPersistableEntity.IdLong> onBeforeConvert(
      AbstractPersistableEntity.IdLong entity, String collection) {
    if (entity.getId() == null) {
      return idSequenceRepository
          .getNextSequenceId(collection)
          .map(
              id -> {
                entity.setId(id);
                return entity;
              });
    } else {
      return Mono.just(entity);
    }
  }
}
