package com.anthem.eap.repository;

import static com.anthem.eap.constants.EAPConstants.ZONE_UTC;

import com.anthem.eap.audit.AuditorAwareImpl;
import com.anthem.eap.config.EAPBeanResolver;
import com.anthem.eap.model.AbstractPersistableEntity;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.query.Update;
import reactor.core.publisher.Mono;

/** @author Rajesh Bandarupalli */
public interface MongoAuditingRepository {

  default <T extends AbstractPersistableEntity.IdLong> Mono<T> populateAuditDetails(
      T persistableEntity) {
    Mono<String> currentAuditor =
        EAPBeanResolver.getBean(AuditorAwareImpl.class).getCurrentAuditor();
    if (persistableEntity.getId() == null) {
      return currentAuditor.map(
          ca -> {
            persistableEntity.setCreatedBy(ca);
            persistableEntity.setCreatedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC.code)));
            persistableEntity.setLastModifiedBy(ca);
            persistableEntity.setLastModifiedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC.code)));
            return persistableEntity;
          });
    }
    return currentAuditor.map(
        ca -> {
          persistableEntity.setLastModifiedBy(ca);
          persistableEntity.setLastModifiedDate(
              ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC.code)));
          return persistableEntity;
        });
  }

  default <T extends AbstractPersistableEntity.IdLong> Mono<T> updateMongoId(
      T persistableEntity, String sequenceName) {
    if (!persistableEntity.isNew()) {
      return Mono.just(persistableEntity);
    }
    return EAPBeanResolver.getBean(ReactiveIdSequenceRepository.class)
        .getNextSequenceId(sequenceName)
        .map(
            id -> {
              persistableEntity.setId(id);
              return persistableEntity;
            });
  }

  default <T extends AbstractPersistableEntity.IdLong> void setEmbeddedEntityId(
      List<T> entiteList, T entity) {
    List<Long> ids =
        Optional.ofNullable(entiteList).orElseGet(Collections::emptyList).stream()
            .map(AbstractPersistableEntity.IdLong::getId)
            .collect(Collectors.toList());
    if (CollectionUtils.isNotEmpty(ids)) {
      entity.setId(Collections.max(ids) + 1);
    } else {
      entity.setId(1L);
    }
  }

  default Mono<Update> prepareAuditUpdateQuery(String objectType) {
    Mono<String> currentAuditor =
        EAPBeanResolver.getBean(AuditorAwareImpl.class).getCurrentAuditor();
    return currentAuditor.map(
        ca -> {
          Update update = new Update();
          update.set("lastModifiedBy", ca);
          update.set(
              "lastModifiedDate",
              ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC.code)));

          if (StringUtils.isNoneEmpty(objectType)) {
            update.set(objectType + ".$.lastModifiedBy", ca);
            update.set(
                objectType + ".$.lastModifiedDate",
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC.code)));
          }
          return update;
        });
  }
}
