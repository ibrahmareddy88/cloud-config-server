package com.anthem.eap.audit;

import com.anthem.eap.constants.EAPConstants;
import org.springframework.data.domain.ReactiveAuditorAware;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/** @author Sravanti Cherukuri(AF69838) */
@Component
public class AuditorAwareImpl implements ReactiveAuditorAware<String> {
  @Override
  public Mono<String> getCurrentAuditor() {
    return Mono.just(EAPConstants.DEFAULT_AUDIT_USER.code);
  }
}
