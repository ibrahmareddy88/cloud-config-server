package com.anthem.eap.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.time.ZonedDateTime;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.*;
import org.springframework.data.domain.Persistable;

/** @author Dineel Bathina */
@Getter
@Setter
public abstract class AbstractPersistableEntity<ID extends Serializable>
    implements Serializable, Persistable<ID> {

  public abstract static class IdLong extends AbstractPersistableEntity<Long> {
    @Id @Getter @Setter private Long id;
  }

  public abstract static class IdString extends AbstractPersistableEntity<String> {
    @Id @Getter @Setter private String id;
  }

  @CreatedDate private ZonedDateTime createdDate;

  @LastModifiedDate private ZonedDateTime lastModifiedDate;

  @CreatedBy private String createdBy;

  @LastModifiedBy private String lastModifiedBy;

  @JsonIgnore
  @Override
  public boolean isNew() {
    return this.getId() == null;
  }
}
