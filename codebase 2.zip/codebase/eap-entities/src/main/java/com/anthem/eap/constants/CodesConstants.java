package com.anthem.eap.constants;

public enum CodesConstants {
  EAP_PHONE("eapPhone"),
  EAP_FAX("eapFax"),
  EAP_PHONE_FAX("eapPhoneAndFax");

  public final String key;

  CodesConstants(String key) {
    this.key = key;
  }
}
