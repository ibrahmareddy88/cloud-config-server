package com.anthem.eap.exception;

public class GroupSearchResultException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public GroupSearchResultException(String message) {
    super(message);
  }
}
