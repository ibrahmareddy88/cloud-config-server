package com.anthem.eap.model;

import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** @author Sravanti Cherukuri(AF69838) */
@Getter
@Setter
@NoArgsConstructor
public class CodeValues implements Serializable {
  private String code;
  private String label;
  private String description;
  private boolean isActive;
  private Integer sortOrder;
  // To collect additional details for this option eg: XWalkValues or Product Type.
  private List<String> additionalData;
  private String legacyCode;
}
