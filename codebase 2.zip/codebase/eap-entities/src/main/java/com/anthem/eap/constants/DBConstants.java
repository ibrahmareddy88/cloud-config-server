package com.anthem.eap.constants;

public interface DBConstants {

  String USER_COLLECTION = "eapUser";
  String BROKER_COMMISSION_SEQUENCE = "brokerCommissions";
  String DEFAULT_SORTBY = "lastModifiedDate";
  String SPECIAL_INSTRUCTIONS_SEQUENCE = "specialInstructions";
  String MODULE = "module";
  String CODE_VALUES = "values";
  String ID_ATTRIBUTE = "_id";
  String HEALTHPLAN_NAME = "healthPlanName";
  String SOURCE_SYSTEM = "sourceSystem";
  String GROUP_SUBGROUP_CONTACTS_SEQUENCE = "groupSubgroupContacts";
  String CREATED_BY = "createdBy";
  String GROUP_ALIASES = "aliases";
  String GROUP_EMPLOYEE_COUNT = "employeeCount";
  String HEALTHPLAN = "healthPlan";
  String EMPLOYEE_COUNT_AS_OF_DATE = "asOfDate";
  String MEMBER_INCIDENT_COLLECTION = "memberIncident";
  String LAST_MODIFIED_BY = "lastModifiedBy";
  String INCIDENT_CLOSED_DATE = "closedDate";
  String INCIDENT_TICKLER_DATE = "ticklerDate";
  String INCIDENT_RECOMMENDATION = "recommendation";
  String SYSTEM_CLOSED = "System Closed";
  String REQUEST_SUBMIT_DATE = "requestSubmitDate";
  String STATUS = "status";
  String COMMUNICATIONS = "communications";
  String INCIDENT_CONFIRMATION = "incidentConfirmation";
  String NAME = "name";
  String SUPERVISOR_REFERRAL = "supervisorreferral";
}
