package com.anthem.eap.config;

import static java.time.ZoneId.systemDefault;
import static java.time.ZonedDateTime.ofInstant;

import com.anthem.eap.converters.MongoConvertersBuilder;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.mongodb.config.EnableReactiveMongoAuditing;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.geo.GeoJsonModule;

/** @author Sravanti Cherukuri(AF69838) */
@Configuration
@EnableReactiveMongoAuditing(dateTimeProviderRef = "default.zdt.provider")
public class MongoConfig {

  @Bean
  public MongoCustomConversions mongoCustomConversions() {
    return new MongoConvertersBuilder()
        .addDefaults()
        .add(DateToZonedDateTimeConverter.INSTANCE)
        .add(ZonedDateTimeToDateConverter.INSTANCE)
        .add(MongoZonedDateTimeFromStringConverter.INSTANCE)
        .build();
  }

  @Bean("default.zdt.provider")
  public DateTimeProvider defaultZDTProvider() {
    return () -> Optional.of(ZonedDateTime.now());
  }

  @Bean
  public GeoJsonModule geoJsonModule() {
    return new GeoJsonModule();
  }

  enum DateToZonedDateTimeConverter implements Converter<Date, ZonedDateTime> {
    INSTANCE;

    @Override
    public ZonedDateTime convert(Date source) {
      return ofInstant(source.toInstant(), systemDefault());
    }
  }

  enum ZonedDateTimeToDateConverter implements Converter<ZonedDateTime, Date> {
    INSTANCE;

    @Override
    public Date convert(ZonedDateTime source) {
      return Date.from(source.toInstant());
    }
  }

  enum MongoZonedDateTimeFromStringConverter implements Converter<String, ZonedDateTime> {
    INSTANCE;

    @Override
    public ZonedDateTime convert(String source) {
      if (StringUtils.isEmpty(source)) return null;
      return ZonedDateTime.parse(source);
    }
  }
}
