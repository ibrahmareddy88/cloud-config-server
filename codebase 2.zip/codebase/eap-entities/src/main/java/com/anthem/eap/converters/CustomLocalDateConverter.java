package com.anthem.eap.converters;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.stereotype.Component;

@Component
public class CustomLocalDateConverter {

  @ReadingConverter
  public static class LocalDateDeserializer implements Converter<LocalDateTime, LocalDate> {
    @Override
    public LocalDate convert(LocalDateTime dateTime) {
      return dateTime != null ? dateTime.toLocalDate() : null;
    }
  }

  @WritingConverter
  public static class LocalDateSerializer implements Converter<LocalDate, LocalDateTime> {
    @Override
    public LocalDateTime convert(LocalDate date) {
      return date != null ? LocalDateTime.of(date, LocalTime.MIN) : null;
    }
  }
}
