package com.anthem.eap.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@org.springframework.data.mongodb.core.mapping.Document(value = "documents")
@Getter
@Setter
@NoArgsConstructor
public class Document extends AbstractPersistableEntity.IdLong {
  private String entityType;
  private Long entityId;
  private String location;
  private String type;
  private String metadata; // info on how this doc can be accessed.
}
