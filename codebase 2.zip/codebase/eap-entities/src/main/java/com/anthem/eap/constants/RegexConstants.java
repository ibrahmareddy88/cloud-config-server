package com.anthem.eap.constants;

public enum RegexConstants {
  CASE_INSENSITIVE("(?i).*");

  public final String code;

  RegexConstants(String code) {
    this.code = code;
  }
}
