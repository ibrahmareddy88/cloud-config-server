package com.anthem.eap.constants;

public enum CommunicationStatus {
  FAILED("Failed"),
  PENDING("Pending"),
  PARTIAL("Partial"),
  COMPLETED("Completed"),
  NONE("None");

  public final String code;

  CommunicationStatus(String code) {
    this.code = code;
  }
}
