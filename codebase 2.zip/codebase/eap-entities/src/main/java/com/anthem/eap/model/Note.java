package com.anthem.eap.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(value = "notes")
@Getter
@Setter
@NoArgsConstructor
public class Note extends AbstractPersistableEntity.IdLong {
  // group/member/case etc.
  // TODO: convert to enum once we have the list.
  private String entityType;

  // groupId, memberId, caseId etc. Mongo Id of the specific entity.
  private Long entityId;

  // For the sake of keeping data secure if it is sensitive.
  private boolean sensitive;
  private String content;
}
