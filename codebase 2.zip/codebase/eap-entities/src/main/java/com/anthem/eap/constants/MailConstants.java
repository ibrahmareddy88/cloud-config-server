package com.anthem.eap.constants;

public enum MailConstants {
  TO("toEmail"),
  FROM("fromEmail"),
  CC("ccEmail"),
  SUBJECT("subject");

  public final String key;

  MailConstants(String key) {
    this.key = key;
  }
}
