package com.anthem.eap.converters;

import java.util.ArrayList;
import java.util.List;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;

public final class MongoConvertersBuilder {

  private List<Converter<?, ?>> converters = new ArrayList<>();

  public MongoConvertersBuilder add(Converter<?, ?> c) {
    converters.add(c);
    return this;
  }

  public MongoConvertersBuilder addDefaults() {
    return add(new ZonedDateTimeMongoConverters.ZDTSerializer())
        .add(new ZonedDateTimeMongoConverters.ZDTDeserializer())
        .add(new HealthPlanSourceSystemConverter.HealthPlanSourceSystemSerializer())
        .add(new HealthPlanSourceSystemConverter.HealthPlanSourceSystemDeserializer())
        .add(new CustomLocalDateConverter.LocalDateSerializer())
        .add(new CustomLocalDateConverter.LocalDateDeserializer());
  }

  public MongoCustomConversions build() {
    return new MongoCustomConversions(converters);
  }
}
