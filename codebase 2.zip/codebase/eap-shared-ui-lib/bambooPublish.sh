#!/bin/bash

echo "This is meant to be run after the prodBuild script"

echo "Setting up npmrc file."
git config --global url."https://".insteadOf git://
git config --global http.sslverify false
npm config set strict-ssl false
curl -o .npmrc -u$bamboo_artifactory_override_resolver_username:$bamboo_artifactory_override_resolver_password -k "https://artifactory.anthem.com/artifactory/api/npm/npm-snapshot/auth/anthem"
echo "@hipeap:registry=https://artifactory.anthem.com:443/artifactory/api/npm/npm-snapshot/" >> .npmrc
echo "npmrc file setup"
cat ./.npmrc

# move npmrc file to home folder to apply globally.
mv ./.npmrc ~/.npmrc

git config --global url."https://".insteadOf git://
git config --global http.sslverify false
npm config set strict-ssl false

cd ./dist/hipeap/shared-state

npm publish || true

cd ../shared-components

npm publish || true

cd ../shared-security

npm publish || true