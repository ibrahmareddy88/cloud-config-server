#!/bin/bash

yarn install

# dependencies for shared-state service
cd ./projects/hipeap/shared-components
yarn install

#go back to base directory
cd ../../..

ng build @hipeap/shared-components --prod

#ng build hip-shared-lib --prod