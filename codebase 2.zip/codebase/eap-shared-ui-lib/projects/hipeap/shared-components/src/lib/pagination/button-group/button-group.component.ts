import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ButtonGroupData } from '../../models/search-data';

@Component({
  selector: 'lib-button-group',
  templateUrl: './button-group.component.html',
  styleUrls: ['./button-group.component.scss']
})
export class ButtonGroupComponent implements OnInit {

  @Input() buttonGroupData : ButtonGroupData;
  @Output() buttonClicked = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  emitButton(buttonData: any) {
    this.buttonClicked.emit(buttonData);
  }

}
