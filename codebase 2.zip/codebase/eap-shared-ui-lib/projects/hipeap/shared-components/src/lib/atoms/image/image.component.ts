import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Field } from '../../models/field';
import { BaseAtomComponent } from '../base-atom/base-atom.component';


@Component({
  selector: 'lib-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.scss']
})
export class ImageComponent extends BaseAtomComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }

  emit(){
    this.fieldEmitter.emit({name: this.field.name, data: this.rowFormGroup});
  }
}
