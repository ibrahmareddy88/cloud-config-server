export enum InlineToasterType {
    CRITICAL = 'critical',
    STANDARD = 'standard'
}

export class InlineToaster {
    message?: string = '';
    type?: InlineToasterType = InlineToasterType.STANDARD;
    duration?: number = 30000;
    autoClose?: boolean = false;
}
