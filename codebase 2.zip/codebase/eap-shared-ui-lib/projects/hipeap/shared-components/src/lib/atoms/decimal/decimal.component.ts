import { Component, Input, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-decimal',
  templateUrl: './decimal.component.html',
  styleUrls: ['./decimal.component.scss'],
})
export class DecimalComponent extends BaseAtomComponent implements OnInit {
   inValidCharArray: string[]=[];


  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
    this.inValidCharArray=this.field?.restrictedValues!==undefined?this.field?.restrictedValues:[];
  }
}
