import { Component, Input, OnInit } from '@angular/core';
import { FieldType } from '../../models/field';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-read-only',
  templateUrl: './read-only.component.html',
  styleUrls: ['./read-only.component.scss'],
})
export class ReadOnlyComponent extends BaseAtomComponent implements OnInit {
  fieldData: any;
  prefix: string;
  @Input() toolTipRequired ?: boolean = false;

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.fieldData = this.rowFormGroup.get(this.field.name).get('value').value;
    this.prefix = this.field?.prefix !== undefined ? this.field?.prefix : undefined;
  }
  get fieldType(): typeof FieldType {
    return FieldType;
  }

  get labelValues(): any {
    if (Array.isArray(this.fieldGroup.value.value)) {
      const values = [...this.fieldGroup.value.value];
      return values.map((v) => v.label);
    } else {
      return this.fieldGroup.value.value?.label;
    }
  }

  get isValidValue(): boolean {
    return this.fieldData!==null && this.fieldData!==undefined && this.fieldData!=='';
  }

}
