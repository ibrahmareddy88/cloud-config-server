export interface RowErrors {
  rowId?: string;
  error?: string;
}
