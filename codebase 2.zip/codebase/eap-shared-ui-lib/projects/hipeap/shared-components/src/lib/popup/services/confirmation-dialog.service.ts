import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { Observable } from 'rxjs';
import { take, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
  })
export class ConfirmationDialogService {
  constructor(private dialog: MatDialog) {}
  dialogRef?: MatDialogRef<ConfirmationDialogComponent>;

  public open(options: any): void{
      // this.sharedDataApi.toggleElementShown('dialog', true); // blurs background page elements
      this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          panelClass: options.size || 'small-width', // options.size values-- med-width or large-width
          data: options,
      });
      this.dialogRef.afterClosed().subscribe((res: any) => {
          // this.sharedDataApi.toggleElementShown('dialog', false);
      });
  }
  public confirmed(): Observable<any> | undefined{
      return this.dialogRef?.afterClosed().pipe(
          take(1),
          map((res: any) => {
              return res;
          })
      );
  }
}
