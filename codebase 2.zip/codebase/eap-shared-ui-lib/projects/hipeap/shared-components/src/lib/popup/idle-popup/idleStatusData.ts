export interface IdleStatusData {
    message: string;
    closeDialog: boolean;
}
