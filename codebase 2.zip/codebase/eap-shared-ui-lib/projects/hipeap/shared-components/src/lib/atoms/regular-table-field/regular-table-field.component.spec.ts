import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularTableFieldComponent } from './regular-table-field.component';

describe('RegularTableFieldComponent', () => {
  let component: RegularTableFieldComponent;
  let fixture: ComponentFixture<RegularTableFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegularTableFieldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularTableFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
