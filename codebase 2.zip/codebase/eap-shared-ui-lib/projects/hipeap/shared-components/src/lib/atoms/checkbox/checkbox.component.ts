import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent extends BaseAtomComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }

}
