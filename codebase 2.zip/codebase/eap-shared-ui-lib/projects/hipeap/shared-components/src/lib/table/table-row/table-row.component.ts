import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { ButtonType } from '../../models/buttontype';
import { IS_ROW_EDITABLE } from '../../models/constants';
import { TableData } from '../../models/table-data';
import { EmitterData, Field } from './../../models/field';


@Component({
  selector: 'lib-table-row',
  templateUrl: './table-row.component.html',
  styleUrls: ['./table-row.component.scss'],
})
export class TableRowComponent implements OnInit {
  @Input() tableData: TableData;
  @Input() rowFormGroup: any;
  @Input() buttonData: any;
  @Input() buttonEmitter: EventEmitter<EmitterData>;
  @Input() fieldEmitter: EventEmitter<EmitterData>;
  @Input() tableFormArray: FormArray;
  @Input() index: number;
  @Input() toolTipRequired: boolean = false;
  editing = false;
  disabled = false;
  showRowDetail = false;
  constructor() {}

  ngOnInit(): void {
    this.rowFormGroup = this.rowFormGroup as FormGroup;
    if (this.tableData.isGlobalEdit) {
      this.editing = this.isGlobalEditable();
    }
    this.makeClonedRowEditable();
  }

  toggleEdit(): void {
    this.editing = !this.editing;
  }

  emit(str: string): void {
    if (this.isGlobalEditable() && str === ButtonType.DELETE) {
      this.tableFormArray.removeAt(this.index);
      this.buttonEmitter.emit({
        type: str,
        currentValue: this.rowFormGroup.value,
      });
    } else {
      this.buttonEmitter.emit({
        type: str,
        data: this.rowFormGroup,
      });
    }
  }

  getEnable(field: Field): boolean {
    return this.rowFormGroup.get(field?.name)?.get('enable')?.value;
  }

  get isRowEditable(): boolean {
    return this.rowFormGroup.get(IS_ROW_EDITABLE)?.value;
  }

  isGlobalEditable(): boolean {
    return this.tableData?.isGlobalEdit && this.tableData?.editable;
  }

  getFormGroupValidationMessages(): string[] {
    let formGroupValidationMessages: string[] = [];
    if (
      this.tableData.validatorData &&
      this.tableData.validatorData.length > 0 &&
      this.rowFormGroup.errors
    ) {
      const invalidKeys = Object.keys(this.rowFormGroup.errors);
      this.tableData.validatorData.forEach((x) => {
        if (invalidKeys.includes(x.name))
          formGroupValidationMessages.push(x.errorMsg);
      });
    }
    return formGroupValidationMessages;
  }

  private makeClonedRowEditable(): void {
    const  isCloned = this.tableFormArray?.value[this.index]?.isCloned?.value ?? false;
    if (isCloned) {
      this.editing = true;
      this.disabled = true;
    }
  }

}
