import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiSearchDropdownComponent } from './multi-search-dropdown.component';

describe('MultiSearchDropdownComponent', () => {
  let component: MultiSearchDropdownComponent;
  let fixture: ComponentFixture<MultiSearchDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiSearchDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSearchDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
