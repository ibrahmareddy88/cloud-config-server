import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, TemplateRef, OnChanges, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'lib-multi-search-dropdown',
  templateUrl: './multi-search-dropdown.component.html',
  styleUrls: ['./multi-search-dropdown.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: MultiSearchDropdownComponent,
    }
  ]
})
export class MultiSearchDropdownComponent implements OnInit,AfterViewInit, OnChanges, ControlValueAccessor {

  @Input() labelname:string;
  @Input() mappingField : string;
  @Input() searchValues : Observable<any>;
  @Input() inputSeparator : string;
  @Input() displayFields : string[];
  @Input() inputRowTemplate?: TemplateRef<any>;
  @Input() minInputLength? : number;
  @Output() buttonEmitter = new EventEmitter<string>();
  @Input() clearData : Observable<boolean>;

  // Flag to apply Static filtering on the Options
  @Input() hasStaticFiltering: boolean = false;

  // Options to be displayed on the box
  @Input() options: Array<any> = [];

  // To display the Label of selected options instead of value
  @Input() showLabelForSelectedValues: boolean = false;

  searchInput: string = '';
  searchResult: Array<any> = [];
  outputVals:Array<any> =[];
  searchedOutputVals:Array<string> =[];
  outputSearchVal:string='';
  canShowSearchpopup:boolean=false;
  onChange = (_: any) => {};
  onTouch = () => {};
  duplicates : Array<String> = [];
  disableAdd : boolean = true;
  disableSearch : boolean = true;
  showNoRecords : boolean = false;
  allowedChars : RegExp;
  maxChar:number = 1000;
  invalidInput : boolean = false;
  invalidSearchInput : boolean = false;

  constructor() {}

   writeValue(obj: any): void {
    this.outputVals = obj || [];
    this.onOutputSearchValChange();
    }

    registerOnChange(fn: any): void {
      this.onChange = fn;
    }
    registerOnTouched(fn: any): void {
      this.onTouch = fn;
    }
    setDisabledState(isDisabled: boolean): void {

    }

  ngOnChanges(changes: SimpleChanges) {
    if((changes.hasStaticFiltering || changes.options) && this.hasStaticFiltering && this.options) {
      this.onSearchResultsReceived(this.options);
    }
  }

   ngAfterViewInit(): void {
     this.clearData?.subscribe(flag => {
       if(flag){
        this.showNoRecords = false;
       }
     })
     this.searchValues?.subscribe(data => this.onSearchResultsReceived(data));
     this.allowedChars = new RegExp(`^[a-zA-Z0-9\b${this.inputSeparator || ''}]*$`);
   }

   onSearchResultsReceived(data:any[]) {
      this.searchResult = data;
      this.canShowSearchpopup = data.length > 0;
      this.showNoRecords = !this.disableSearch && !this.canShowSearchpopup;
      this.disableAddBtn();
   }

  ngOnInit(): void {
  }

  onSearchCloseClick():void {
    this.canShowSearchpopup = false;
    this.disableAddBtn();
  }

  disableSearchBtn() {
    this.disableSearch = this.searchInput.length < this.minInputLength;
  }

  disableAddBtn() {
    this.disableAdd = !this.canShowSearchpopup && this.searchInput.length < this.minInputLength;
  }

  onSearchInputChange() : void {
    this.invalidInput = this.searchInput && !this.allowedChars.test(this.searchInput);
    this.canShowSearchpopup = false;
    this.duplicates = [];
    if(!this.invalidInput) {
      this.disableSearchBtn();
      this.disableAddBtn();
    }
  }

  onSearchClick() : void {
    this.duplicates = [];
    this.disableAdd = true;
    
    if(this.hasStaticFiltering) {
      this.performStaticFiltering()
    } else {
      this.buttonEmitter.emit(this.searchInput);
    }
  }

  onAddClick():void {
    this.canShowSearchpopup = false;
    this.duplicates = [];
    this.searchInput.split(this.inputSeparator).forEach(val => this.addRowIfNotExists(val));
    this.outputVals.sort();
    this.onOutputSearchValChange();
    this.searchInput = '';
    this.disableAdd = true;
    this.disableSearch = true;
  }

  addRowIfNotExists(value:string) {
    if(value) {
      if(this.outputVals.indexOf(value) == -1) {
        this.outputVals.push(value);
      } else {
        this.duplicates.indexOf(value) == -1? this.duplicates.push(value):'';
      }
    }
  }

  onRowAdd(searchRow:any) {
    let newVal = searchRow[this.mappingField];
    if(this.outputVals.indexOf(newVal) == -1) {
      this.outputVals.push(newVal);
      this.outputVals.sort();
      this.onOutputSearchValChange();
    }
  }

 onOutputSearchValChange() :void {
  this.invalidSearchInput = false;
  if(!this.outputSearchVal) {
    this.searchedOutputVals = this.outputVals;
  } else {
    this.invalidSearchInput =!(/^[a-zA-Z0-9\b]*$/.test(this.outputSearchVal));
    let inputstr =this.outputSearchVal.toLocaleLowerCase();
    this.searchedOutputVals = this.outputVals.filter(row => row.toLowerCase().includes(inputstr));
  }
  this.onChange(this.outputVals);
  this.onTouch();
 }

 onOuputValDelete(inputval:string) {
  this.outputVals.splice(this.outputVals.indexOf(inputval), 1);
  this.onOutputSearchValChange();
 }

 canAddRow(searchRow: any) {
   return this.outputVals.indexOf(searchRow[this.mappingField]) != -1;
 }

 onNoRecordsCloseClick() {
   this.showNoRecords = false;
 }

 keyPressAlphanumeric(event) {
  let inp = String.fromCharCode(event.keyCode);
  if(inp === this.inputSeparator) {
    let len = this.searchInput.length;
    if(!this.searchInput || this.searchInput.charAt(len-1) === inp) {
      return false;
    } else {
      if((len - this.searchInput.lastIndexOf(this.inputSeparator)) <= this.minInputLength) {
        return false;
      }
    }
  }
  if (this.allowedChars.test(inp)) {
    return true;
  } else {
    event.preventDefault();
    return false;
  }
}

onoutputSearchValKeyPress(event) {
  let inp = String.fromCharCode(event.keyCode);
  if (/^[a-zA-Z0-9\b]*$/.test(inp)) {
    return true;
  } else {
    event.preventDefault();
    return false;
  }
}

  /**
   * This method finds the selected option and provides the Label value for selected value
   * @param selectedValue 
   */
  getLabelForSelectedValue(selectedValue: any) {
    const selectedOption = this.searchResult.find(value => value[this.mappingField] === selectedValue);
    if(selectedOption) {
      return this.displayFields.map(key => selectedOption[key]).join(this.inputSeparator)
    }

    return selectedValue;
  }

  private performStaticFiltering() {
    let filteredData = this.options;
    if(this.searchInput?.length) {
      filteredData = this.options.filter(option =>
        this.displayFields.some(fieldKey =>
          (option[fieldKey] as string)?.toLowerCase()?.includes(this.searchInput?.toLowerCase())));
    }
    
    this.canShowSearchpopup = filteredData?.length > 0;
    this.showNoRecords = !filteredData?.length;
    this.searchResult = filteredData;
  }

}
