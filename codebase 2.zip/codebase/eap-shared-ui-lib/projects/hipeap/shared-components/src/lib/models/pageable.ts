
export interface Pageable {
  pageNumber?: number;
  pageSize?: number;
  paged?: boolean;
  unpaged?: boolean;
  offset?: number;
  totalElements?: number;
}

