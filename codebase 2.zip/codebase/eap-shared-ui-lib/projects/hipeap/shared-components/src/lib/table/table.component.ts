import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  TemplateRef,
} from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { IS_ROW_EDITABLE } from '../models/constants';
import {
  EmitterData,
  Field,
  FieldType,
  Option,
  OptionMap,
} from '../models/field';
import { Pageable } from '../models/pageable';
import { TableData } from '../models/table-data';
import { FhirpathService } from '../services/fhirpath.service';
import { FileUploadUtil } from '../utils/file-upload-utils';
import { FilterData, EventChangeType } from '../models/filter-data';

@Component({
  selector: 'lib-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit, OnChanges {
  @Input() tableData!: TableData;
  @Input() tableValues: any;
  @Input() optionsMap: OptionMap[];
  @Input() isRefreshed!: boolean;
  @Input() filter: any;
  @Input() customFilters: Array<any>;
  @Input() globalSort: any;
  @Input() filterByType: any;
  @Input() statusList: any;
  @Input() dateFilter: boolean;
  @Input() statusOptionAll: boolean;
  @Input() dateFilterCriteria: any;
  @Input() toolTipRequired ?: boolean = false;
  @Input() customTemplate?: TemplateRef<any>;
  @Output() buttonEmitter = new EventEmitter<EmitterData>();
  @Output() fieldEmitter = new EventEmitter<EmitterData>();
  @Output() filterPageEmitter = new EventEmitter<FilterData>();
  @Output() exportFileEmitter = new EventEmitter<FilterData>();
  pageable: Pageable = {
    pageNumber: 1,
    pageSize: 5,
    totalElements: 0,
  };
  filterEmitterData: FilterData = {};
  selectedView: any;
  tableFormArray: FormArray;
  actionFormGroup: FormGroup;
  dynamicView: any;
  filterresult: boolean;
  tableExportArray: any[];
  searchExportArray: any[];
  constructor(
    private fhirPathService: FhirpathService,
    private cd: ChangeDetectorRef,
    private fileUploadUtil: FileUploadUtil
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (
      this.isRefreshed &&
      !changes?.isRefreshed?.firstChange &&
      !this.tableData.isGlobalEdit
    ) {
      this.updatePageableAndTableValues();
      this.createFormArray(this.tableValues, false);
      this.cd.detectChanges();
    } else if (
      this.isRefreshed &&
      !changes?.isRefreshed?.firstChange &&
      this.tableData.isGlobalEdit
    ) {
      this.updatePageableAndTableValues();
      if (changes.tableValues?.previousValue !== undefined) {
        this.globalEditRowGroup(changes);
      } else {
        this.createFormArray(this.tableValues, false);
      }
      this.cd.detectChanges();
    }
  }

  private updatePageableAndTableValues(): void {
    if (this.tableValues && this.tableData?.serverPagination) {
      this.pageable.pageSize = this.tableValues.pageable?.pageSize;
      this.pageable.pageNumber = this.tableValues.pageable?.pageNumber + 1;
      this.pageable.totalElements = this.tableValues.totalElements;
      this.tableValues = this.tableValues.content;
    } else {
      this.tableValues = this.tableValues;
      this.pageable.pageSize = 5;
      this.pageable.pageNumber = 1;
      this.pageable.totalElements = this.tableValues?.length;
    }
  }

  ngOnInit(): void {
    this.updatePageableAndTableValues();
    this.createFormArray(this.tableValues, false);
  }

  createFormArray(tableValues: any, isSearch: boolean): void {
    if (this.tableData.fileName) {
      if (!this.tableData.searchDownload && !isSearch) {
        this.tableExportArray = [];
      } else if (isSearch && this.tableData.searchDownload) {
        this.searchExportArray = [];
      }
    }
    this.tableFormArray = new FormArray([]);
    tableValues?.forEach((value: any, index: number) => {
      let tableExportValue: any = {};
      const rowGroup: FormGroup = new FormGroup({});
      rowGroup.addControl('id', new FormControl(index));
      rowGroup.addControl('buttons', new FormControl(this.tableData.buttons));
      this.tableData.headerFields?.forEach((fieldValue: Field) => {
        this.createFormGroup(fieldValue, value, rowGroup, tableExportValue);
      });
      this.tableData.cardFields?.forEach((fieldValue: Field) => {
        this.createFormGroup(fieldValue, value, rowGroup, tableExportValue);
      });
      this.tableFormArray.push(rowGroup);
      this.filterresult = false;
      if (
        this.tableData.fileName &&
        !isSearch &&
        !this.tableData.searchDownload
      ) {
        this.tableExportArray.push(tableExportValue);
      } else if (
        this.tableData.fileName &&
        isSearch &&
        this.tableData.searchDownload
      ) {
        this.searchExportArray.push(tableExportValue);
      }
    });
    if (tableValues?.length === 0) {
      this.filterresult = true;
    }
  }

  createFormGroup(
    fieldValue: Field,
    value: any,
    rowGroup: FormGroup,
    tableExportValue: any
  ): void {
    const expression: string = fieldValue.dataPath
      .split('%resource')
      .join('TableData');
    const enableWhenExpr: string = fieldValue.enableWhen
      ?.split('%resource')
      .join('TableData');
    const rowEditableExpr: string = this.tableData.isRowEditable
      ?.split('%resource')
      .join('TableData');
    value.resourceType = 'TableData';
    const evaluateResult: any[] =
      this.fhirPathService.evaluate(value, expression, null) || [];
    const validators = fieldValue.validatorData
      ?.filter((val) => val.valFunc !== undefined && val.valFunc !== null)
      .map((v) => v.valFunc);
    const elementValue =
      fieldValue.type === FieldType.MULTISELECT
        ? this.isValidValue(evaluateResult)
          ? evaluateResult
          : ''
        : this.isValidValue(evaluateResult)
        ? evaluateResult[0]
        : '';
    const enableValue = enableWhenExpr
      ? this.fhirPathService.evaluate(value, enableWhenExpr, null)[0]
      : true;

    if (rowEditableExpr) {
      rowGroup.addControl(
        IS_ROW_EDITABLE,
        new FormControl(
          this.fhirPathService.evaluate(value, rowEditableExpr, null)[0]
        )
      );
    }
    if (fieldValue.choiceOptions) {
      const fieldGroup = new FormGroup({
        value: new FormControl(
          this.getOption(fieldValue, elementValue),
          validators
        ),
        choiceOptions: new FormControl(
          this.getOptionsFromMap(fieldValue.choiceOptions)
        ),
        enable: new FormControl(enableValue),
      });
      rowGroup.addControl(fieldValue.name, fieldGroup);
    } else if (fieldValue.type === FieldType.DATE) {
      const elementControl = new FormGroup({
        value: new FormControl(
          elementValue ? new Date(elementValue) : '',
          validators
        ),
        enable: new FormControl(enableValue),
      });
      rowGroup.addControl(fieldValue.name, elementControl);
    } else {
      const elementControl = new FormGroup({
        value: new FormControl(elementValue, validators),
        enable: new FormControl(enableValue),
      });
      rowGroup.addControl(fieldValue.name, elementControl);
    }
    if (this.tableData.fileName && fieldValue.exportableField) {
      tableExportValue[
        fieldValue.label
          ? fieldValue.label.toUpperCase()
          : fieldValue.name.toUpperCase()
      ] = elementValue;
    }
  }

  private isValidValue(elementValue: any) {
    return elementValue !== null && elementValue !== undefined;
  }

  getOptionsFromMap(choiceOption: string): Option[] {
    return this.optionsMap.find((option) => option.optionKey === choiceOption)
      .optionValues;
  }

  filterResult(filterAction: any): void {
    this.createFormArray(filterAction, true);
    this.pageable.pageSize = 5;
    this.pageable.pageNumber = 1;
    this.pageable.totalElements = filterAction?.length;
    filterAction.pageable = this.pageable;
    this.filterEmitterData = filterAction;
    this.filterPageEmitter.emit(this.filterEmitterData);
    this.scrollToFirstRow();
  }

  scrollToFirstRow(): void {
    setTimeout(() => {
      document
        .getElementById('rowitem0')
        ?.scrollIntoView({ behavior: 'smooth' });
    }, 10);
  }

  getOption(field: Field, elementValue: any): Option | Option[] {
    if (Array.isArray(elementValue)) {
      return this.getOptionsFromMap(field.choiceOptions).filter((opt) =>
        elementValue.includes(opt.code)
      );
    } else {
      return this.getOptionsFromMap(field.choiceOptions).find(
        (opt) => opt.code == elementValue
      );
    }
  }

  emitFilterData(event: FilterData): void {
    const filterData = event;
    this.pageable.pageNumber = 1;
    filterData.pageable = this.pageable;
    this.filterEmitterData = filterData;
    this.filterPageEmitter.emit(this.filterEmitterData);
  }

  private globalEditRowGroup(changes: SimpleChanges): void {
    let tableExportValue: any = {};
    // get only the newly added row from table arrray
    const newRows = changes.tableValues?.currentValue.filter(
      (row: any) =>
        !changes.tableValues?.previousValue?.some(
          (prevRrow: any) => row.guid === prevRrow.guid
        )
    );
    newRows.forEach((value: any, index: number) => {
      const rowGroup: FormGroup = new FormGroup({});
      rowGroup.addControl('id', new FormControl(index));
      rowGroup.addControl('buttons', new FormControl(this.tableData.buttons));
      this.tableData.headerFields?.forEach((fieldValue: Field) => {
        this.createFormGroup(fieldValue, value, rowGroup, tableExportValue);
      });
      this.tableData.cardFields?.forEach((fieldValue: Field) => {
        this.createFormGroup(fieldValue, value, rowGroup, tableExportValue);
      });
      this.tableFormArray.push(rowGroup);
    });
  }
  export() {
    if (this.tableData?.serverExport) {
      this.exportFileEmitter.emit(this.filterEmitterData);
    } else {
      this.fileUploadUtil.exportAsExcelFile(
        this.exportArray(),
        this.tableData.fileName
      );
    }
  }

  public get isExportable() {
    return (
      this.tableExportArray?.length > 0 || this.searchExportArray?.length > 0
    );
  }

  exportArray(): any[] {
    return this.tableExportArray.length > 0
      ? this.tableExportArray
      : this.searchExportArray;
  }

  getTableFormArray(): any[] {
    return this.tableFormArray.length > 0 ? this.tableFormArray.value : [];
  }

  pageChangeHandler(event: Pageable) {
    this.pageable.pageSize = event.pageSize;
    this.pageable.pageNumber = event.pageNumber;
    if (this.tableData?.serverPagination) {
      this.filterEmitterData.pageable = event;
      this.filterEmitterData.eventType = EventChangeType.PAGE_NUMBER;
      this.filterPageEmitter.emit(this.filterEmitterData);
    }
    this.scrollToFirstRow();
  }
}
