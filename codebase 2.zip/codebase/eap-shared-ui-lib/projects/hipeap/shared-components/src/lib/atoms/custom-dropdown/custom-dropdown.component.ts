import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-custom-dropdown',
  templateUrl: './custom-dropdown.component.html',
  styleUrls: ['./custom-dropdown.component.scss']
})
export class CustomDropdownComponent extends BaseAtomComponent implements OnInit {

  config = {
    displayKey: 'label',
    search: true,
    noResultsFound: 'No results found!', 
    searchPlaceholder: 'Search',
    height: '200px',
    clearOnSelection: true
  };

  constructor() {
    super();
  }
  

  ngOnInit(): void {
    if(this.field.config){
      this.config = this.field.config;
    }
    this.handleControls();
  }

  emitEvent(event: any, eventType: string): void{
    this.fieldEmitter.emit({type: eventType, name: this.field.name, currentValue: event, data: this.rowFormGroup});
  }

}
