import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-checkbox-group',
  templateUrl: './checkbox-group.component.html',
  styleUrls: ['./checkbox-group.component.scss'],
})
export class CheckboxGroupComponent
  extends BaseAtomComponent
  implements OnInit
{
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }
}
