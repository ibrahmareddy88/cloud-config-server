import { Component, OnInit, Input, Optional, Output, EventEmitter, ViewChild, ViewContainerRef, ComponentFactoryResolver, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { TabGroupData, TabData, ButtonGroupData } from '../../models/search-data';
import { Field } from '../../models/field';
import { Subscription } from 'rxjs';
import { FormGroup } from '@angular/forms';
import { ButtonData } from '../../models/table-data';
import { TabSectionComponent } from './tab-section/tab-section.component';

@Component({
  selector: 'lib-tab-details',
  templateUrl: './tab-details.component.html',
  styleUrls: ['./tab-details.component.scss']
})
export class TabDetailsComponent implements OnInit, AfterViewInit {
  @Input() tabData: TabGroupData;
  @Input() formGroup: FormGroup;
  @Output() tabChange = new EventEmitter();
  @Output() buttonClick = new EventEmitter();
  selectedTabFields: Field[];
  activeTab: string;
  tabButtonGroup: ButtonGroupData;
  tabFieldComponentRef;
  @ViewChild("viewContainerRef", { read: ViewContainerRef })
  VCR: ViewContainerRef;
  buttonSubscription: Subscription ;
  constructor(private CFR: ComponentFactoryResolver, private cd: ChangeDetectorRef) { }
  ngAfterViewInit(): void {
    this.changeTab(this.tabData.tabGroupFields[0]);
  }

  ngOnInit(): void {
    
  }

  changeTab(tab:TabData): void {
    this.tabChange.emit({
      currentTabFields: this.selectedTabFields,
      newTabFields: tab.tabfields
    });
    this.activeTab = tab.tabName;
    this.selectedTabFields =tab.tabfields;
    this.tabButtonGroup = tab.tabButtons
  
    if (this.VCR.get(0)){
      this.destroyTabFields();
    }
    this.createTabFields();
    this.cd.detectChanges();
  }

  createTabFields(){
    let componentFactory = this.CFR.resolveComponentFactory(TabSectionComponent);
    let tabFieldComponentRef = this.VCR.createComponent(componentFactory);
    let childComponent = tabFieldComponentRef.instance;
    childComponent.selectedTabFields = this.selectedTabFields;
    childComponent.tabButtonGroup = this.tabButtonGroup;
    childComponent.formGroup = this.formGroup;
    this.buttonSubscription = childComponent.buttonClick.subscribe((btnData: ButtonData)=>{
      this.buttonClick.emit({
        selectedButton: btnData,
        btnType: btnData.type,
        formData: this.formGroup
      });
    })
  }

  destroyTabFields() {
    this.buttonSubscription.unsubscribe();
    this.VCR.remove(0);
  }

}
