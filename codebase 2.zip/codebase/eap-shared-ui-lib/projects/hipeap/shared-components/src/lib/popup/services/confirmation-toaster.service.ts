import { Injectable, Type } from '@angular/core';
import { Toaster, ToastConfig, Toast } from 'ngx-toast-notifications';
import { ConfirmationToastOptions } from '../../models/confimation-toast-options';
import { ConfirmationToasterComponent } from '../confirmation-toaster/confirmation-toaster.component';
import { Observable, BehaviorSubject } from 'rxjs';
import { filter} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfirmationToasterService{

  constructor(private toaster: Toaster) { }

  private overlay$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  public showOverlay$ = this.overlay$.asObservable();

  private dateField$ = new BehaviorSubject<string>('');

  public readonly getDateField$ = this.dateField$.asObservable();
  
  currentToaster: Toast;
  confirmationToastComponent: Type<any>;
  isCalendarAvailable:boolean;

  public open(options: ConfirmationToastOptions){
    this.isCalendarAvailable = options.isCalendarAvailable;
    let toastConfig: ToastConfig = {
      text: options.message,
      caption: options.confirmText+ '-' + options.cancelText+'-' + options.isCalendarAvailable,
      preventDuplicates: true,
      component: ConfirmationToasterComponent,
      autoClose: false
    };
    this.currentToaster = this.toaster.open(toastConfig);
    // this.currentToaster.onClose.subscribe((value)=>{

    // })
  }

  public confirmed(): Observable<any> | undefined{
    return this.currentToaster?.onClose.pipe(
        filter(n => this.isCalendarAvailable?n: n === true)
    );
  }

  showOverlay() {
    this.overlay$.next(true);
  }

  hideOverlay() {
    this.overlay$.next(false);
  }

  setDateField(date: string) {
    this.dateField$.next(date);
  }
}
