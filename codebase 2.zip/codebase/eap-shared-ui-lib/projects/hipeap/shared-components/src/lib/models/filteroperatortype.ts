export enum FilterOperatorType{
    CONTAINS = "contains",
    EQUALS = "equals",
    ALL = "allowAll"
  }