import { Field } from './field';
import { ButtonData } from './table-data';

export class SearchData {
    searchTitle: string;
    searchFields: SearchFields[];
}
    
export class TabData {
    tabDisplay?: string;
    tabName?: string;
    tabfields?: Field[];
    tabButtons?: ButtonGroupData;
}

export class TabGroupData{
  tabGroupFields?: TabData[];
  tabGroupName?: string;
}

export class ButtonGroupData {
  buttons?: ButtonData[];
  buttonGroupStyleClass?: string
}

export class SearchFields {
    searchFieldType?: SearchFieldType;
    searchField?: Field | ButtonGroupData | TabGroupData;  
}

export enum SearchFieldType{
  TABGROUP ='tab-group',
  INPUT = 'input',
  BUTTONGROUP ='button-group'
}