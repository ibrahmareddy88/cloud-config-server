import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
})
export class MultiSelectComponent extends BaseAtomComponent implements OnInit {
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }

  compareFun(item1, item2): boolean {
    return item1 && item2 ? item1.code === item2.code : item1 === item2;
  }
}
