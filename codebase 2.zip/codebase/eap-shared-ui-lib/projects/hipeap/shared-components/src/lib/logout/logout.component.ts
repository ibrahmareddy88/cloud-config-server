import { Component } from '@angular/core';
import { Location } from '@angular/common';

@Component({
	selector: 'app-logout',
	templateUrl: './logout.component.html',
	styleUrls: ['./logout.component.css']
})
export class LogoutComponent {

	constructor(private location: Location) { }

	relogin() {
		this.location.replaceState('/');
		location.reload();
	}
}
