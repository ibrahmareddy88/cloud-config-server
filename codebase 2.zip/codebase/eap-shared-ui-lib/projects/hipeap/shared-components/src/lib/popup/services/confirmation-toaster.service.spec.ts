import { TestBed } from '@angular/core/testing';

import { ConfirmationToasterService } from './confirmation-toaster.service';

describe('ConfirmationToasterService', () => {
  let service: ConfirmationToasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConfirmationToasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
