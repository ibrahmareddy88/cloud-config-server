import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'lib-no-results',
  templateUrl: './no-results.component.html',
  styleUrls: ['./no-results.component.scss']
})
export class NoResultsComponent implements OnInit {

  @Input() messageHeader?: string;
  @Input() messageContent?: string;
  constructor() { }

  ngOnInit(): void {
  }

}
