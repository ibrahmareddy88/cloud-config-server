import { Directive, HostListener, ElementRef, Input, AfterViewInit, OnDestroy, NgZone } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { PhoneMaskPipe } from '../pipes/phone-mask.pipe';
import { distinctUntilChanged } from 'rxjs/operators';

@Directive({
  selector: '[libPhoneMask]',
})
export class PhoneMaskDirective implements AfterViewInit, OnDestroy {
  @Input('libPhoneMask') isMaskEnabled: string = 'true';
  ngControlSubscription: Subscription;

  constructor(
    private element: ElementRef,
    private phoneMaskPipe: PhoneMaskPipe,
    public ngControl: NgControl
  ) {}

  ngOnDestroy(): void {
    this.ngControlSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.ngControlSubscription = this.ngControl.valueChanges
      .pipe(
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b))
      )
      .subscribe((value) => {
        this.onInputChange();
      });
  }

  @HostListener('input')
  onModelChange() {
    this.onInputChange();
  }

  onInputChange(): void {
    const value = (this.element.nativeElement as HTMLInputElement)
      .value as string;
    if (
      (this.isMaskEnabled === 'true' || this.isMaskEnabled === '') &&
      !!value
    ) {
      let numValue = this.phoneMaskPipe.transform(value);
      const finalValue = !!numValue ? numValue : null;
      this.ngControl.control.patchValue(finalValue, { emitEvent: false });
      this.ngControl.control.updateValueAndValidity();
    }
  }
}
