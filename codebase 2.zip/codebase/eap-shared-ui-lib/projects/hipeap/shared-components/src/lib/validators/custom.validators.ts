import {
  AbstractControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
} from '@angular/forms';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';

/**
 *This methods validates whether the formcontrol value is empty or not
 *@returns Validator Function
 */
export class CustomValidators {
  static NUMBERS = '^[0-9]*$';

  static NUMBERS_WITH_DECIMALS = '^[0-9]+([.][0-9]+)?$';

  static TWO_DECIMALS = '^-?d*[.,]?d{0,2}$';

  static ALPHA_NUMERIC = '^[a-zA-Z0-9]*$';

  static PHONE_NUMBER = '^[0-9]{3}-[0-9]{3}-[0-9]{4}$';

  static NATURALNUMBERS = '[1-9][0-9]*';

  static ALOW_CHAR_SPACE = '^[a-zA-Z ]*$';

  static PHONE_FORMAT = '^\\d{3}-\\d{3}-\\d{4}$';

  static ISDIGIT_REGEX = '^[0-9]*$';

  static EMAIL_PATTERN = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]+$';

  static trimValidator(): ValidatorFn {
    const result = (
      control: AbstractControl
    ): { [key: string]: any } | null => {
      if (control.value?.length > 0 && control.value?.trim() === '') {
        return {
          trimError: 'cannot be empty space(s)',
        };
      }
      return null;
    };
    return result;
  }

  /**
   *This methods validates whether the formcontrol value does has leading and trailing spaces of specified lenghts (min,max)
   *@param minLength:number
   *@param maxLength:number
   *@returns Validator Function
   */
  static leadingAndTrailingspacesValidator(
    minLength: number,
    maxLength?: number
  ): ValidatorFn {
    const result = (
      control: AbstractControl
    ): { [key: string]: any } | null => {
      if (
        control.value?.length >= minLength &&
        control.value?.startsWith(' ')
      ) {
        return {
          spaceError: 'should not contain leading spaces.',
        };
      }
      if (control.value?.length >= minLength && control.value?.endsWith(' ')) {
        return {
          spaceError: 'should not contain trailing spaces.',
        };
      }
      if (minLength && maxLength) {
        if (
          control.value?.length >= minLength &&
          control.value?.startsWith(' ')
        ) {
          return {
            spaceError: 'should not contain leading spaces.',
          };
        }
        if (
          control.value?.length >= maxLength &&
          control.value?.endsWith(' ')
        ) {
          return {
            spaceError: 'should not contain trailing spaces.',
          };
        }
        if (control.value?.endsWith(' ')) {
          return {
            spaceError: 'should not contain trailing spaces.',
          };
        }
      }
      return null;
    };
    return result;
  }

  /**
   *This methods validates whether the formcontrol value has a specified minimum or maximum  lenght
   *@param minLength:number
   *@param maxLength:number
   *@returns Validator Function
   */
  static lengthValidator(minLength: number, maxLength?: number): ValidatorFn {
    const result = (
      control: AbstractControl
    ): { [key: string]: any } | null => {
      if (
        control.value !== null &&
        control.value !== undefined &&
        control.value
      ) {
        let inputValue = control.value;
        const regexp = new RegExp(this.NUMBERS_WITH_DECIMALS);
        const nonDigitRegExp = new RegExp('/[^0-9]/g');
        if (regexp.test(control.value)) {
          inputValue = control.value?.toString()?.replace(nonDigitRegExp, '');
        }
        if (maxLength && inputValue?.length > maxLength) {
          return {
            allowedLength: `maximum allowed length ${maxLength}`,
          };
        }
        if (minLength && inputValue?.length < minLength) {
          return {
            allowedLength: `should have minimum length of ${minLength}`,
          };
        }
        return null;
      }
      return null;
    };
    return result;
  }

  /**
   * This method validates the value of formControl for maximum date value
   *
   * @param maxDate : Date | Moment
   * @returns Validator Function
   */
  public static maxDateValidator(maxDate: Date | moment.Moment): ValidatorFn {
    const result = (
      control: AbstractControl
    ): { [key: string]: any } | null => {
      if (control.value === null || control.value === undefined) return null;
      return control.value <= maxDate
        ? null
        : {
            maxDate: `should be same or before ${moment(maxDate).format(
              'yyyy-MM-DD'
            )}`,
          };
    };
    return result;
  }
  public static minDateValidator(minDate: Date | moment.Moment): ValidatorFn {
    const datePipe = new DatePipe('en-US');
    const result = (
      control: AbstractControl
    ): { [key: string]: any } | null => {
      if (!control.value) return null;
      const controlVal = datePipe.transform(control.value, 'MM/dd/yyyy');
      const minVal = datePipe.transform(minDate?.toLocaleString(), 'MM/dd/yyyy');
      return new Date(controlVal) >= new Date(minVal) 
        ? null
        : {
            maxDate: `should be same or after ${moment(minDate).format(
              'yyyy-MM-DD'
            )}`,
          };
    };
    return result;
  }
  static isDigit(event: KeyboardEvent): boolean {
    const regex = new RegExp(this.ISDIGIT_REGEX);
    return regex.test(event.key);
  }

}
/**
 * Validates the FormGroup values are empty or not
 * @returns ValidatorFn
 */
export function isFormGroupNotEmptyValidator(): ValidatorFn {
  return function validate(formGroup: FormGroup): ValidationErrors {
    let status: boolean = false;
    if (formGroup && formGroup?.controls) {
      Object.keys(formGroup.controls)?.forEach((key) => {
        let controlvalue = formGroup.get(key).value;
        if (
          controlvalue !== null &&
          controlvalue !== undefined &&
          JSON.stringify(controlvalue) !== JSON.stringify('')
        ) {
          status = true;
        }
      });
      if (!status) {
        return {
          emptyFormGroup: true,
        };
      }
    }
    return null;
  };
}
