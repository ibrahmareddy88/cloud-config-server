import { Pageable } from './pageable';

export interface FilterData {
    queryString?: string;
    sortingField?: string;
    sortDirection?: SortDirection;
    pageable?: Pageable;
    eventType?:EventChangeType;
}

export enum SortDirection {
    ASC = 'ASC', 
    DESC = 'DESC'
}

export enum EventChangeType {
    SORT_DIRECTION = 'DIRECTION',
    SORT_BY = 'SORT_BY',
    FILTER_BY = 'FILTER_BY',
    CLEAR = 'CLEAR',
    PAGE_NUMBER = 'PAGE_NUMBER'
}