import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'libPhoneMaskPipe' })
export class PhoneMaskPipe implements PipeTransform {
  transform(value: string) {
    if (value) {
      let numValue = value.replace(/\D/g, '');
      if (numValue.length <= 3 && value.includes('(') && !value.includes(')')) {
        numValue = numValue.substring(0, numValue.length - 1);
      }
      if (!!numValue && numValue.length > 1) {
        if (numValue.length <= 3) {
          numValue = numValue.replace(/^(\d{0,3})/, '($1)');
        } else if (numValue.length <= 6) {
          numValue = numValue.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          numValue = numValue.substring(0, 10);
          numValue = numValue.replace(
            /^(\d{0,3})(\d{0,3})(\d{0,4})/,
            '($1) $2-$3'
          );
        }
      }
      return numValue;
    }
    return value;
  }
}
