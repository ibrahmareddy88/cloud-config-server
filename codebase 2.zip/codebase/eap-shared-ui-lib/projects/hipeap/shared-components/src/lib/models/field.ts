import { TemplateRef } from '@angular/core';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { ButtonType } from './buttontype';

export class Field {
  type?: FieldType;
  label?: string;
  choiceOptions?: string;
  editable?: boolean;
  toolTip?:boolean;
  dataPath?: string;
  name?: string;
  validatorData?: ValidatorData[] = [];
  innerHTML?: string; // might need to sanitize HTML using DOMSanitizer;
  template?: TemplateRef<any>;
  multiple?: boolean;
  enableWhen?: string;
  cssClass?: string;
  config?: any;
  prefix?:string;
  libPhoneMask?: string="true";
  libTinMask?: string="true";
  exportableField?: boolean;
  minDate?: Date;
  minDateControlName?: string;
  maxDate?: Date;
  maxDateControlName?: string;
  enableMap?: Map<any, string[]>;
  activateMap?: Map<any | boolean, string[]>;
  restrictedValues?:string[]
  errorsHandle?:HandleExternalErrors;
  maxLength?: number;
}

export class HandleExternalErrors{

  errorCheckControlName: string;
  operator:Operator;
  validatorName?: string;
  errormsgTargetPath: string;

}

export enum Operator{

  GREAERTHAN = '>',
  GREAERTHANOREQUALS = '>=',
  EQUALS='===',
  NOTEQUALS = '!==',
  LESSTHAN = '<',
  LESSTHANOREQUALS = '<=='

}

export class Option {
  code: string | number;
  label: string
}

export class OptionMap {
  optionKey: string;
  optionValues: Option[]
}

export class EmitterData{
  name?: string;
  data?: FormGroup;
  currentValue?: any;
  type?: any | ButtonType;
  uploadFile?: File;
  closeForm?: Boolean;
}

export enum FieldType {
  CUSTOMFIELD = 'customfield',
  CHECKBOX = 'checkbox',
  CHECKBOXGROUP = 'checkboxgroup',
  DATE = 'date',
  DECIMAL = 'decimal',
  DROPDOWN = 'dropdown',
  IMAGE = 'image',
  RADIO = 'radio',
  TEXTAREA = 'textarea',
  TEXTBOX = 'textbox',
  HIDDEN = 'hidden',
  LINK = 'link',
  MULTISELECT = 'multiselect',
  INNERHTML = 'innerHTML',
  CUSTOMDROPDOWN = 'customDropdown',
  SPEECHTOTEXT = 'speechToText'
}

export class ValidatorData{
  name?: string;
  valFunc?: ValidatorFn;
  errorMsg?: string;
}
