import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationToasterComponent } from './confirmation-toaster.component';

describe('ConfirmationToasterComponent', () => {
  let component: ConfirmationToasterComponent;
  let fixture: ComponentFixture<ConfirmationToasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmationToasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationToasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
