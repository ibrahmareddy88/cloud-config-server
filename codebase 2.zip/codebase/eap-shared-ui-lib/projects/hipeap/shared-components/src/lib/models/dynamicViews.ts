import { DynamicView } from './dynamicView';

export interface DynamicViews {
    _id: number;
    quueId: number;
    pageName: string;
    views: Array<DynamicView>;
}

