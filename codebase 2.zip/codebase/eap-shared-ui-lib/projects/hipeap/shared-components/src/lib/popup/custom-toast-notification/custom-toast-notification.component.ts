import { Component, OnInit, Input } from '@angular/core';
import { Toast } from 'ngx-toast-notifications';

@Component({
  selector: 'lib-custom-toast-notification',
  templateUrl: './custom-toast-notification.component.html',
  styleUrls: ['./custom-toast-notification.component.scss']
})
export class CustomToastNotificationComponent {

  @Input() toast: Toast;

  constructor() { }
  
}
