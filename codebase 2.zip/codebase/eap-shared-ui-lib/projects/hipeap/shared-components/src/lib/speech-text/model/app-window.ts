export interface AppWindow extends Window {
    // tslint:disable-next-line:no-any
    webkitSpeechRecognition: any;
}
