export enum ButtonType{
    SUBMIT ='submit',
    RESET = 'reset',
    CANCEL ='cancel',
    CLEAR = 'clear',
    CUSTOM = 'custom',
    DELETE = 'delete',
    CLONE = 'clone',
    TERMINATE = 'terminate'
  }