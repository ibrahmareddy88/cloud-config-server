import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomToastNotificationComponent } from './custom-toast-notification.component';

describe('CustomToastNotificationComponent', () => {
  let component: CustomToastNotificationComponent;
  let fixture: ComponentFixture<CustomToastNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomToastNotificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomToastNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
