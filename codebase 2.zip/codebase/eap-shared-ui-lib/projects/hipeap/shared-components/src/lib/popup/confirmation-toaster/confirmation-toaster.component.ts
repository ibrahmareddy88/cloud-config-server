import { Component, OnInit, Input } from '@angular/core';
import { Toast } from 'ngx-toast-notifications';
import {ConfirmationToasterService} from '../services/confirmation-toaster.service';
import { take } from 'rxjs/operators';
@Component({
  selector: 'lib-confirmation-toaster',
  templateUrl: './confirmation-toaster.component.html',
  styleUrls: ['./confirmation-toaster.component.scss'],
})
export class ConfirmationToasterComponent implements OnInit {
  @Input() toast: Toast;

  constructor(private overlayService: ConfirmationToasterService) {}

  cancelText: string;
  confirmText: string;
  isCalendarAvailable: boolean;
  isDisabled: boolean = false;

  ngOnInit(): void {
    let splitText = this.toast.caption?.split('-',3);
    this.confirmText = splitText[0];
    this.cancelText = splitText[1];
    this.overlayService.showOverlay();
    this.isCalendarAvailable = (splitText[2] === "true")?true:false;
    if (this.isCalendarAvailable) this.isDisabled = true;
  }

  public cancel(): void {
    this.close(false);
  }

  public close(value: any): void {
    this.overlayService.hideOverlay();
    this.toast.close(value);
  }

  public confirm(): void {
    this.overlayService.getDateField$.pipe(take(1)).subscribe((x) => {
      if (this.isCalendarAvailable) this.close(x);
    });
    if (!this.isCalendarAvailable) this.close(true);
  }

  public terminationDateUpdate(termDate: string): void {
    this.overlayService.setDateField(termDate);
    this.isDisabled = false;
  }
}
