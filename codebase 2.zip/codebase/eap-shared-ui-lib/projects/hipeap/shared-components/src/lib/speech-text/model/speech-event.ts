export enum SpeechEvent {
    Start,
    End,
    FinalContent,
    InterimContent
  }
