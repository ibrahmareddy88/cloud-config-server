import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'lib-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent{

  closeAble = true;
  constructor(
    private mdDialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
      if (data){
        if (data.closeAble !== undefined) { this.closeAble = data.closeAble; }
      }
    }

  public cancel(): void{
    this.close(false);
  }

  public close(value: any): void{
    this.mdDialogRef.close(value);
  }

  public confirm(): void{
    this.close(true);
  }
}
