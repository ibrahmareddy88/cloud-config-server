import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { NgxPaginationModule } from 'ngx-pagination';
import { CheckboxGroupComponent } from './atoms/checkbox-group/checkbox-group.component';
import { CheckboxComponent } from './atoms/checkbox/checkbox.component';
import { DateComponent } from './atoms/date/date.component';
import { DecimalComponent } from './atoms/decimal/decimal.component';
import { DropdownComponent } from './atoms/dropdown/dropdown.component';
import { ImageComponent } from './atoms/image/image.component';
import { MultiSelectComponent } from './atoms/multi-select/multi-select.component';
import { RadioComponent } from './atoms/radio/radio.component';
import { ReadOnlyComponent } from './atoms/read-only/read-only.component';
import { RegularTableFieldComponent } from './atoms/regular-table-field/regular-table-field.component';
import { TextareaComponent } from './atoms/textarea/textarea.component';
import { TextboxComponent } from './atoms/textbox/textbox.component';
import { GridFilterComponent } from './filter/grid-filter/grid-filter.component';
import { LogoutComponent } from './logout/logout.component';
import { NoResultsComponent } from './no-results/no-results.component';
import { PaginationComponent } from './pagination/pagination.component';
import { ConfirmationDialogComponent } from './popup/confirmation-dialog/confirmation-dialog.component';
import { IdlePopupComponent } from './popup/idle-popup/idle-popup.component';
import { ConfirmationDialogService } from './popup/services/confirmation-dialog.service';
import { SpinnerComponent } from './spinner/spinner.component';
import { TableRowComponent } from './table/table-row/table-row.component';
import { TableComponent } from './table/table.component';
import { LocalDateValueAccessorModule } from 'angular-date-value-accessor';
import { CustomDropdownComponent } from './atoms/custom-dropdown/custom-dropdown.component';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { BaseAtomComponent } from './atoms/base-atom/base-atom.component';
import { UnauthComponent } from './unauth/unauth.component';
import { SpeechTextComponent } from './speech-text/speech-text.component';
import { ConfirmationToasterComponent } from './popup/confirmation-toaster/confirmation-toaster.component';
import { ConfirmationToasterService } from './popup/services/confirmation-toaster.service';
import { HistoryPopupComponent } from './popup/history-popup/history-popup.component';
import { UploadButtonComponent } from './upload-button/upload-button.component';
import { PhoneMaskDirective } from './directives/phone-mask.directive';
import { TinMaskDirective } from './directives/tin-mask.directive';
import { MultiSearchDropdownComponent } from './multi-search-dropdown/multi-search-dropdown.component';
import { InlineToasterService } from './inline-toaster/inline-toaster.service';
import { InlineToasterComponent } from './inline-toaster/inline-toaster.component';

import { TinMaskPipe } from './pipes/tin-mask.pipe';
import { PhoneMaskPipe } from './pipes/phone-mask.pipe';
import { GenericDatesService } from '@hipeap/shared-state';
import { ServerFilterComponent } from './filter/grid-filter/server-filter/server-filter.component';
import { TaxIdMaskDirective } from './directives/tax-id-mask.directive';
import { TaxIdMaskPipe } from './pipes/tax-id-mask.pipe';
import { ValidNumericValueDirective } from './directives/valid-numeric.directive';
import { LengthRestrictorDirective } from './directives/length-restrictor.directive';
import { TimeslotPickerComponent } from './timeslot-picker/timeslot-picker.component';
import { EapInputModuleModule } from './eap-input-module/eap-input-module.module';
import { CustomToastNotificationComponent } from './popup/custom-toast-notification/custom-toast-notification.component';
import { TimerComponent } from './timer/timer.component';

@NgModule({
  declarations: [
    TableComponent,
    CheckboxComponent,
    DateComponent,
    DecimalComponent,
    RadioComponent,
    DropdownComponent,
    TextareaComponent,
    TextboxComponent,
    ImageComponent,
    CheckboxGroupComponent,
    TableRowComponent,
    RegularTableFieldComponent,
    ReadOnlyComponent,
    PaginationComponent,
    MultiSelectComponent,
    IdlePopupComponent,
    ConfirmationDialogComponent,
    SpinnerComponent,
    NoResultsComponent,
    LogoutComponent,
    GridFilterComponent,
    CustomDropdownComponent,
    BaseAtomComponent,
    ConfirmationToasterComponent,
    UnauthComponent,
    SpeechTextComponent,
    HistoryPopupComponent,
    UploadButtonComponent,
    PhoneMaskDirective,
    TinMaskDirective,
    TinMaskPipe,
    PhoneMaskPipe,
    MultiSearchDropdownComponent,
    InlineToasterComponent,
    ServerFilterComponent,
    TaxIdMaskDirective,
    TaxIdMaskPipe,
    ValidNumericValueDirective,
    LengthRestrictorDirective,
    TimeslotPickerComponent,
    CustomToastNotificationComponent,
    TimerComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    FormsModule,
    NgxDaterangepickerMd,
    MatNativeDateModule,
    MatDatepickerModule,
    LocalDateValueAccessorModule,
    SelectDropDownModule,
    EapInputModuleModule
  ],
  exports: [
    TableComponent,
    ConfirmationDialogComponent, SpinnerComponent, NoResultsComponent, LogoutComponent,SpeechTextComponent,
    UnauthComponent,
    HistoryPopupComponent,UploadButtonComponent,PhoneMaskDirective,TinMaskDirective, TinMaskPipe, PhoneMaskPipe,MultiSearchDropdownComponent, InlineToasterComponent, TaxIdMaskDirective, TaxIdMaskPipe,ValidNumericValueDirective,
    LengthRestrictorDirective, TimeslotPickerComponent, TimerComponent
  ],
  providers: [
    DatePipe,
    PhoneMaskPipe,
    TinMaskPipe,
    TaxIdMaskPipe,
    ConfirmationDialogComponent,
    SpinnerComponent,
    NoResultsComponent,
    ConfirmationDialogService,
    ConfirmationToasterService,
    GenericDatesService
  ],
})
export class SharedComponentsModule { }
