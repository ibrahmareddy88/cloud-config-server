import { PageElements } from './pageElements';

export interface DynamicView {
    _id: number;
   defaultView: boolean;
   selected: boolean;
   viewName: string;
   pageElements: Array<PageElements>;
}
