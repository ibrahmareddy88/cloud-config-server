export interface ConfirmationToastOptions {
  message: string;
  confirmText: string;
  cancelText: string;
  isCalendarAvailable?:boolean;
}