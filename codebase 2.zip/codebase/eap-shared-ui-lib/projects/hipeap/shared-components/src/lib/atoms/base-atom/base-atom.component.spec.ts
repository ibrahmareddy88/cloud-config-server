import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseAtomComponent } from './base-atom.component';

describe('BaseAtomComponent', () => {
  let component: BaseAtomComponent;
  let fixture: ComponentFixture<BaseAtomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BaseAtomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseAtomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
