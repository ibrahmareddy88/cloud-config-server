import { Directive, Input, ElementRef, HostListener, AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { NgControl } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';

@Directive({
  selector: '[libLengthRestrictor]'
})
export class LengthRestrictorDirective implements AfterViewInit, OnDestroy {
  @Input('libLengthRestrictor') restrictedLength: number;

  ngControlSubscription: Subscription;

  constructor(
    private element: ElementRef,
    public ngControl: NgControl
  ) { }

  ngOnDestroy(): void {
    this.ngControlSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.ngControlSubscription = this.ngControl.valueChanges
      .pipe(
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b))
      )
      .subscribe((value) => {
        this.onInputChange();
      });
  }

  @HostListener('input')
  onModelChange() {
    this.onInputChange();
  }

  onInputChange(): void {
    const value = (this.element.nativeElement as HTMLInputElement).value as string;
    if (
      this.restrictedLength !== null &&
      this.restrictedLength !== undefined &&
      value?.length &&
      value?.length > this.restrictedLength
    ) {
      const finalValue = value.substr(0, this.restrictedLength);
      this.ngControl.control.patchValue(finalValue, { emitEvent: false });
      this.ngControl.control.updateValueAndValidity();
    }
  }

}
