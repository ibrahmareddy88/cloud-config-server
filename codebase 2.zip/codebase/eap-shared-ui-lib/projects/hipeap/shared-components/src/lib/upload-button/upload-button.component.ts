import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileUploadUtil } from '../utils/file-upload-utils';
import * as XLSX from 'xlsx';
import { Toaster, ToastConfig } from 'ngx-toast-notifications';

@Component({
  selector: 'lib-upload-button',
  templateUrl: './upload-button.component.html',
  styleUrls: ['./upload-button.component.scss']
})
export class UploadButtonComponent implements OnInit {

  @Input() accept: string

  @Input() columnHeaders: Map<string, string>;

  @Input() validationColumns: Map<string, string>;

  @Input() label: string;

  @Output() uploadEmitter=new EventEmitter();

  fileInfo: any;

  fileName!: string;

  selectedFiles: File =null;

  constructor(
    private fileUploadUtil: FileUploadUtil,
    private toaster: Toaster
  ) {
   }

  ngOnInit(): void {
  }

  selectFile(event: any) {
    Array.from(event.target.files).forEach((element: File) => {
      this.selectedFiles = element;
    });
    this.fileName = this.selectedFiles.name;
    const fileExt = this.fileName.split('.').pop();
    const acceptExtn = this.accept.split(',');
    if (!acceptExtn.includes(`.${fileExt}`)) {
     this.selectedFiles = null;

     const toastConfig: ToastConfig = {
      caption: 'Error',
      position: 'bottom-center',
      type: 'danger',
      text: `Invalid file type. Select only ${this.accept} file.`
    };

    this.toaster.open(toastConfig);
    }
  }

  upload() {
  let  workbook: any;
  let arrayBuffer: any;
    if (this.selectedFiles) {
      const fileReader = new FileReader();
      let rowMap: Map<string, any>;
      fileReader.onload = () => {  
        arrayBuffer = fileReader.result;
        const data = new Uint8Array(arrayBuffer);
        const arr = [];
        let index = 0;
        while (index <= data.length) {
          arr[index] = String.fromCharCode(data[index]);
          index += 1;
        }
        const bstr = arr.join('');
        workbook = XLSX.read(bstr, { type: 'binary' });
        rowMap = this.fileUploadUtil.getRowItems(workbook, this.columnHeaders, this.validationColumns);
        this.selectedFiles = null;
        this.fileInfo = null;
        this.uploadEmitter.emit(rowMap);
      }
      fileReader.readAsArrayBuffer(this.selectedFiles);
    }
  }
}
