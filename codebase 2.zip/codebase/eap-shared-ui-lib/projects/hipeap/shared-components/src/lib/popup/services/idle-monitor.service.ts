import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IdleMonitorService {

  subjectIdleService: Subject<any> = new Subject<any>();
  getIdleData$ = this.subjectIdleService.asObservable();
  constructor() {}

  setStatus(status: any): void{
      this.subjectIdleService.next(status);
  }
}
