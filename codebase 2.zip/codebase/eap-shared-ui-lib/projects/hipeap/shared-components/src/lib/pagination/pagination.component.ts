import { AfterViewChecked, ChangeDetectorRef, Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Pageable } from '../models/pageable';



@Component({
  selector: 'lib-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements AfterViewChecked {
  @Input() pageSize: number;
  @Input() id: string;
  @Output() readonly page: EventEmitter<Pageable> = new EventEmitter<Pageable>();
  @ViewChild('p') paginator: any;
  pageSizeOptions: number[];
  
  constructor(private cd: ChangeDetectorRef) { }

  ngAfterViewChecked(): void {
    if(this.paginator){
      this.pageSizeOptions = this.getPageSizeOptions();
    }
    this.cd.detectChanges();
  }
  changePageSize(pageSize: any): void {
    this.pageSize = pageSize;
    this.emitPageEvent(1);
  }

  emitPageEvent(pageIndex: any): void {
    this.page.emit({
      pageNumber: pageIndex,
      pageSize: this.pageSize,
      totalElements: this.paginator?.getTotalItems()
    });
  }

  getPageSizeOptions(): Array<number>{
    const multiplier = 5;
    if (this.paginator.getTotalItems()) {
      const pageSizeOption = [...Array((Math.ceil(this.paginator.getTotalItems() / multiplier)) + 1)].map((x, i) => {
        if (i !== 0 && i * multiplier <= 50) {
          return i * multiplier;
        }else{
          return undefined;
        }
      });
      return pageSizeOption.filter(item => item);
    }
    return [];
  }

}
