import { ButtonType } from './buttontype';
import { Field, ValidatorData } from './field';
import { TemplateRef } from '@angular/core';
import {FilterOperatorType} from './filteroperatortype';

export class TableData {
  title?: string;
  cssClass?: string;
  headerFields?: Field[];
  cardFields?: Field[];
  editable?: boolean;
  buttons?: ButtonData[];
  showPagination?: boolean;
  showFilter?: boolean;
  isRowEditable?: string;
  id?: string;
  fileName?: string;
  searchDownload?: boolean;
  isGlobalEdit?: boolean;
  serverPagination?: boolean;
  serverExport?: boolean;
  validatorData?: ValidatorData[] = [];
}

export class ButtonData {
  label?: string;
  withTable?: boolean;
  imgUrl?: string;
  tooltip?: string;
  type?: ButtonType;
  cssClass?: string;
  template?: TemplateRef<any>;
}

export class FilterInput {
  key:string;
  value?:any;
  operator?:FilterOperatorType;//#constants for reference
}

