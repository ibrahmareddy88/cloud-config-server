import { Injectable } from '@angular/core';
import {evaluate, compile} from 'fhirpath';

@Injectable({
  providedIn: 'root'
})
export class FhirpathService {

  constructor() { }
  evaluate(fhir: any, fhirPath: string, context: any): any {
    return evaluate(fhir, fhirPath, context);
  }

  compile(path: string, context: any): any {
    return compile(path, context);
  }

  evaluateToString(fhir: any, fhirPath: string): string {
    const result = this.evaluate(fhir, fhirPath, null);
    if (
      result &&
      result instanceof Array &&
      (result as Array<string>).length === 1
    ) {
      return (result as Array<string>)[0];
    }
    return null;
  }
}
