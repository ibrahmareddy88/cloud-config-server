export interface PageElements {
    _id: number;
    labelName: string;
    key: string;
    visible: boolean;
    cssStyle: string;
    order: number;
}
