import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss'],
})
export class RadioComponent extends BaseAtomComponent implements OnInit {
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }

}
