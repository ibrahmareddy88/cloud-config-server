import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  Renderer2,
  ViewChild,
  SimpleChanges,
} from '@angular/core';

import { DaterangepickerDirective } from 'ngx-daterangepicker-material';
import { Moment } from 'moment';
import { ranges } from './utils/date-utils';
import { FilterService } from './service/filter.service';
import { DynamicViews } from '../../models/dynamicViews';
import { DynamicView } from '../../models/dynamicView';
import { FilterInput } from '../../models/table-data';
import { FilterOperatorType } from '../../models/filteroperatortype';


@Component({
  selector: 'lib-grid-filter',
  templateUrl: './grid-filter.component.html',
  styleUrls: ['./grid-filter.component.scss'],
  providers: [FilterService]
})
export class GridFilterComponent implements OnInit, OnChanges {
  @ViewChild(DaterangepickerDirective, { static: false })
  pickerDirective: DaterangepickerDirective;
  @Input() filterCriteria: any;
  @Input() customFilters: Array<any>;
  @Input() dateFilterCriteria: any;
  @Input() data: Array<any>;
  @Input() dynamicView: DynamicViews;
  @Input() sortingListElements: any;
  @Input() filterTypeList: any;
  @Output() selectedViewChange: EventEmitter<DynamicView> = new EventEmitter<DynamicView>();
  @Output() saveViewChange: EventEmitter<DynamicView> = new EventEmitter<DynamicView>();
  @Output() filterResult = new EventEmitter<Array<any>>();
  filterValue: string = '';
  filterColumnValue: string = '';
  filteredData: Array<any> = new Array();
  viewName: string;
  selectedView: DynamicView;
  hideShow: any = [false, false];
  selected: { startDate: Moment; endDate: Moment };
  filterDate: any;
  saveDisable = false;
  ranges = ranges;
  clickListener = null;
  selectedSortingVariable = null;
  sortByAscOrDesc = false;
  sortedData: Array<any> = new Array();
  @Input() statusFilter: any;
  @Input() isRefreshed: boolean;
  @Input() filterByDate: boolean;
  @Input() statusOptionAll: boolean;
  
  constructor(private filterService: FilterService,
              private renderer: Renderer2) {


              }

  @ViewChild('viewToggleButton') toggleButton: ElementRef;
  @ViewChild('pageElementsHolder') menu: ElementRef;
  ngOnInit(): void {

    this.listenForClickOutside();
    if(this.statusFilter){
      this.statusFiltering(this.statusFilter.status);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.dynamicView) {
      this.defaultview();
    }
    if(this.isRefreshed) {
      this.clear();
    }   
    if (changes.data) {
      this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
    }
  }
  changeFilter(): void {
    this.selectedViewChange.emit(this.selectedView);
  }

  filter(filterInput: string, dateFilter: any, selectedSortingVariable: any): void {
    let keys = this.filterCriteria ? Object.keys(this.filterCriteria) : [];
    let hasNameTypeFilter = (this.filterColumnValue && this.filterColumnValue != 'All');
    let filterVals : FilterInput[][] = new Array();

    if(filterInput) {
      let textvals : FilterInput[] = new Array();
      for (const key of keys) {
        let filterObj = {
          key : key,
          value : filterInput,
          operator : FilterOperatorType.CONTAINS
        };
        textvals.push(filterObj);
        filterVals.push(textvals);
      }
    }
    if(this.statusFilter) {
      let filterObj: any;
      if(this.statusFilter.status === 'All'){
         filterObj = {
          key : 'status',
          value : this.statusFilter.status,
          operator : FilterOperatorType.ALL
        };
      }else{
         filterObj = {
          key : 'status',
          value : this.statusFilter.status,
          operator : FilterOperatorType.EQUALS
        };
      }      
      filterVals.push([filterObj]);
    }

    if(hasNameTypeFilter){
      let filterObj = {
        key : 'nameType',
        value : this.filterColumnValue,
        operator : FilterOperatorType.EQUALS
      };
      filterVals.push([filterObj]);
    }
    this.filteredData = this.filterService.filter(filterInput, dateFilter, filterVals,
                              this.dateFilterCriteria, selectedSortingVariable, this.sortByAscOrDesc, this.data);
    this.filterResult.emit(this.filteredData);
  }

  filterWithParam(param: any, type: string){
    if(type === 'all'){
      this.filterValue = param;
    }else if (type === 'column'){
      this.filterColumnValue = param;
    }
    this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
  }

  filterByKeyWord(param: any): void {  
    this.filterValue = param;
    this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
  }

  statusFiltering(statusString: any): void {
    this.statusFilter.status = statusString;
    this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
  }

  datesUpdated(param: any): void {
    this.filterDate = param;
    this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
  }

  sortingList(): void {
    this.sortByAscOrDesc = !this.sortByAscOrDesc;
    this.filter(this.filterValue, this.filterDate, this.selectedSortingVariable);
  }

  selectView(view: any): void {
    this.selectedView = view;
    this.viewName = '';
    this.selectedViewChange.emit(view);
  }

  defaultview(): void {
    if (this.dynamicView && this.dynamicView.views) {
      const defaultView = this.dynamicView.views.filter((view) => view.defaultView)[0];
      const selectedView = this.dynamicView.views.filter((view) => view.selected)[0];
      this.selectedView = selectedView ? selectedView : defaultView;
      this.viewName = '';
      this.selectedViewChange.emit(this.selectedView);
    }
  }

  saveView(): void {
    if (this.viewName && this.viewName !== '') {
      this.selectedView.viewName = this.viewName;
    }
    this.saveViewChange.emit(this.selectedView);
  }

  clear(): void {
    this.filterValue = '';
    this.filterColumnValue ='';
    this.selected = null;
    this.filterDate = null;
    this.pickerDirective?.clear();
    this.selectedSortingVariable = null;
    this.sortByAscOrDesc = false;
    if(this.statusFilter) {
      this.statusFilter.status = 'Active';
    }
    this.filter(this.filterValue, this.selected, this.selectedSortingVariable);
    this.defaultview();
  }

  private listenForClickOutside(): void {
    this.clickListener = this.renderer.listen('window', 'click', (e: Event) => {
      if (this.hideShow[1] === false) { return; }
      if (!this.toggleButton.nativeElement.contains(e.target) && !this.menu.nativeElement.contains(e.target)) {
        this.togglePageElementView();
      }
    });
  }

  togglePageElementView(): void {
    this.hideShow[1] = !this.hideShow[1];
  }

  onSortingOptionChange(): void {
    this.sortByAscOrDesc = false;
  }
}

