import { Directive, ElementRef, HostListener, Input, AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { TaxIdMaskPipe } from '../pipes/tax-id-mask.pipe';
import { NgControl } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';

@Directive({
  selector: '[libTaxIdMask]',
})
export class TaxIdMaskDirective implements AfterViewInit, OnDestroy {
  @Input('libTaxIdMask') isMaskEnabled: string = 'true';

  ngControlSubscription: Subscription;
  constructor(
    private element: ElementRef,
    private taxIdMaskPipe: TaxIdMaskPipe,
    public ngControl: NgControl
  ) {}

  ngOnDestroy(): void {
    this.ngControlSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.ngControlSubscription = this.ngControl.valueChanges
      .pipe(
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b))
      )
      .subscribe((value) => {
        this.onInputChange();
      });
  }

  @HostListener('input')
  onModelChange() {
    this.onInputChange();
  }

  onInputChange(): void {
    const value = (this.element.nativeElement as HTMLInputElement)
      .value as string;
    if (
      (this.isMaskEnabled === 'true' || this.isMaskEnabled === '') &&
      value
    ) {
      this.ngControl.control.patchValue(this.taxIdMaskPipe.transform(value), { emitEvent: false });
      this.ngControl.control.updateValueAndValidity();
    }
  }
}
