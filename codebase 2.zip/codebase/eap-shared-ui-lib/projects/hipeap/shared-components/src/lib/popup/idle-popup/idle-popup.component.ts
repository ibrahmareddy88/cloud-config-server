import { Component, OnInit, OnDestroy } from '@angular/core';
import { IdleMonitorService } from '../services/idle-monitor.service';
import { MatDialogRef } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { IdleStatusData } from './idleStatusData';

@Component({
  selector: 'lib-idle-popup',
  templateUrl: './idle-popup.component.html',
  styleUrls: ['./idle-popup.component.scss']
})
export class IdlePopupComponent implements OnInit, OnDestroy {

  status?: IdleStatusData;
  getAMStatusSubscription?: Subscription;
  message?: string;

  constructor(
    public dialogRef: MatDialogRef<IdlePopupComponent>,
    private idleService: IdleMonitorService
  ) {}

  ngOnInit(): void{
    this.getAMStatusSubscription = this.idleService.getIdleData$.subscribe((status: IdleStatusData) => {
      this.status = status;
      this.message = 'Click the \'OK\' button or you will be logged out in ' + status.message + '.';
      if (status.closeDialog) {
        this.dialogRef.close(false);
      }
    });
  }

  onClose(): void{
    this.dialogRef.close(true);
  }

  ngOnDestroy(): void{
    this.getAMStatusSubscription?.unsubscribe();
  }


}
