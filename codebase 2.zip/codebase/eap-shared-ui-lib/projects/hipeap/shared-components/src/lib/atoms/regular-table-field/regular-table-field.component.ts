import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Field, FieldType } from '../../models/field';

@Component({
  selector: 'lib-regular-table-field',
  templateUrl: './regular-table-field.component.html',
  styleUrls: ['./regular-table-field.component.scss'],
})
export class RegularTableFieldComponent implements OnInit {
  @Input() field: Field;
  @Input() fields: Field[];
  @Input() rowFormGroup: FormGroup;
  @Input() editing: boolean;
  @Input() toolTipRequired ?: boolean = false;
  @Input() emitter: EventEmitter<any>;

  constructor() {}

  ngOnInit(): void {}

  get fieldType(): typeof FieldType {
    return FieldType;
  }

  public hasError(errorCode: string): boolean {
    return this.fieldValueControl?.hasError(errorCode);
  }

  get error(): boolean {
    return !this.isValid && (this.isDirty || this.isTouched);
  }

  get isValid(): boolean {
    return this.fieldValueControl?.valid;
  }

  get isTouched(): boolean {
    return this.fieldValueControl?.touched;
  }

  get isDirty(): boolean {
    return this.fieldValueControl?.dirty;
  }

  get fieldValueControl(): FormControl{
    return this.rowFormGroup?.get(this.field.name)?.get('value') as FormControl;
  }

  get fieldFormGroup(): FormGroup {
    return this.rowFormGroup?.get(this.field.name) as FormGroup;
  }

  get activate(): boolean{
    return this.rowFormGroup.get(this.field?.name)?.get('enable')?.value;
  }

  get fieldCssClass() {
    return this.field?.cssClass ? this.field?.cssClass : ''
  }
}
