import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'libTaxIdMaskPipe' })
export class TaxIdMaskPipe implements PipeTransform {
  transform(value: string) {
    if (value) {
      let numValue = value.replace(/\D/g, '');
      if (numValue.length <= 2 && value.includes('(') && !value.includes(')')) {
        numValue = numValue.substring(0, numValue.length - 1);
      }
      if (!!numValue && numValue.length > 1) {
        if (numValue.length <= 2) {
          numValue = numValue.replace(/^(\d{0,2})/, '$1');
        } else {
          numValue = numValue.substring(0, 9);
          numValue = numValue.replace(
            /^(\d{0,2})(\d{0,7})/,
            '$1-$2'
          );
        }
      }
      return numValue;
    }
    return value;
  }
}