import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { InlineToaster } from "./inline-toaster.model";

@Injectable({
    providedIn: 'root'
})
export class InlineToasterService {

    private toaster$ = new Subject<InlineToaster>();

    constructor() { }

    getInlineToaster(): Observable<InlineToaster> {
        return this.toaster$.asObservable();
    }

    add(toaster: InlineToaster) {
        this.toaster$.next(toaster);
    }

    addAll(toasterList: Array<InlineToaster>) {
        toasterList.forEach(toaster => {
            this.add(toaster);
        });
    }
}
