import {
  Directive,
  ElementRef,
  Input,
  OnInit,
  OnDestroy
} from '@angular/core';
import { NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';


@Directive({
  selector: '[libNumeric]'
})
export class NumericDirective implements OnInit, OnDestroy {
  @Input() decimals = '0';
  previousEvent;
  ngControlSubscription: Subscription;

  constructor(private el: ElementRef, public ngControl: NgControl) { }
  ngOnDestroy(): void {
    this.ngControlSubscription.unsubscribe();
  }
  ngOnInit(): void {
    this.ngControlSubscription = this.ngControl.valueChanges.subscribe(value => {
      this.onInputChange(value);
    });
  }

  onInputChange(event: string): void {
    if (this.previousEvent === event || typeof(event) === undefined) {
      return;
    }
    this.previousEvent = event;
    let newVal: string;
    newVal = event.toString().replace(/[^\d-.]/gm, '');
    const hyphenSplit = newVal.split('-');
    if (hyphenSplit?.length > 2) {
      newVal = '-' + hyphenSplit[0] + hyphenSplit[1] + hyphenSplit[2];
    } else if (hyphenSplit?.length === 2) {
      newVal = '-' + hyphenSplit[0] + hyphenSplit[1];
    }
    const splitDecimal = newVal?.split('.');
    if (splitDecimal?.length > 1) {
      newVal = splitDecimal[0] + '.' + splitDecimal[1].slice(0, this.decimals as unknown as number);
    }
    this.ngControl.valueAccessor.writeValue(newVal);
    this.ngControl.control.setValue(newVal);
  }
}
