import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ToastConfig, Toaster } from 'ngx-toast-notifications';
import { ConfirmationToasterService } from '../popup/services/confirmation-toaster.service';
import { TimeSpanModel } from './models/timeSpanModel';
import { WeekAvailabilityModel } from './models/weekAvailabilityModel';

enum TIME_FORMAT {
  HOUR_24 = 'HH:mm',
  HOUR_12 = 'hh:mm'
}

@Component({
  selector: 'lib-timeslot-picker',
  templateUrl: './timeslot-picker.component.html',
  styleUrls: ['./timeslot-picker.component.scss']
})
export class TimeslotPickerComponent implements OnInit {

  @Input()
  weekAvailability: Array<WeekAvailabilityModel> | null;

  @Input()
  inViewMode: boolean = true;

  slotForm: FormGroup = this.fb.group({
    startTime: ['', Validators.required],
    endTime: ['', Validators.required]
  });

  LIST_OF_DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  daysForm = this.fb.group({});
  currentMode = null;

  private toastConfig: ToastConfig = {
    caption: 'Error',
    position: 'top-center',
    text: '',
    type: 'danger'
  };

  private timeFormat = 'HH:mm';

  days = [
    { 391: false, id: 391, name: this.LIST_OF_DAYS[0], controlName: this.LIST_OF_DAYS[0], enable: false, slots: [] },
    { 392: false, id: 392, name: this.LIST_OF_DAYS[1], controlName: this.LIST_OF_DAYS[1], enable: false, slots: [] },
    { 393: false, id: 393, name: this.LIST_OF_DAYS[2], controlName: this.LIST_OF_DAYS[2], enable: false, slots: [] },
    { 394: false, id: 394, name: this.LIST_OF_DAYS[3], controlName: this.LIST_OF_DAYS[3], enable: false, slots: [] },
    { 395: false, id: 395, name: this.LIST_OF_DAYS[4], controlName: this.LIST_OF_DAYS[4], enable: false, slots: [] },
    { 396: false, id: 396, name: this.LIST_OF_DAYS[5], controlName: this.LIST_OF_DAYS[5], enable: false, slots: [] },
    { 397: false, id: 397, name: this.LIST_OF_DAYS[6], controlName: this.LIST_OF_DAYS[6], enable: false, slots: [] }
  ];

  timings = ['00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30'];

  private dayStartTimeMoment = moment('00:00', this.timeFormat);
  private dayEndTimeMoment = moment('23:59', this.timeFormat);
  endingMinutes;
  startingMinutes;

  constructor(private fb: FormBuilder, private toaster: Toaster, private toasterService: ConfirmationToasterService) { }

  ngOnChanges(change: SimpleChanges) {

    const weekAvailabilityChange = change['weekAvailability'];
    if (weekAvailabilityChange != null && weekAvailabilityChange.currentValue != null) {
      if (weekAvailabilityChange.currentValue.length !== 0) {
        this.days.forEach(day => {
          const dayDetails: WeekAvailabilityModel = this.weekAvailability.find(d => d.dayOfWeek === day.name);
          day.slots = dayDetails.timeSpanList.map((timeSpan: TimeSpanModel) => {
            return {
              startTime: timeSpan.from,
              endTime: timeSpan.to
            };
          });
          day.enable = !dayDetails.ignoreDayOfweek;
        });
      } else {
        this.days.forEach(day => {
          day.enable = false;
        });
      }
    }

    if (change['inViewMode']) {
      this.currentMode = change['inViewMode'].currentValue;
    }

    if (this.currentMode) {
      this.daysForm.disable();
      this.days.forEach(day => {

          day[day.id] = false;

      
      });
    } else {
      this.daysForm.enable();
    }
  }

  ngOnInit(): void {
    this.LIST_OF_DAYS.forEach(name => {
      this.daysForm.addControl(name, new FormControl(false));
    });
  }

  toggle(selectedId: number): void {
    this.days.forEach(day => {
      if (day.id === selectedId && !this.inViewMode) {
        day[selectedId] = !day[selectedId];
        this.slotForm.reset();
      } else {
        day[day.id] = false;
      }
    });
  }

  validateAddingSlot(existingSlots: Array<any>, newSlot): boolean {

    const startTimeMoment = moment(newSlot.startTime, this.timeFormat);
    const endTimeMoment = moment(newSlot.endTime, this.timeFormat);

    if (!this.isBetweenAndEqualToMoments(startTimeMoment, this.dayStartTimeMoment, this.dayEndTimeMoment, '[]') || !this.isBetweenAndEqualToMoments(endTimeMoment, this.dayStartTimeMoment, this.dayEndTimeMoment, '[]')) {
      this.showValidations('Selected times should be between 00:00 and 23:59');
      return false;
    } else if (endTimeMoment.isSameOrBefore(startTimeMoment)) {
      this.showValidations('End time should be greater than Start time');
      return false;
    } else if (existingSlots.length === 0) {
      return true;
    } else {
      const isOverlapping = existingSlots.some(slot => {
        const existingSlotStartTimeMoment = moment(slot.startTime, this.timeFormat);
        const existingSlotEndTimeMoment = moment(slot.endTime, this.timeFormat);
        return (this.isBetweenAndEqualToMoments(startTimeMoment, existingSlotStartTimeMoment, existingSlotEndTimeMoment, '()') || this.isBetweenAndEqualToMoments(endTimeMoment, existingSlotStartTimeMoment, existingSlotEndTimeMoment, '()'));
      });
      if (isOverlapping) {
        this.showValidations('Timeslot Overlap is not allowed');
      }
      return !isOverlapping;
    }
  }

  private isBetweenAndEqualToMoments(momentToCheck: moment.Moment, m1: moment.Moment, m2: moment.Moment, inclusion: any): boolean {
    return momentToCheck.isBetween(m1, m2, null, inclusion);
  }

  add(day, slotForm: FormGroup): void {
    if (slotForm.valid) {
      const formData = slotForm.value;
      this.days.forEach(d => {
        if (d.id == day.id) {
          if (this.validateAddingSlot(day.slots, formData)) {
            day.slots.push({
              startTime: formData.startTime,
              endTime: formData.endTime
            });
            d[day.id] = false;
            this.slotForm.reset();
          }
        }
      });
    }
  }

  removeSlot(dayIndex: number, index: number) {
    this.toasterService.open({
      cancelText: 'No',
      confirmText: 'Yes',
      message: `Are you sure you want to delete?`
    });
    this.toasterService.confirmed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.days[dayIndex].slots.splice(index, 1);
      }
    });
  }

  positionSlot(startTime: string, endTime: string, enabled: boolean): Array<string> {
    const noOfStartingMinutes = moment.duration(this.getDateObject(startTime).diff(this.getDateObject('00:00'))).asMinutes() / 30;
    const StartingMinutes = Math.floor(noOfStartingMinutes)
    const noOfEndingMinutes = moment.duration(this.getDateObject(endTime).diff(this.getDateObject(startTime))).asMinutes() / 30 + noOfStartingMinutes;

    if (noOfEndingMinutes % 1 != 0) {
      const int_part = Math.trunc(noOfEndingMinutes);
      const float_part = Number((noOfEndingMinutes - int_part).toFixed(2));

      if (float_part >= 0.1 && float_part <= 0.5) {
        this.endingMinutes = int_part+'-5'
      }
      else if(float_part > 0.5){

        const roundedMinutes = Math.round(noOfEndingMinutes);
        this.endingMinutes = roundedMinutes+'-5';

      }

    }
    else {
      this.endingMinutes = Math.round(noOfEndingMinutes)
    }


    if (noOfStartingMinutes % 1 != 0) {
      const int_part = Math.trunc(noOfStartingMinutes);
      const float_part = Number((noOfStartingMinutes - int_part).toFixed(2));

      if (float_part >= 0.1 && float_part <= 0.5) {
        this.startingMinutes = int_part+'-5'
      }
      else if(float_part > 0.5){

        const roundedMinutes = Math.round(noOfStartingMinutes);
        this.startingMinutes = roundedMinutes+'-5';

      }

    }
    else {
      this.startingMinutes = Math.round(noOfStartingMinutes)
    }
    
    const classes = [`pos-slot-top-${this.startingMinutes}`, `pos-bottom-${this.endingMinutes}`];
 
    if (!enabled) {
      classes.push('time-box-disabled');
    }
    return classes;
  }

  enableOrDisableDay(index: number, value: boolean): void {
    this.days[index][this.days[index].id] = false;
    this.days[index].enable = value;
  }

  private getDateObject(time: string): moment.Moment {
    return moment(time, ["HH:mm"]);
  }

  removeAMPM(time: string): string {
    return time.slice(0, -3);
  }

  getSelectedSlots(): any {
    return this.days.map(day => {

      const dayInfo: WeekAvailabilityModel = {
        dayOfWeek: day.name,
        ignoreDayOfweek: !day.enable
      };

      dayInfo.timeSpanList = day.slots.map(slot => {
        return { from: slot.startTime, to: slot.endTime };
      });

      return dayInfo;
    });
  }

  showValidations(msg: string): void {
    this.toastConfig.text = msg;
    this.toaster.open(this.toastConfig);
  }

  showDeleteIcon(dayIndex: number, index: number, inViewMode: boolean): void {

    if (!inViewMode) {
      this.days[dayIndex].slots[index].showDelete = true;
    }
  }

  hideDeleteIcon(dayIndex: number, index: number): void {
    this.days[dayIndex].slots[index].showDelete = false;
  }
}