import { Directive, ElementRef, HostListener, Input, AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { TinMaskPipe } from '../pipes/tin-mask.pipe';
import { NgControl } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';

@Directive({
  selector: '[libTinMask]',
})
export class TinMaskDirective implements AfterViewInit, OnDestroy {
  @Input('libTinMask') isMaskEnabled: string = 'true';

  ngControlSubscription: Subscription;
  constructor(
    private element: ElementRef,
    private tinMaskPipe: TinMaskPipe,
    public ngControl: NgControl
  ) {}

  ngOnDestroy(): void {
    this.ngControlSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.ngControlSubscription = this.ngControl.valueChanges
      .pipe(
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b))
      )
      .subscribe((value) => {
        this.onInputChange();
      });
  }

  @HostListener('input')
  onModelChange() {
    this.onInputChange();
  }

  onInputChange(): void {
    const value = (this.element.nativeElement as HTMLInputElement)
      .value as string;
    if (
      (this.isMaskEnabled === 'true' || this.isMaskEnabled === '') &&
      !!value
    ) {
      let numValue = this.tinMaskPipe.transform(value);
      const finalValue = !!numValue ? numValue : null;
      this.ngControl.control.patchValue(finalValue, { emitEvent: false });
      this.ngControl.control.updateValueAndValidity();
    }
  }
}
