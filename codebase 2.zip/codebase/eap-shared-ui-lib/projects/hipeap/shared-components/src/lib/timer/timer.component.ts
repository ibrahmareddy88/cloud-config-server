import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
  selector: 'lib-timer',
  templateUrl: './timer.component.html',
})
export class TimerComponent implements OnInit {

  counter = timer(0, 1000);
  timer: string;

  constructor() { }

  ngOnInit(): void {
    this.counter.subscribe((x) => {
      this.timer = this.format(x);
    })
  }

  format(seconds: number): any {
    return [
      ('0' + Math.floor(seconds / 3600)).slice(-2),
      ('0' + Math.floor(seconds / 60) % 60).slice(-2),
      ('0' + seconds % 60).slice(-2),
    ].join(' : ');
  }

}
