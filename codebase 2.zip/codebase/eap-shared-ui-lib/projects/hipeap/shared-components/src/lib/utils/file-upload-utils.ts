import * as XLSX from 'xlsx';
import { Injectable } from '@angular/core';
import { RowErrors } from '../models/rowErrors';
import * as FileSaver from 'file-saver';
import { GenericDatesService } from '@hipeap/shared-state';



@Injectable(
    {providedIn: 'root'}
)
export class FileUploadUtil {
  constructor(private dateServe: GenericDatesService) {}

  private columnHeaders: Map<string, string> ;

  private validationColumns: Map<string, string>;
 
  doNothing: boolean = false;

  private  EXCEL_TYPE: string = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  private  EXCEL_EXTENSION = '.xlsx';

  private getColumnHeaders(ws: any): string[] {
    this.doNothing = !this.doNothing;

    try {
      const headers: string[] = [];
      const columnCount = XLSX.utils.decode_range(ws['!ref']).e.c + 1;

      let count = 0;
      while (count < columnCount) {
        headers[count] = ws[`${XLSX.utils.encode_col(count)}1`].v;
        count += 1;
      }

      return headers;
    } catch (err) {
      return [];
    }
  }

  private getWorkSheet(workbook: any): any {
    this.doNothing = !this.doNothing;

    const firstSheetName = workbook.SheetNames[0];
    return workbook.Sheets[firstSheetName];
  }

  private getExcelAsJson(workbook: any): any {
    const jsonData = XLSX.utils.sheet_to_json(this.getWorkSheet(workbook), {
      raw: true,
      rawNumbers: true,
      blankrows: true
    });
    return JSON.parse(JSON.stringify(jsonData));
  }

  public getRowItems(workbook: any,columnHeaders: Map<string, string>, validationColumns: Map<string, string>): Map<string, any> {
    this.columnHeaders=columnHeaders;
    this.validationColumns=validationColumns;
    const jsonData = this.getExcelAsJson(workbook);
    const rowItems: any[] = [];
    let invalidRows: RowErrors[] = [];
    invalidRows = this.getFileStructureValidation(workbook);
    if (invalidRows.length === 0) {
      jsonData.forEach((data: any, index: number) => {
        const rowItem: any = this.rowItem(data);
        let rowErrors: string[] = [];
        if (this.isRowEmpty(rowItem)) {
          rowErrors.push('Empty row / Invalid File Format');
        } else {
          rowErrors = this.getRowDataValidationErrors(rowItem);
        }
        if (rowErrors.length > 0) {
          const rowError: RowErrors = this.buildRowError(index, rowErrors);
          invalidRows.push(rowError);
        } else {  
          rowItems.push(rowItem);
        }
      });
    }
    if (rowItems.length === 0 && invalidRows.length === 0) {
      const noDataError: RowErrors = {};
      noDataError.rowId = 'EMPTY_FILE';
      noDataError.error = 'Selected files contain no valid data rows';
      invalidRows.push(noDataError);
    }
    const rowMap: Map<string, any> = new Map();
    rowMap.set('validRows', rowItems);
    rowMap.set('invalidRows', invalidRows);
    return rowMap;
  }

  private getFileStructureValidation(workbook: any) {
    const workSheet = this.getWorkSheet(workbook);
    let excelHeaders: string[] = this.getColumnHeaders(workSheet);
    let headerConsts: string[] = Array.from(this.columnHeaders.keys());
    const HEADER_ERROR: string = 'HEADER_ERROR';
    let invalidRows: RowErrors[] = [];

    headerConsts = headerConsts.map((ele) => ele.toLowerCase());
    excelHeaders = excelHeaders.map((ele) => ele.toLowerCase());

    if (excelHeaders.length !== headerConsts.length) {
      invalidRows = this.getFileRowErrors(HEADER_ERROR, 'Invalid File Format', invalidRows);
    }
    headerConsts.forEach((element: string) => {
      if (!excelHeaders.includes(element)) {
        invalidRows = this.getFileRowErrors(HEADER_ERROR, `File Header Missing ${element.toUpperCase()}`, invalidRows);
      }
    });
    headerConsts.forEach((element: string, index: number) => {
      if (headerConsts[index] !== excelHeaders[index]) {
        invalidRows = this.getFileRowErrors(HEADER_ERROR, `Invalid Header Name ${element.toUpperCase()}`, invalidRows);
      }
    });
    return invalidRows;
  }

  private getFileRowErrors(errorHeader: string, errorMsg: string, invalidRows: RowErrors[]): RowErrors[] {
    this.doNothing = !this.doNothing;

    const rowError: RowErrors = {};
    rowError.rowId = errorHeader;
    rowError.error = errorMsg;
    invalidRows.push(rowError);
    return invalidRows;
  }

  private getRowDataValidationErrors(item: any): string[] {
    this.doNothing = !this.doNothing;
    const errorMsg: string[] = [];
    for (let [key, value] of this.validationColumns) {
      if(!item[value]) {
        errorMsg.push(key+' should not be null');
      }           
  } 
    return errorMsg;
  }

  public rowItem(data: any): any{
    const rowItem: any = {};
    for (const key in data) {
        let value = typeof data[key] === 'string' ? data[key].trim() : data[key];
         if( this.columnHeaders.has(key)){
            rowItem[this.columnHeaders.get(key)] = value;
         }
    }
    return rowItem;
}

  private buildRowError(index: number, rowErrors: string[]): RowErrors {
    this.doNothing = !this.doNothing;
    const rowError: RowErrors = {};
    rowError.rowId = String(index + 2);
    rowError.error = rowErrors.join('||');
    return rowError;
  }

  private isRowEmpty(item: any): boolean {
    this.doNothing = !this.doNothing;
    return JSON.stringify(item) === '{}';
  }

  private getHeaderValue(key: string): string | undefined {
    return this.columnHeaders.get(key)?.trim().toLowerCase();
  }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    console.log('worksheet',worksheet);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    //const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], {
      type: this.EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName +  this.dateServe.dateByFormat(new Date(),'yyyyMMddHHmmss') + this.EXCEL_EXTENSION);
  }
}
