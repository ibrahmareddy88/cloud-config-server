import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';
import { GenericDatesService } from '@hipeap/shared-state';
import * as momentTz from 'moment-timezone';
import {Moment} from 'moment'



@Component({
  selector: 'lib-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss']
})
export class DateComponent extends BaseAtomComponent implements OnInit {

  constructor(private dateServ: GenericDatesService) {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }

  public get minDate(): string {
    if (this.field?.minDateControlName &&
      this.rowFormGroup.get(this.field?.minDateControlName)?.get('value')?.value) {
      if (momentTz.tz.guess().indexOf('America')!==-1) {
        let date = this.dateServ.formatDate(this.rowFormGroup.get(this.field?.minDateControlName)?.get('value')?.value)
        return this.dateServ.calendarMinDate(this.dateServ.calendarMinDateIncDays(date, 1))
      } else {
        return this.dateServ.calendarMinDate(this.rowFormGroup.get(this.field?.minDateControlName)?.get('value')?.value)
      }
    } else if (this.field?.minDate) {
      return this.dateServ.calendarMinDate(this.field?.minDate);
    }
    return '1900-01-01';
  }

  public get maxDate(): string {
    if (this.field?.maxDateControlName &&
      this.rowFormGroup.get(this.field?.maxDateControlName)?.get('value')?.value) {
      if (momentTz.tz.guess().indexOf('America')!==-1) {
        let date = this.dateServ.formatDate(this.rowFormGroup.get(this.field?.maxDateControlName)?.get('value')?.value)
        return this.dateServ.calendarMinDate(this.dateServ.calendarMinDateIncDays(date, 1))
      } else {
        return this.dateServ.calendarMinDate(this.rowFormGroup.get(this.field?.maxDateControlName)?.get('value')?.value)
      }
    } else if (this.field?.maxDate) {
      return this.dateServ.calendarMinDate(this.field?.maxDate);
    }
    return '9999-12-31';
  }

}
