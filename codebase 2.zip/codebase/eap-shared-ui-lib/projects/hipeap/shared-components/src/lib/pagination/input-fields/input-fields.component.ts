import { Component, OnInit, Input } from '@angular/core';
import { Field, FieldType } from '../../models/field';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'lib-input-fields',
  templateUrl: './input-fields.component.html',
  styleUrls: ['./input-fields.component.scss']
})
export class InputFieldsComponent implements OnInit {
  @Input() field: Field;
  @Input() formGroup: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

  get fieldType(): typeof FieldType{
    return FieldType;
  }
}
