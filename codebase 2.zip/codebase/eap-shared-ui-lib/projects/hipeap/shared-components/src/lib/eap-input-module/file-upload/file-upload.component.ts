import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormControlName } from '@angular/forms';
import { EmitterData } from '../../models/field';

@Component({
  selector: 'lib-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

  public uploadDocumentFormGroup!: FormGroup;

  uploadedFile : File;

  @Input() fieldEmit?: boolean = false;

  @Output() uploadEmitter = new EventEmitter<EmitterData>();
  @Output() cancelEmitter = new EventEmitter<EmitterData>();

  calculatedFileSize: any = null;

  fileName: string = "";

  errorMessage: any = {
    fileSizeError: {
      status: false,
      message: "File exceeds limit size",
    },
  };

  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.uploadDocumentFormGroup = this.getUploadDocumentForm();
  }

  clearForm() {
    this.uploadDocumentFormGroup.reset();
    this.errorMessage.fileSizeError.status = false;
    this.calculatedFileSize = null;
  }

  private getUploadDocumentForm(): FormGroup {
    return this.fb.group({
      uploadedFile: new FormControl('', [Validators.required]),
      fileDescription: new FormControl('',),
      fileName: new FormControl('',),
    });
  }


  getFileDetails(event) {
    this.errorMessage.fileSizeError.status = false;
    this.calculatedFileSize = null;
    this.fileName = event.target.files[0].name;
    this.uploadedFile = event.target.files[0];
    var size = event.target.files[0].size;
    this.calculatedFileSize =  (size / 1024 / 1024).toFixed(2);
    
    if (this.calculatedFileSize > 10) {
      this.errorMessage.fileSizeError.status = true;
    }
  }

  emit() {
    if (this.fieldEmit === true) {
      this.uploadEmitter.emit({ uploadFile: this.uploadedFile, data: this.uploadDocumentFormGroup, name: this.fileName });
    }
  }

  cancelEmit() {
    if (this.fieldEmit === true) {
      this.cancelEmitter.emit({ closeForm: true });
    }
  }

}
