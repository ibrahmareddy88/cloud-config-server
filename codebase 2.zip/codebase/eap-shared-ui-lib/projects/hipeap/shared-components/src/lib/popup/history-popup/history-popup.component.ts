import { Component, OnInit, Input } from '@angular/core';
import { trigger, state, transition, animate, style } from '@angular/animations';
import { TableData } from '../../models/table-data';

@Component({
  selector: 'lib-history-popup',
  templateUrl: './history-popup.component.html',
  styleUrls: ['./history-popup.component.scss'],
  animations: [
    trigger('click', [
      state('show', style({ height: '*' })),
      state('hide', style({ height: '0' })),
      transition('hide <=> show', [animate('300ms ease-in-out')])
    ])
  ]
})
export class HistoryPopupComponent implements OnInit {

  @Input() buttonName:string;
  @Input() tableConfig:TableData;
  @Input() tableArray:any[];
  
  show: boolean = false;

  state = 'hide';

  isRefreshed: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  

  
  toggle() {
    this.show = !this.show;
  }

  toggleMessagePopover() {
    if (this.state === 'hide') {
      this.state = 'show';
    } else {
      this.state = 'hide';
    }
  }
  
  popUpData(){
    this.toggle();
    this.toggleMessagePopover();
    this.isRefreshed = true;
  }
}
