import { Component, EventEmitter, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EmitterData, Field, FieldType, Operator } from '../../models/field';

@Component({
  selector: 'lib-base-atom',
  templateUrl: './base-atom.component.html',
  styleUrls: ['./base-atom.component.scss']
})
export class BaseAtomComponent implements OnInit {

  @Input() field: Field;
  @Input() rowFormGroup: FormGroup;
  @Input() fieldEmitter: EventEmitter<EmitterData>;


  constructor() { }

  ngOnInit(): void {
  }

  get fieldGroup(): FormGroup{
    return this.rowFormGroup.get(this.field.name) as FormGroup;
  }

  emit(data: any){
    this.fieldEmitter.emit({name: this.field.name, currentValue: data, data: this.rowFormGroup});
  }

  handleControls(){
    this.enableControls();
    this.activateControls();
    this.setErrorMsg();
  }
  setErrorMsg() {
    if (this.field.errorsHandle) {
      const currentField = this.rowFormGroup.get(this.field.name).get('value').value;
      const externalField = this.rowFormGroup.get(this.field.errorsHandle.errorCheckControlName).get('value').value;
      if (currentField && externalField) {
        switch (this.field.errorsHandle.operator) {
          case Operator.EQUALS:
            if (currentField === externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          case Operator.GREAERTHAN:
            if (currentField > externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          case Operator.GREAERTHANOREQUALS:
            if (currentField >= externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          case Operator.LESSTHAN:
            if (currentField < externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          case Operator.LESSTHANOREQUALS:
            if (currentField <= externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          case Operator.NOTEQUALS:
            if (currentField !== externalField) {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors({
                invalid: true
              });
            } else {
              this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            }
            break;
          default:
            this.rowFormGroup.get(this.field.errorsHandle.errormsgTargetPath).get('value').setErrors(null);
            break;
        }
      }
    }
  }

  enableControls() {
    if (this.field.enableMap?.size > 0) {
      this.field.enableMap.forEach((value, key) => {
        let enable = false;
        let sourceValue = null;
        if(this.field?.type == FieldType.CHECKBOX){
        sourceValue = this.rowFormGroup.get(this.field?.name)?.get('value')?.value === '' ? false : this.rowFormGroup.get(this.field?.name)?.get('value')?.value;
        }else{
          sourceValue = this.rowFormGroup.get(this.field?.name)?.get('value')?.value;
        }
        if (key === sourceValue) {
          enable = true
        }
          this.enbleFieldControlls(value, enable)
      })
    }

  }
  enbleFieldControlls(value: string[], enable: boolean) {
    value.forEach(name => {
      if (enable) {
        this.rowFormGroup.get(name)?.get('value').enable();
      } else {
        this.rowFormGroup.get(name)?.get('value').setValue(null);
        this.rowFormGroup.get(name)?.get('value').setErrors(null);
        this.rowFormGroup.get(name)?.get('value').disable();
      }
    });
  }

  activateControls(){
    if (this.field.activateMap?.size > 0) {
      this.field.activateMap.forEach((value, key) => {
        let activate = false;
        if (key === this.rowFormGroup.get(this.field?.name)?.get('value')?.value) {
          activate = true;
        }
          this.activateFieldControlls(value, activate)
      })
    }
  }

  activateFieldControlls(values: string[], activate: boolean) {
    values?.forEach(name => {
      if(activate){
      this.rowFormGroup.get(name)?.get('enable').setValue(activate);
      }else{
        this.rowFormGroup.get(name)?.get('enable').setValue(false);
        this.rowFormGroup.get(name)?.get('value').setValue(null);
        this.rowFormGroup.get(name)?.get('value').setErrors(null);
      }
    });
  }

}

