import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { NavigationStart, Router } from '@angular/router';
import { SubSink } from 'subsink';
import { InlineToaster } from './inline-toaster.model';
import { InlineToasterService } from './inline-toaster.service';

@Component({
    selector: 'lib-inline-toaster',
    templateUrl: './inline-toaster.component.html',
    styleUrls: ['./inline-toaster.component.scss'],
    animations: [
        trigger('progress', [
            state('void', style({
                width: 0
            })),
            transition('void => *', animate('{{duration}}', style({ width: '100%' })))
        ])
    ]
})
export class InlineToasterComponent implements OnInit {

    @Output() toastersClosed = new EventEmitter<boolean>();
    @Input() clearOnRouteChange = true;
    inlineToasters: Array<any> = [];
    private subs = new SubSink();

    constructor(private inlineToasterService: InlineToasterService, private router: Router) { }

    ngOnInit(): void {
        this.subs.add(this.inlineToasterService.getInlineToaster()
            .subscribe(inlineToaster => {
                this.inlineToasters.push(inlineToaster);
                this.sendToasterVisibilityStatus();
                if (inlineToaster.autoClose) {
                    setTimeout(() => {
                        this.remove(inlineToaster);
                    }, inlineToaster.duration);
                }
            }),
            this.router.events.subscribe(event => {
                if (event instanceof NavigationStart) {
                    if(!this.clearOnRouteChange) return;
                    this.inlineToasters = [];
                    this.sendToasterVisibilityStatus();
                }
            }));
    }

    remove(toaster: InlineToaster) {
        this.inlineToasters = this.inlineToasters.filter(it => it != toaster);
        this.sendToasterVisibilityStatus();
    }

    private sendToasterVisibilityStatus() {
        if (this.inlineToasters.length === 0) {
            this.toastersClosed.emit(true);
        } else {
            this.toastersClosed.emit(false);
        }
    }

    ngOnDestroy() {
        this.subs.unsubscribe();
    }
}
