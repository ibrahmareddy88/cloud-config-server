import { Component, OnInit } from '@angular/core';
import { BaseAtomComponent } from '../base-atom/base-atom.component';

@Component({
  selector: 'lib-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.scss'],
})
export class TextboxComponent extends BaseAtomComponent implements OnInit {
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.handleControls();
  }
}
