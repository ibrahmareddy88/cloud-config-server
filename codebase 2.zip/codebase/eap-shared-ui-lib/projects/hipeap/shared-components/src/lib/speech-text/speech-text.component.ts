import { Component, Input, OnChanges, OnInit, SimpleChanges, OnDestroy } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { merge, Observable, of, Subject } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { SpeechError } from './model/speech-error';
import { SpeechEvent } from './model/speech-event';
import { SpeechNotification } from './model/speech-notification';
import { SpeechRecognizerService } from './service/speech-recognizer.service';

@Component({
  selector: 'lib-speech-text',
  templateUrl: './speech-text.component.html',
  styleUrls: ['./speech-text.component.scss'],
  providers: [
    SpeechRecognizerService,
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: SpeechTextComponent,
    },
  ],
})
export class SpeechTextComponent
  implements OnInit, OnChanges, ControlValueAccessor, OnDestroy {
  clearValue: boolean;
  finalEditedText: string;

  totalText: string = '';
  @Input() disabled = false;
  @Input() label: string;
  @Input() maxLength = 10000;
  @Input() rows = 5;

  currentLanguage = 'en-US';
  totalTranscript?: string;
  intermTranscript?: string;
  transcript$?: Observable<string>;
  listening$?: Observable<boolean>;
  errorMessage$?: Observable<string>;
  defaultError$ = new Subject<string | undefined>();
  listen = false;

  constructor(private speechRecognizer: SpeechRecognizerService) {}

  onChange = (_: any) => {};
  onTouch = () => {};

  writeValue(obj: any): void {
    this.totalText = obj || '';
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouch = fn;
  }
  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
    if (this.disabled && this.speechRecognizer.isListening) this.stop();
  }

  valueModelChange() {
    this.onChange(this.totalText);
    this.intermTranscript = this.totalText;
    this.totalTranscript = this.totalText;
    this.onTouch();
  }

  ngOnInit(): void {
    const webSpeechReady = this.speechRecognizer.initialize(
      this.currentLanguage
    );
    if (webSpeechReady) {
      this.initRecognition();
      this.listening$.subscribe((val) => {
        this.listen = val;
      });
    } else {
      this.errorMessage$ = of(
        'Your Browser is not supported. Please try Google Chrome.'
      );
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.disabled && this.speechRecognizer.isListening) {
      this.stop();
    }
  }

  start(): void {
    if (this.speechRecognizer.isListening) {
      this.stop();
      return;
    }
    this.defaultError$.next(undefined);
    this.speechRecognizer.start();
  }

  stop(): void {
    this.speechRecognizer.stop();
  }

  private initRecognition(): void {
    this.transcript$ = this.speechRecognizer.onResult().pipe(
      tap((notification) => {
        this.processNotification(notification);
      }),
      map((notification) => notification.content || '')
    );

    this.listening$ = merge(
      this.speechRecognizer.onStart(),
      this.speechRecognizer.onEnd()
    ).pipe(map((notification) => notification.event === SpeechEvent.Start));

    this.errorMessage$ = merge(
      this.speechRecognizer.onError(),
      this.defaultError$
    ).pipe(
      map((data) => {
        if (data === undefined) {
          return '';
        }
        if (typeof data === 'string') {
          return data;
        }
        let message;
        switch (data.error) {
          case SpeechError.NotAllowed:
            message = `Cannot run the demo.
            Your browser is not authorized to access your microphone.
            Verify that your browser has access to your microphone and try again.`;
            break;
          case SpeechError.NoSpeech:
            message = `No speech has been detected. Please try again.`;
            break;
          case SpeechError.AudioCapture:
            message = `Microphone is not available. Plese verify the connection of your microphone and try again.`;
            break;
          default:
            message = '';
            break;
        }
        return message;
      })
    );
  }

  private processNotification(notification: SpeechNotification<string>): void {
    const message = notification.content?.trim() || '';
    this.intermTranscript = this.totalTranscript
      ? `${this.totalText}' '${message}`
      : notification.content;
    if (
      (this.totalText.length === 0 || !this.totalText.endsWith('...')) &&
      notification.event > SpeechEvent.FinalContent
    )
      this.totalText += '...';
    if (notification.event === SpeechEvent.FinalContent && !this.disabled) {
      this.totalText = this.totalText.substring(0, this.totalText.length - 3);
      this.totalTranscript = this.totalTranscript
        ? `${this.totalText} ${message}`
        : notification.content;
      this.totalText = this.totalTranscript;
      this.onChange(this.totalText);
      this.onTouch();
    }
  }

  clearSpeechText() {
    this.clearValue = false;
    this.finalEditedText = '';
    this.totalTranscript = this.finalEditedText;
    this.intermTranscript = this.finalEditedText;
    this.totalText = '';
    this.onChange(this.totalText);
  }

  ngOnDestroy(): void {
    if (this.speechRecognizer.isListening) this.stop();
  }
}
