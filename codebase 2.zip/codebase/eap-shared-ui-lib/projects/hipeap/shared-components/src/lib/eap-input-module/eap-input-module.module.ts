import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseInputAtomComponent } from './atoms/base-input-atom/base-input-atom.component';
import { TextboxInputComponent } from './atoms/textbox-input/textbox-input.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownInputComponent } from './atoms/dropdown-input/dropdown-input.component';
import { PhoneMaskDirective } from './directives/phone-mask.directive';
import { ZipMaskDirective } from './directives/zip-mask.directive';
import { NumericDirective } from './directives/numeric.directive';
import { TextareaInputComponent } from './atoms/textarea-input/textarea-input.component';
import { DateInputComponent } from './atoms/date-input/date-input.component';
import { GenericDatesService } from '@hipeap/shared-state';
import { RadioInputComponent } from './atoms/radio-input/radio-input.component';
import { DecimalInputComponent } from './atoms/decimal-input/decimal-input.component';
import { CheckboxInputComponent } from './atoms/checkbox-input/checkbox-input.component';
import { ErrorMessageComponent } from './atoms/error-message/error-message.component';
import { CheckboxGroupInputComponent } from './atoms/checkbox-group-input/checkbox-group-input.component';
import { TimeInputComponent } from './atoms/time-input/time-input.component';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { MultiSelectInputComponent } from './atoms/multi-select-input/multi-select-input.component';
import { LocalDateValueAccessorModule } from 'angular-date-value-accessor';
import { LengthRestrictorDirective } from './directives/length-restrictor.directive';
import { TimeTwentyfourInputComponent } from './atoms/time-twentyfour-input/time-twentyfour-input.component';
import { ValueRestrictorDirective } from './directives/value-restrictor.directive';
import { FileUploadComponent } from './file-upload/file-upload.component';

@NgModule({
  declarations: [
    BaseInputAtomComponent,
    TextboxInputComponent,
    DropdownInputComponent,
    PhoneMaskDirective,
    ZipMaskDirective,
    NumericDirective,
    TextareaInputComponent,
    DateInputComponent,
    RadioInputComponent,
    DecimalInputComponent,
    CheckboxInputComponent,
    ErrorMessageComponent,
    CheckboxGroupInputComponent,
    TimeInputComponent,
    MultiSelectInputComponent,
    LengthRestrictorDirective,
    TimeTwentyfourInputComponent,
    ValueRestrictorDirective,
    FileUploadComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgxMaterialTimepickerModule,
    SelectDropDownModule,
    LocalDateValueAccessorModule
  ],
  exports: [
    TextboxInputComponent,
    DropdownInputComponent,
    TextareaInputComponent,
    DateInputComponent,
    RadioInputComponent,
    DecimalInputComponent,
    CheckboxInputComponent,
    CheckboxGroupInputComponent,
    TimeInputComponent,
    MultiSelectInputComponent,
    TimeTwentyfourInputComponent,
    FileUploadComponent,
  ],
  providers: [
    GenericDatesService
  ]
})
export class EapInputModuleModule { }
