export interface GroupDashboardResponse {
    head_cbg?: any;
    head_radio?: any;
    head_dd: any;
    head_d: any;
}
