import { Directive, OnInit, OnDestroy } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[libZipMask]'
})
export class ZipMaskDirective implements OnInit, OnDestroy {

  ngControlSubscription: Subscription;
  constructor(public ngControl: NgControl) {

  }
  ngOnDestroy(): void {
   this.ngControlSubscription.unsubscribe();
  }

  ngOnInit(): void {
    if (this.ngControl.control.value){
      this.onInputChange(this.ngControl.control.value);
    }
    this.ngControlSubscription = this.ngControl.valueChanges.subscribe(value => {
      this.onInputChange(value);
    });
  }

  onInputChange(event): void {
    if (event) {
      let newVal = event.replace(/\D/g, '');
      if (newVal.length === 0) {
        newVal = '';
      } else if (newVal.length <= 5) {
        newVal = newVal;
      } else if (newVal.length <= 6) {
        newVal = newVal.replace(/^(\d{0,5})(\d{0,4})$/, '$1-$2');
      }
      else {
        newVal = newVal.substring(0, 9);
        newVal = newVal.replace(/^(\d{0,5})(\d{0,4})$/, '$1-$2');
      }
      this.ngControl.valueAccessor.writeValue(newVal);
    }
  }
}
