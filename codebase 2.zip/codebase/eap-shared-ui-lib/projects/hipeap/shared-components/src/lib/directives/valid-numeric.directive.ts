import { Directive, ElementRef, HostListener, Input } from "@angular/core";
import { Subscription } from "rxjs";

@Directive({
    selector: '[libValidNumericValue]',
  })
  export class ValidNumericValueDirective  {

    @Input() restrictedValues: string[];
    ngControlSubscription: Subscription;
    constructor(private element: ElementRef) { }
  
    @HostListener('keydown',['$event'])
    onKeyPress(event:KeyboardEvent) {
      if (this.restrictedValues.includes(event.key)) {
        event.preventDefault();
        return false;
      }else{
        return true;
      }    
    }
  }