import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '@hipeap/shared-state';
import { Observable, of } from 'rxjs';
import { ConfigLoader } from '../security/config-loader.service';

@Injectable({
    providedIn: 'root',
})
export class UserService {
    constructor(private httpClient: HttpClient, private config: ConfigLoader) { }

    getUserData(): Observable<User> {
        // call user service here
        return of({
            "roles": [
                {
                    "primary": true,
                    "restrictions": [
                        {
                            "_id": 1,
                            "resourceCode": "ReadOnly_User_Setup",
                            "description": "Read Only User Setup",
                            "accessLevel": "readonly"
                        },

                        {
                            "_id": 2,
                            "resourceCode": "HIDE_ACCOUNTS",
                            "description": "No Access to accounts for this role",
                            "accessLevel": "HIDDEN"
                        }
                    ]
                }
            ]
        });
    }
}
