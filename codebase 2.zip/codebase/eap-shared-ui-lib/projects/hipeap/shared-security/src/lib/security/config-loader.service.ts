import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Config } from '../model/config.model';



export let config: Config;

@Injectable({
  providedIn: 'root'
})
export class ConfigLoader {
  private readonly CONFIGURATION_URL = './assets/config/config.json';
  public configuration!: Config;

  constructor(private http: HttpClient) {}

  public loadConfiguration(): any  {
    return this.http
      .get(this.CONFIGURATION_URL)
      .toPromise()
      .then((configuration: any) => {
        this.configuration = configuration;
        config = this.configuration;
        return configuration;
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  getConfiguration(): Config {
    return this.configuration;
  }
}
