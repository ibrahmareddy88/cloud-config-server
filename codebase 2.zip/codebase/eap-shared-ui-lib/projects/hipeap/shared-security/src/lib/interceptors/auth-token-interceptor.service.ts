import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Inject, Injectable } from "@angular/core";
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthTokenInterceptorService implements HttpInterceptor {

    ignoreUrls: string[] = [];

    constructor(@Inject(SESSION_STORAGE) private session: StorageService) {
    }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        const ignoreAuthToken = this.ignoreUrls.some(url => url.includes(req.url));

        if (ignoreAuthToken) {
            return next.handle(req);
        }

        const requestWithAuthToken = req.clone({
            setHeaders: {
                'Authorization': `Bearer ${this.session.get('token')}`
            }
        });

        return next.handle(requestWithAuthToken);
    }
}
