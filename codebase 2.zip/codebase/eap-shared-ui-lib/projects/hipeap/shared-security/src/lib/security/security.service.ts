import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { ConfigLoader } from './config-loader.service';

@Injectable({
    providedIn: 'root'
})
export class SecurityService {

    constructor(@Inject(SESSION_STORAGE) private sessionStorage: StorageService, private http: HttpClient, private config: ConfigLoader, private router: Router) { }

    private _loginUrl = this.config.getConfiguration().authenticateUrl + '/login';
    private _logoutUrl = this.config.getConfiguration().authenticateUrl + '/logout';


    login(): boolean | void {
        this.sessionStorage.clear();
        const locationNoHash = location.href.replace('#', '');
        const searchParams = new URL(locationNoHash).searchParams;
        const token = searchParams.get('tokenValue');

        if (token != null) {
            this.sessionStorage.set('token', token);
            return true;
        } else
            location.href = this._loginUrl;
    }

    logout() {
        this.http.get(this._logoutUrl).subscribe(_ => {
            this.sessionStorage.clear();
            this.router.navigateByUrl('/logout');
        });
    }


}
