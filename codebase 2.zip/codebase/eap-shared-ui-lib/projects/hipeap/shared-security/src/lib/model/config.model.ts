export type Config = {
  apiUrl?: string;
  env?: string;
  groupsUrl?: string;
  adminUrl?:string;
  reportsUrl?: string;
  authenticateUrl?: string;
  providerUrl?: string;
  providerSearchUrl?: string;
  memberUrl?: string;
  sharedUrl?: string;
  cgrUrl?: string;
  consultationUrl?: string;
  referralUrl?: string;
};
