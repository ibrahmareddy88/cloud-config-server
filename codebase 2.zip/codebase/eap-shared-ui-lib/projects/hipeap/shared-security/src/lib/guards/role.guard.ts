import { Injectable } from '@angular/core';
import { CanLoad, Route, Router, UrlTree, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { GlobalUserDataService, UserRestrictions } from '@hipeap/shared-state';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { UserService } from '../services/user.service';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard implements CanLoad, CanActivate {
  constructor(
    private globalUserData: GlobalUserDataService,
    private userRestrictions: UserRestrictions,
    private userService: UserService,
    private router: Router
  ) { }

  canLoad(route: Route): Observable<boolean | UrlTree> {
    const role: string | null = route.data && route.data.role;
    return this.checkAccessDetails(role);
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> {
    const role: string | null = route.data && route.data.role;
    return this.checkAccessDetails(role);
  }

  checkAccessDetails(role: string): Observable<boolean | UrlTree> {
    if (this.globalUserData.getRestrictions() != null) {
      return of(this.allowOrRestrict(this.userRestrictions.checkRouteAccess(role)));
    }

    return this.userService.getUserData().pipe(
      map(
        (data) => {
          this.globalUserData.setUserInformation(data);
          return this.allowOrRestrict(this.userRestrictions.checkRouteAccess(role));
        },
        catchError(() => of(false))
      )
    );
  }

  allowOrRestrict(accessFlag: boolean): boolean | UrlTree {
    return accessFlag ? accessFlag : this.router.parseUrl('/unauth');
  }
}
