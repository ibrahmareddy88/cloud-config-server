#!/bin/bash

yarn install

# dependencies for shared-security service
cd ./projects/hipeap/shared-security
yarn install

#go back to base directory
cd ../../..

ng build @hipeap/shared-security --prod
