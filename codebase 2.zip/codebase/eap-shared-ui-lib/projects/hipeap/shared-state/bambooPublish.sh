#!/bin/bash

echo "This is meant to be run after the prodBuild script"

cd ./dist/hipeap/shared-components

echo "Setting up npmrc file."
git config --global url."https://".insteadOf git://
git config --global http.sslverify false
npm config set strict-ssl false
curl -o .npmrc -u$bamboo_artifactory_override_resolver_username:$bamboo_artifactory_override_resolver_password -k "https://artifactory.anthem.com/artifactory/api/npm/npm-snapshot/auth/anthem"
echo "@hipeap:registry=https://artifactory.anthem.com:443/artifactory/api/npm/npm-snapshot/" >> .npmrc
echo "npmrc file setup"
cat ./.npmrc

npm publish || true