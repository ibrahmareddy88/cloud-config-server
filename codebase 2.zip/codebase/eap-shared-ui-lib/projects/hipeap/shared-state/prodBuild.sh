#!/bin/bash

yarn install

# dependencies for shared-security service
cd ./projects/hipeap/shared-state
yarn install

#go back to base directory
cd ../../..

ng build @hipeap/shared-state --prod
