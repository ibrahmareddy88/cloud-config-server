// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  env: 'local',
  production: false,
  sharedServiceURL: 'http://localhost:9090/eap/shared',
  groupServiceURL: 'http://localhost:9091/eap/groups',
  adminServiceURL: 'http://localhost:9092/eap/admin',
  reportServiceURL: 'http://localhost:9093/eap/reports',
  providerSearchServiceURL: 'http://localhost:9095/eap/providersearch',
  integrationServiceURL: 'http://localhost:9096/eap/integration',
  providerServiceURL: 'http://localhost:9097/eap/provider',
  memberServiceURL:'http://localhost:9098/eap/member',
  questionnaireServiceURL: 'http://localhost:9099/eap-questionnaire-service/fhir',
  templateServiceURL:'http://localhost:9101/eap/template',
  referralServiceURL: 'http://localhost:9100/eap/referral',
  cgrServiceURL: 'http://localhost:9102/eap/cgr',
  consultationServiceURL: "http://localhost:9103/eap/consultation",
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
