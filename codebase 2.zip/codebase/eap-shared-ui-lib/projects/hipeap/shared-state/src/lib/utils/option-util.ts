export class OptionUtil {
  static getCodesByLabelKeyWord(
    keyWord: string,
    optionMap: {optionKey: string, optionValues: {code: string, label: string}[]}[],
    fieldName: string
  ): (string | number)[] {
    const optionValues = optionMap.find(
      (o: {optionKey: string, optionValues: {code: string, label: string}[]}) => o.optionKey === fieldName
    )?.optionValues;
    return optionValues
      .filter((opt: {code: string, label: string}) =>
        opt.label.toLowerCase().includes(keyWord?.toLowerCase())
      )
      .map((option) => option.code);
  }
}
