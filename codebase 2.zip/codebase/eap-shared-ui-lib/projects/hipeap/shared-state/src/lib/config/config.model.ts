import { environment } from '../environments/environment';

export type Config = {
  apiUrl: string;
  env: string;
  rolesUrl: string;
  usersUrl: string;
  restrictionsUrl: string;
  codesUrl: string;
};
export const context = {
  groupService: 'eap/groups',
  sharedService: 'eap/shared',
  adminService: 'eap/admin',
  reportService: 'eap/report',
  providerSearchService: 'eap/providersearch',
  providerService: 'eap/provider',
  integrationService: 'eap/integration',
  memberService: 'eap/member',
  templateService: 'eap/template',
  referralService: 'eap/referral',
  cgrService: 'eap/cgr',
  questionnaireService: 'eap-questionnaire-service/fhir',
  consultationService: 'eap/consultation',
};

export const getConfiguration = (contextPath: string): string => {
  if (window.location.origin.includes('localhost')) {
    switch (contextPath) {
      case context.groupService:
        return environment.groupServiceURL;
      case context.sharedService:
        return environment.sharedServiceURL;
      case context.adminService:
        return environment.adminServiceURL;
      case context.reportService:
        return environment.reportServiceURL;
      case context.providerSearchService:
        return environment.providerSearchServiceURL;
      case context.providerService:
        return environment.providerServiceURL;
      case context.integrationService:
        return environment.integrationServiceURL;
      case context.memberService:
        return environment.memberServiceURL;
      case context.templateService:
        return environment.templateServiceURL;
      case context.referralService:
        return environment.referralServiceURL;
      case context.cgrService:
        return environment.cgrServiceURL;
      case context.questionnaireService:
        return environment.questionnaireServiceURL;
      case context.consultationService:
        return environment.consultationServiceURL;
      default:
        return '';
    }
  }
  return `${window.location.origin}/${contextPath}`;
};
