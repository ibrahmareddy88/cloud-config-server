import { Injectable } from "@angular/core";
import { Restriction, Role, User } from '../models/user.model';


@Injectable({
    providedIn: 'root'
})
export class GlobalUserDataService {

    private _userinformation: User;
    private _restrictions: Restriction[];

    setUserInformation(user: User) {
        this._userinformation = user;
        this._restrictions = user.roles.filter((role: Role) => role.primary)[0].restrictions;
    }

    getRestrictions(): Restriction[] {
        return this._restrictions;
    }

    getUserInformation(): User {
        return this._userinformation;
    }
}