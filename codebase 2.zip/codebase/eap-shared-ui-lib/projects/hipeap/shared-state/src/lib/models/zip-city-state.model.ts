export interface ZipCityStateModel {
    zipCode: number;
    city: string;
    stateCode: string;
    state: string;
}