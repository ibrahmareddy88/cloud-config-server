import { Injectable } from "@angular/core";
import { ZipCityStateModel } from "../models/zip-city-state.model";
import { ZIP_STATE_MAPPING } from "../utils/zip-city-state-mapping.constant";

@Injectable({
    providedIn: 'root'
})
export class ZipCityStateService {

    getMatchingCityAndState(zipCode: string): ZipCityStateModel | null {
        const zipCodeLength = zipCode ? zipCode.toString().length: 0;
        if (zipCodeLength === 5 || zipCodeLength === 6) {
            return ZIP_STATE_MAPPING.find((zipMapping) => zipMapping.zipCode === Number(zipCode));
        }
        return null;
    }
}