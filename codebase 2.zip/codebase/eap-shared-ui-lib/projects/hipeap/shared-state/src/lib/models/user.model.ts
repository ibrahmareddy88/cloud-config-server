export interface User {
    userId?:        string;
    name?:          string;
    email?:         string;
    eapGroup?:      string;
    roles?:         Role[];
    isSystemAdmin?: boolean;
}

export interface Role {
    code?:         string;
    displayName?:  string;
    restrictions?: Restriction[];
    primary?:      boolean;
}

export interface Restriction {
    resourceCode?: string;
    display?:      string;
    accessLevel?:  string;
}
