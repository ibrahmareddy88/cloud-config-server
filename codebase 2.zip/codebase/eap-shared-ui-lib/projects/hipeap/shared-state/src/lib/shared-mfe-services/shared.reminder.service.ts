import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class SharedReminderService {

    private toggleReminder$ = new Subject<boolean>();

    constructor() {}

    showReminderForm(): void {
        this.toggleReminder$.next(true);
    }

    hideReminderForm(): void {
        this.toggleReminder$.next(false);
    }

    getReminderState(): Observable<boolean> {
        return this.toggleReminder$.asObservable();
    }
}
