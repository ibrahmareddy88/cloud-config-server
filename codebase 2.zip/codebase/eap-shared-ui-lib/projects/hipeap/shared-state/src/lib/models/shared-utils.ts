import { Codes } from './codes';
import { CodeValues } from './codeValues';

export const getOptionsMapByCodeId = (data: Codes[], codeId: string): {code: string, label: string}[] => {
    return data?.find((code: Codes) => code?.id === codeId)
        ?.values?.map((val: CodeValues) => ({ code: val?.code, label: val?.label }));
}
