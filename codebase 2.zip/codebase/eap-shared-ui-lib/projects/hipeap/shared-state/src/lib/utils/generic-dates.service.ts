import { Injectable } from '@angular/core';

import { DatePipe, formatDate } from '@angular/common';
import * as moment from 'moment';
import { AbstractControl } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class GenericDatesService {
  EMPTY_VALUE: string = '------------';

  constructor(private dateFormatter: DatePipe) {}

  dateByFormat(param: any, format: string): string | null {
    format = this.getFormat(format);
    if (param instanceof Date) {
      return this.dateFormatter.transform(param, format, 'en');
    } else if (param && param.length > 0) {
      const date = new Date(param);
      date.setMinutes(date.getMinutes() + date.getTimezoneOffset());
      return this.dateFormatter.transform(date.toUTCString(), format, 'en');
    } else {
      return null;
    }
  }

  formatDate(param: any): string | null {
   return this.dateByFormat(param, 'MM/dd/yyyy')
  }

  toDateJSON(val: string | Date): string | null {
    if (typeof val === 'string' && val !== '') {
      let date = JSON.stringify(val);
      date = date.slice(1, 11);
      return new Date(date).toJSON();
    } else if (val instanceof Date) {
      return val.toJSON();
    }
    return null;
  }

  toDate(val: string | Date): Date | null {
    if (typeof val === 'string' && val !== '') {
      let date = JSON.stringify(val);
      date = date.slice(1, 11);
      return new Date(date);
    }
    return null;
  }

  calendarMinDate(date: string | Date) {
    return moment(date).add(0, 'd').format('yyyy-MM-DD');
  }

  calendarMinDateIncDays(date: string | Date, inc: number) {
    return moment(date).add(inc, 'd').format('yyyy-MM-DD');
  }

  setDateToFormControl(dateStr: any) {
    if (dateStr && dateStr !== '') {
      dateStr = this.formatDate(dateStr);
      return formatDate(dateStr, 'yyyy-MM-dd', 'en');
    }
    return null;
  }

  displayDate(
    formControl: AbstractControl,
    controlName: string
  ): string | null {
    const date: string = formControl.get(controlName)?.value;
    const formattedDate = this.formatDate(date);
    if (formattedDate != null) {
      return this.dateFormatter.transform(formattedDate, 'MM/dd/yyyy');
    }
    return this.EMPTY_VALUE;
  }

  private getFormat(format: string) {
    const validFormats = ['MM/dd/yyyy', 
    'yyyy-MM-dd:HH:mm:ss',
     'MM/dd/yyyy HH:mm:ss',
     'yyyyMMddHHmmss',
     'dd/MM/yyyy',
     'dd/MM/yyyy hh:mm:ss',
     'dd-MM-yyyy',
     'MM/dd/yyyy hh:mm:ss',
     'yyyy/MM/dd',
     'yyyy/MM/dd HH:mm:ss',
     'dd/MM/yy',
     'dd/MM/yy hh:mm:ss',];
    if (validFormats.includes(format)) {
      return format;
    }
    return 'MM/dd/yyyy';
  }
  
}
