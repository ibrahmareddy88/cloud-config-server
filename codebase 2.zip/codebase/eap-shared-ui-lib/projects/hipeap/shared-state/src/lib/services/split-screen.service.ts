import { Injectable, Inject } from '@angular/core';
import { StorageService, SESSION_STORAGE } from 'ngx-webstorage-service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SplitScreenService {
  constructor() {}

  private splitScreenSource = new BehaviorSubject(false);

  private fakeSplitScreenSource = new BehaviorSubject(false);

  private sharedData = new BehaviorSubject(null);

  getSharedData(): Observable<any> {
    return this.sharedData.asObservable();
  }
  setSharedData(data: any) {
    this.sharedData.next(data);
  }

  getSplitScreen(): Observable<boolean> {
    return this.splitScreenSource.asObservable();
  }
  setSplitScreen(splitScreen: boolean): void {
    this.splitScreenSource.next(splitScreen);
  }

  getFakeSplitScreen(): Observable<boolean> {
    return this.fakeSplitScreenSource.asObservable();
  }
  setFakeSplitScreen(splitScreen: boolean): void {
    this.fakeSplitScreenSource.next(splitScreen);
  }
}
