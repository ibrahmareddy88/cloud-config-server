import { Injectable } from "@angular/core";
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class LoaderService {

    private _loader$ = new BehaviorSubject(false);
    public showLoader$ = this._loader$.asObservable();

    showLoading() {
        this._loader$.next(true);
    }

    hideLoading() {
        this._loader$.next(false);
    }
}
