import { Injectable } from '@angular/core';
import { GlobalUserDataService } from '../global-data/user-data.service';
import { Restriction } from '../models/user.model';

enum AccessLevel {
    HIDDEN = 'HIDDEN',
    READONLY = 'readonly'
}

@Injectable({
    providedIn: 'root'
})
export class UserRestrictions {

    constructor(private userData: GlobalUserDataService) { }

    readonly(resourceCode: string): boolean {
        return this.verifyAccess(resourceCode, AccessLevel.READONLY);
    }

    hideContent(resourceCode: string): boolean {
        return this.contentAccess(resourceCode, AccessLevel.HIDDEN);
    }

    checkRouteAccess(role: string): boolean {
        if (role == null) {
            return true; // no restriction
        } else if (this.hideRoute(role)) {
            return false; // hide route;
        } else {
            return true;;
        }
    }

    private hideRoute(resourceCode: string): boolean {
        return this.verifyAccess(resourceCode, AccessLevel.HIDDEN);
    }

    private verifyAccess(role: string, accessLevel: AccessLevel): boolean {
        if (!this.userData.getRestrictions()) {
            return false;
        }
        const filteredRestriction: Restriction[] = this.userData.getRestrictions().filter(restriction => restriction.resourceCode == role);
        const len = filteredRestriction.length;
        if ((len > 0)) {
            return (filteredRestriction[0].accessLevel == accessLevel);
        }
        return false;
    }

    private contentAccess(role: string, accessLevel: AccessLevel): boolean {
        if (!this.userData.getRestrictions()) {
            return false;
        }
        const restriction = this.userData.getRestrictions().filter(restriction => restriction.resourceCode == role);
        if ((restriction.length > 0)) {
            if (restriction[0].accessLevel == accessLevel) {
                return false;
            } else
                return true;
        }
        return true;
    }


}