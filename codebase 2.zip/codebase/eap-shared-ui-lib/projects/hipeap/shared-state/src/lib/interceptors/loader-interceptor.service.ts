import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { LoaderService } from '../loader.service';

@Injectable({
    providedIn: 'root'
})
export class LoaderInterceptorService implements HttpInterceptor {

    private processingRequestCount = 0;

    constructor(private loaderService: LoaderService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        this.loaderService.showLoading();
        this.processingRequestCount++;
        return Observable.create(ob => {
            const subscription = next.handle(req)
                .subscribe(
                    event => {
                        if (event instanceof HttpResponse) {
                            ob.next(event);
                        }
                    },
                    err => {
                        ob.error(err);
                    },
                    () => {
                        ob.complete();
                    });
            return () => {
                this.processingRequestCount--;
                this.checkAndRemoveLoading();
                subscription.unsubscribe();
            };
        });
    }

    private checkAndRemoveLoading() {
        if (this.processingRequestCount == 0)
            this.loaderService.hideLoading();
    }
}
