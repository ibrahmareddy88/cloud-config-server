import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpeechTextDisplayComponent } from './speech-text-display.component';

describe('SpeechTextDisplayComponent', () => {
  let component: SpeechTextDisplayComponent;
  let fixture: ComponentFixture<SpeechTextDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpeechTextDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpeechTextDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
