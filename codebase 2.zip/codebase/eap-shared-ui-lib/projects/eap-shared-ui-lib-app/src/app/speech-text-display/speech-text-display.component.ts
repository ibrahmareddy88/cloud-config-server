import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-speech-text-display',
  templateUrl: './speech-text-display.component.html',
  styleUrls: ['./speech-text-display.component.scss']
})
export class SpeechTextDisplayComponent implements OnInit {
  form!: FormGroup;
  secondControlDisable: boolean;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      firstControl: new FormControl(''),
      secondControl: new FormControl(null),
    });
  }

  firstControlToggleEnable() {
    if (this.form.get('firstControl').disabled)
      this.form.get('firstControl').enable();
    else this.form.get('firstControl').disable();
  }

  secondControlToggleEnable() {
    this.secondControlDisable = !this.secondControlDisable;
  }

  clear(){
    this.form.reset();
  }
}
