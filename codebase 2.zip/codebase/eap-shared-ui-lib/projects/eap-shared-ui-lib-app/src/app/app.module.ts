import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FhirpathService } from 'projects/hipeap/shared-components/src/lib/services/fhirpath.service';
import { BrowserModule } from '@angular/platform-browser';
import { EapInputModuleModule, SharedComponentsModule } from 'projects/hipeap/shared-components/src/public-api';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TableDisplayComponent } from './table-display/table-display.component';

import { ToastNotificationsModule, Toaster } from 'ngx-toast-notifications';
import { HandleErrorService } from 'projects/hipeap/shared-state/src/lib/services/handle-error.service';
import { ErrorInterceptor } from 'projects/hipeap/shared-state/src/lib/interceptors/error/error.interceptor';
import { SharedStateModule } from 'projects/hipeap/shared-state/src/public-api';
import { SpeechTextDisplayComponent } from './speech-text-display/speech-text-display.component';
import { ToastDemoComponent } from './toast-demo/toast-demo.component';
import { TimerDisplayComponent } from './timer-display/timer-display.component';

@NgModule({
  declarations: [
    AppComponent,
    TableDisplayComponent,
	  SpeechTextDisplayComponent,
    ToastDemoComponent,
    TimerDisplayComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    SharedComponentsModule,
    HttpClientModule,
    ToastNotificationsModule.forRoot({position: 'bottom-center', preventDuplicates: true}),
    SharedStateModule,
    ReactiveFormsModule,
    EapInputModuleModule

  ],
  providers: [FhirpathService,HandleErrorService,
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true},

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
