import { AfterViewInit, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { TableData } from 'projects/hipeap/shared-components/src/lib/models/table-data';
import { FieldType, Option, OptionMap } from 'projects/hipeap/shared-components/src/lib/models/field';


@Component({
  selector: 'app-table-display',
  templateUrl: './table-display.component.html',
  styleUrls: ['./table-display.component.scss']
})
export class TableDisplayComponent implements OnInit, AfterViewInit {

  table: TableData;
  anyTableData: any;
  optionsData: OptionMap[] = [];
  options1: Option[] = [];
  options2: Option[] = [];
  @ViewChild('customTemp') customTemplate: TemplateRef<any>;
  inEditMode = true;
  clientProfileFormGroup: FormGroup;
  daysForm = new FormGroup({
    startTime: new FormControl(''),
    endTime: new FormControl(''),
    timeZone: new FormControl(''),
    days: new FormArray([
      new FormGroup({
        code: new FormControl('Monday'),
        display: new FormControl('M'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Tuesday'),
        display: new FormControl('T'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Wednesday'),
        display: new FormControl('W'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Thursday'),
        display: new FormControl('Tu'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Friday'),
        display: new FormControl('F'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Saturday'),
        display: new FormControl('S'),
        checked: new FormControl('')
      }),
      new FormGroup({
        code: new FormControl('Sunday'),
        display: new FormControl('Su'),
        checked: new FormControl('')
      })
    ])
  })

  logForm() {
    console.log(this.clientProfileFormGroup.value);
    console.log(this.daysForm.value);
  }

  constructor() {
    this.clientProfileFormGroup = new FormGroup({
      clientName: new FormControl(''),
      timePicker: new FormControl('')
    })
    this.options1 =[{code: 'choice 1', label: 'Choice 1 label'},
    {code: 'choice1', label: 'Choice1 label'},
    {code: 'choice 2', label: 'Choice 2 label'},
    {code: 'choice2', label: 'Choice2 label'},
    {code: 'choice 4', label: 'Choice4 label'}];
    this.options2 =[{code:'choice 1', label: 'choice  1'}, {code:'choice2', label: 'choice  2'}, {code:'choice 2', label: 'choice  2 label'}];
    
    this.optionsData=[{optionKey: 'option1', optionValues: this.options1}, {optionKey: 'option2', optionValues: this.options2}]
    this.anyTableData = [{
      head_cb: true,
      head_cbg: ['choice 1','choice2'],
      head_radio: 'choice2',
      head_dd: 'choice1',
      head_d: '4',
      head_md: ['choice1','choice2', 'choice 1'],
      card_ta: 'row 1 card area',
      card_tb: 'row 1 card box',
      card_cb: false,
      card_date: '2021-08-04T00:00:00.000Z',
    }, {
      head_cb: false,
      head_cbg: 'choice2',
      head_radio: 'choice 1',
      head_dd: 'choice1',
      head_md: ['choice1','choice2', 'choice 1'],
      head_d: '10',
      card_ta: 'row 2 card area',
      card_tb: 'row 2 card box',
      card_cb: true,
      card_date: '2021-08-05T00:00:00.000Z',
    },
      {
        head_cb: false,
        head_cbg: 'choice 2',
        head_radio: 'choice 1',
        head_dd: 'choice 4',
        head_md: ['choice1','choice2', 'choice 1'],
        head_d: '10',
        card_ta: 'row 2 card area',
        card_tb: 'row 2 card box',
        card_cb: true,
        card_date: '2021-08-04T00:00:00.000Z',
    },];
    this.table = {
      title: 'Table One', //To display Title
      showFilter: true, // To display Filter along with grid. By default false
      showPagination: true, // To display paginator along with grid. By default false
      headerFields: [  // Array of fields to display in Grid
        {
          type: FieldType.CHECKBOX, // field type to render the HTML element in edit mode. AVAILABLE types: CUSTOMFIELD,CHECKBOX,CHECKBOXGROUP,DATE,DECIMAL,DROPDOWN,IMAGE,RADIO,TEXTAREA,TEXTBOX,HIDDEN,LINK,MULTISELECT,INNERHTML,CUSTOMDROPDOWN
          label: 'Is this checked', // Header Name of the field
          editable: true, // to make field editable
          dataPath: '%resource.head_cb', // fhir path expression evaluates and return field value
          name: 'head_cb', // field name
          enableWhen: "%resource.head_radio ='choice 1'" // fhir path expression evaluates and return boolean value - used to show or hide the field dynamically
        },
        {
          type: FieldType.CUSTOMDROPDOWN,
          label: 'Header custom field',
          editable: true,
          dataPath: '%resource.head_cbg',
          name:'head_cbg',
          choiceOptions: 'option2', //give OptionKey from OptionsMap
          multiple: true, // to select multiple options in dropdown
        },
        {
          type: FieldType.MULTISELECT,
          label: 'Header MULTISLECT',
          editable: true,
          dataPath: '%resource.head_md',
          name:'head_md',
          choiceOptions: 'option1',
        },
        {
          type: FieldType.RADIO,
          choiceOptions: 'option1',
          label: 'Header radio',
          editable: true,
          dataPath: '%resource.head_radio',
          name : 'head_radio'
        },
        {
          type: FieldType.DROPDOWN,
          choiceOptions: 'option1',
          label: 'Header Dropdown',
          editable: true,
          dataPath: '%resource.head_dd',
          name:'head_dd'
        },
        {
          type: FieldType.DECIMAL,
          label: 'header decimal',
          editable: true,
          dataPath: '%resource.head_d',
          name: 'head_d',
          validatorData: [{name: 'required',  errorMsg: 'card text box is required',valFunc: Validators.required}] // to add validator to field
        }],
      cardFields: [{
        type: FieldType.SPEECHTOTEXT,
        label: 'card text area',
        editable: true,
        dataPath: '%resource.card_ta',
        name:'card_ta',
        cssClass: 'one-col'
      },
      {
        type: FieldType.TEXTBOX,
        label: 'card text box',
        editable: true,
        dataPath: '%resource.card_tb',
        name:'card_tb',
      },
      {
        type: FieldType.DATE,
        label: 'card text box',
        editable: true,
        dataPath: '%resource.card_date',
        name:'card_date',
      },
      {
        type: FieldType.INNERHTML,
        label: 'Simple Html',
        dataPath: '%resource.card_date',
        name:'card_cb',
        innerHTML: '<a>Hello</a>',
      },
      {
        type: FieldType.CUSTOMFIELD,
        label: 'custom Html',
        dataPath: '%resource.card_date',
        name:'card_ct',
        template: this.customTemplate,
      }],
      editable: true,
      buttons: [{
        cssClass: 'svgIcon icon-green-tick icon-check'
      }]
    }; 
  }
  ngAfterViewInit(): void {
    this.table.cardFields.forEach( f => {
      if(f.name === 'card_ct'){
        f.template = this.customTemplate;
      }
    })
  }
  ngOnInit(): void {
  }

  emitterHandler(event: any): void {
    console.log(event);
    /* if(event.type === 'edit'){
      event.response.controls.buttons.patchValue([])
    }else{
      event.response.controls.buttons.patchValue([{
        class: 'svgIcon icon-green-tick icon-check'
      }]);
    } */
  }

}