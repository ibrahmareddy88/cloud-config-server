import { Component, OnInit } from '@angular/core';
import { ConfirmationToasterService } from 'projects/hipeap/shared-components/src/public-api';

@Component({
  selector: 'app-toast-demo',
  templateUrl: './toast-demo.component.html',
  styleUrls: ['./toast-demo.component.scss']
})
export class ToastDemoComponent implements OnInit {


  constructor(private confirmationToaster: ConfirmationToasterService) { }

  ngOnInit(): void {
  }
  
  showToast() {
    this.confirmationToaster.open({
      cancelText: 'No',
      confirmText: 'Yes',
      message: 'Do you want to delete this item?'
    });

    this.confirmationToaster.confirmed().subscribe(()=>{
      console.log("Confirm action")
    })
    }

    toastHandler(event: any) {
      console.log(event);
    }
}
