import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer-display',
  templateUrl: './timer-display.component.html',
})
export class TimerDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
