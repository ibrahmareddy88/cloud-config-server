import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'eap-shared-ui-lib-app';

  constructor(private http: HttpClient) { 
    this.login({}).subscribe(data => {
      console.log(data);
    });
  }


  login(data: any) {
      data = { email: 'admin', password: 'admin' };
      return this.http.post('http://localhost:3070/api/login', data);
  }

  getCustomerDetails() {
      return this.http.get('http://localhost:3070/customers/details');
  }
}
