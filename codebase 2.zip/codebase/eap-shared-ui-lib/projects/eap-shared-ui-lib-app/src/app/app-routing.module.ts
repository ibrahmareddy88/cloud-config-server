import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SpeechTextDisplayComponent } from './speech-text-display/speech-text-display.component';
import { TableDisplayComponent } from './table-display/table-display.component';
import { TimerDisplayComponent } from './timer-display/timer-display.component';

const routes: Routes = [
  {
    path: 'speechtext',
    component: SpeechTextDisplayComponent,
  },
  {
    path: 'timer',
    component: TimerDisplayComponent,
  },
  {
    path: '',
    component: TableDisplayComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
