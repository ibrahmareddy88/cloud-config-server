#!/bin/bash

npm install

### dependencies for shared-state service
cd ./projects/hipeap/shared-state
npm install

#go back to base directory
cd ../../..

ng build @hipeap/shared-state --prod

### dependencies for shared-components lib
cd ./projects/hipeap/shared-components
npm install

#go back to base directory and build shared-components
cd ../../..

ng build @hipeap/shared-components --prod

###TODO.. check if we really need to do package install 3 times..
### dependencies for shared-security
cd ./projects/hipeap/shared-security
npm install

#go back to base directory and build shared-security
cd ../../..
ng build @hipeap/shared-security --prod