#!/bin/bash
# Copyright Anthem 2021
# Author: Hima Bindu Gudipati
#
# JFrog API: https://www.jfrog.com/confluence/display/JFROG/npm+Registry#npmRegistry-UsingBasicAuthentication
# Script to assist developers in pointing to Anthem's npm-public repository for private Angular Typescript packages.

echo "Link https://artifactory.anthem.com/ui/repos/tree/General/npm-public"

# npm config set @anthem:registry https://artifactory.anthem.com/artifactory/api/npm/npm-public/

echo ""
echo "Successfully set npm registry for @anthem client packages"

while true; do

  echo ""
  echo "CHOOSE AN OPTION: "

  echo "(s) - select s to automatically setup your ~/.npmrc file for Anthem Artifactory (mac only)"

  echo "(w) - select w to open the npm setup wiki (Windows Recommended)"

  echo "(a) - select a to open anthem artifactory and print steps"

  echo "(r) - select r (mac only) to open your npmrc file for editing after artifactory setup."

  echo "(e) - select e or q to exit"

  read -p "Select option (s/w/a/r/e/q) " sware
  case $sware in
      [sS]* ) break;;
      [wW]* ) open "https://confluence.anthem.com/pages/resumedraft.action?draftId=654034366&draftShareId=27af7b80-e4a0-428f-a0b5-13f848240bbb&";;
      [aA]* ) open "https://artifactory.anthem.com/ui/repos/tree/General/npm-public"; echo "Step 1: Click the \"Set Me Up\" button in the top right of the page opened just now."; echo "Step 2: In the top right, enter your password and press the arrow key. This is where it says \"Type password to insert your credentials to the code snippets"; echo "Step 3: Copy the section entitled \"Using basic authentication\" and paste it into your ~./npmrc file.";;
      [rR]* ) open -a TextEdit ~/.npmrc;;
      [eEqQ]* ) exit;;
      * ) echo "Please make a supported selection";;
  esac
done

read -p "Enter your Anthem Domain ID (Ex: AG38705): " USERNAME
echo "Enter your Anthem Domain Password"
read -s PASSWORD

while true; do
    read -p "Are you sure you would like to continue? This will overwrite your .npmrc file and will break it if your username/password are incorrect. (y/n) " yn
    case $yn in
        [Yy]* ) make install; break;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done

if [ "$(uname)" != "Darwin" ]; then
    # Not Mac OS X platform
    echo "You are not on mac, it is recommended you quit and follow the manual setup via the wiki. "
    read -p "Press enter to continue and try your luck"
fi

echo "Attempting to setup your npmrc file."

curl -o .npmrc -u$USERNAME:$PASSWORD -k "https://artifactory.anthem.com/artifactory/api/npm/auth"

echo "NPMRC CLONED SUCCESSFULLY:"
echo "strict-ssl=false" >> .npmrc

echo "registry=https://registry.npmjs.org/" >> .npmrc
echo "@anthem:registry=https://artifactory.anthem.com/artifactory/api/npm/npm-public/" >> .npmrc
echo "@hipeap:registry=https://artifactory.anthem.com/artifactory/api/npm/npm-public/" >> .npmrc

cat .npmrc

#replace current npmrc.
mv ./.npmrc ~/.npmrc

yarn config set strict-ssl false

echo ""
echo "Setup complete! .npmrc (printed above) replaced in your home directory ~/.npmrc"
echo "Note: If your username/password was wrong, it likely broke and you will have to run this again.."
