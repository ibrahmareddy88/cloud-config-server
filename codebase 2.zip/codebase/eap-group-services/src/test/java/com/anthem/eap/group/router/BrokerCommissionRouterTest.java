package com.anthem.eap.group.router;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.BrokerContactsDTO;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.service.GroupService;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.utils.BrokerCommissionClient;
import com.anthem.eap.group.utils.BrokerCommissionUtil;
import com.anthem.eap.model.accountProfile.BrokerCommission;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class BrokerCommissionRouterTest extends AbstractPersistableUnitTests {

  @Autowired private GroupService groupService;

  @Autowired private SubGroupService subGroupService;

  @Autowired private GroupRepository groupRepository;

  private Group group;

  private SubGroup subGroup;

  private MockWebServer mockWebServer = new MockWebServer();
  private BrokerCommissionClient brokerClient =
      new BrokerCommissionClient(WebClient.create(mockWebServer.url("/").toString()));

  @BeforeEach
  private void init() {
    group = BrokerCommissionUtil.getGroup();
    subGroup = BrokerCommissionUtil.getSubGroup();
    groupRepository.save(group).block();
    subGroupService.saveSubGroup(subGroup).block();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  @Order(1)
  @Description("should create broker within a group")
  void addBrokerForGroupProfileTest() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    assertNull(broker.getId());
    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_BROKER_PATH, group.getId(), 1L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerCommission.class)
        .consumeWith(
            response -> {
              BrokerCommission br = response.getResponseBody();
              BrokerCommissionUtil.assertBrokerCommission(broker, br);
            });
  }

  @Test
  @Order(2)
  @Description("should throw error when group account profile not found")
  void addBrokerForGroupProfileFailTest() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    assertNull(broker.getId());
    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_BROKER_PATH, group.getId(), 10L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @Order(3)
  @Description("should update broker details within a group if already exists")
  void updateBrokerForGroupProfileTest() throws JsonProcessingException, InterruptedException {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    broker.setId(1L);
    broker.setNote("Instructions updated");
    BrokerCommissionUtil.enqueueMockResponse(mockWebServer, broker);
    Mono<BrokerCommission> brokerMono =
        brokerClient.saveOrUpdateGroupBroker(group.getId(), 1L, broker);
    StepVerifier.create(brokerMono)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("Instructions updated", b.getNote());
              assertEquals(broker.getId(), b.getId());
            })
        .verifyComplete();
  }

  @Test
  @Order(4)
  @Description("should create broker within a subgroup")
  void addBrokerForSubGroupProfileTest() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    assertNull(broker.getId());
    webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_BROKER_PATH, subGroup.getId(), 1L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerCommission.class)
        .consumeWith(
            response -> {
              BrokerCommission br = response.getResponseBody();
              assertNotNull(br);
              assertNotNull(br.getId());
            });
  }

  @Test
  @Order(5)
  @Description("should throw error when subGroup account profile not found")
  void addBrokerForSubGroupProfileFailTest() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    assertNull(broker.getId());
    webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_BROKER_PATH,
            subGroup.getId(),
            10L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @Order(6)
  @Description("should update broker details within a subgroup if already exists")
  void updateBrokerForSubGroupProfileTest() throws JsonProcessingException, InterruptedException {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    broker.setId(1L);
    broker.setNote("Instructions updated");
    BrokerCommissionUtil.enqueueMockResponse(mockWebServer, broker);
    Mono<BrokerCommission> brokerMono =
        brokerClient.saveOrUpdateSubGroupBroker(subGroup.getId(), 2L, broker);
    StepVerifier.create(brokerMono)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("Instructions updated", b.getNote());
            })
        .verifyComplete();
  }

  @Test
  @Order(7)
  @Description("should return empty when groupId is null")
  void returnEmptyWhenGroupIdIsNull() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    Mono<BrokerCommission> brokerRes =
        groupService.saveOrUpdateBrokerCommission(null, 1L, broker, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(8)
  @Description("should return empty when group account profile Id is null")
  void returnEmptyWhenAccountProfileIdIsNull() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    Mono<BrokerCommission> brokerRes =
        groupService.saveOrUpdateBrokerCommission(
            group.getId(), null, broker, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(9)
  @Description("should return empty when broker is null for group")
  void returnEmptyWhenBrokerIsNull() {
    Mono<BrokerCommission> brokerRes =
        groupService.saveOrUpdateBrokerCommission(
            group.getId(), 1L, null, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(10)
  @Description("should return empty when subGroupId is null")
  void returnEmptyWhenSubGroupIdIsNull() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    Mono<BrokerCommission> brokerRes =
        subGroupService.saveOrUpdateBrokerCommission(null, 1L, broker, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(11)
  @Description("should return empty when account profile Id is null for subgroup")
  void returnEmptyWhenSubGroupAccountProfileIdIsNullTest() {
    BrokerCommission broker = BrokerCommissionUtil.getBrokerCommission();
    Mono<BrokerCommission> brokerRes =
        subGroupService.saveOrUpdateBrokerCommission(
            group.getId(), null, broker, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(12)
  @Description("should return empty when broker is null for subgroup")
  void returnEmptyWhenBrokerIsNullForSubGroupTest() {
    Mono<BrokerCommission> brokerRes =
        subGroupService.saveOrUpdateBrokerCommission(
            group.getId(), 1L, null, GroupConstants.GROUP_TYPE);
    StepVerifier.create(brokerRes).verifyComplete();
  }

  @Test
  @Order(13)
  @Description("should get all broker and contact details for a given groupId and accountDetailId")
  void getAllBrokerAndContactsTest() {
    webClient
        .get()
        .uri(RouteConstants.GROUP_BROKER_CONTACTS_INFO, group.getId(), 1L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNotNull(brokerContacts);
            });
  }

  @Test
  @Order(14)
  @Description("should return empty for a given invalid groupId and accountDetailId")
  void getAllBrokerAndContactsForInvalidGroupTest() {
    webClient
        .get()
        .uri(RouteConstants.GROUP_BROKER_CONTACTS_INFO, 898L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNull(brokerContacts);
            });
  }

  @Test
  @Order(15)
  @Description("should return empty for a given valid groupId and invalid accountDetailId")
  void getAllBrokerAndContactsForInvalidProfileIdTest() {
    webClient
        .get()
        .uri(RouteConstants.GROUP_BROKER_CONTACTS_INFO, group.getId(), 19090L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNull(brokerContacts);
            });
  }

  @Test
  @Order(16)
  @Description(
      "should get all broker and contact details for a given subGroupId and accountDetailId")
  void getAllBrokerAndContactsofSubGroupTest() {
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.SUBGROUP_BROKER_CONTACTS_INFO, subGroup.getId(), 1L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNotNull(brokerContacts);
            });
  }

  @Test
  @Order(17)
  @Description("should return empty for a given invalid subGroupId and accountDetailId")
  void getAllBrokerAndContactsForInvalidSubGroupTest() {
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.SUBGROUP_BROKER_CONTACTS_INFO, 898L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNull(brokerContacts);
            });
  }

  @Test
  @Order(18)
  @Description("should return empty for a given valid subGroupId and invalid accountDetailId")
  void getAllBrokerAndContactsOfSubGrpForInvalidProfileIdTest() {
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.SUBGROUP_BROKER_CONTACTS_INFO, subGroup.getId(), 19090L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BrokerContactsDTO.class)
        .consumeWith(
            response -> {
              BrokerContactsDTO brokerContacts = response.getResponseBody();
              assertNull(brokerContacts);
            });
  }
}
