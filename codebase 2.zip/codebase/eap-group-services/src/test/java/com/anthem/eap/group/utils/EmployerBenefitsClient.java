package com.anthem.eap.group.utils;

import com.anthem.eap.group.router.RouteConstants;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

public class EmployerBenefitsClient {
  private WebClient webClient;

  public EmployerBenefitsClient(WebClient webClient) {
    this.webClient = webClient;
  }

  public Mono<SABank> saveOrUpdateGroupSABank(Long groupId, Long accountDetailsId, SABank bank) {
    return webClient
        .put()
        .uri(RouteConstants.GROUPS_EMP_SERVICE_SA_BANK, groupId, accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(bank), SABank.class)
        .retrieve()
        .bodyToMono(SABank.class);
  }

  public Mono<AccountService> saveOrUpdateGroupAccountService(
      Long groupId, Long accountDetailsId, AccountService serv) {
    return webClient
        .put()
        .uri(RouteConstants.GROUPS_ACCOUNT_SERVICE, groupId, accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), AccountService.class)
        .retrieve()
        .bodyToMono(AccountService.class);
  }

  public Mono<SABank> saveOrUpdateSubGroupSABank(
      Long subGroupId, Long accountDetailsId, SABank bank) {
    return webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUPS_EMP_SERVICE_SA_BANK,
            subGroupId,
            accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(bank), SABank.class)
        .retrieve()
        .bodyToMono(SABank.class);
  }

  public Mono<AccountService> saveOrUpdateSubGroupAccountService(
      Long subGroupId, Long accountDetailsId, AccountService serv) {
    return webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_ACCOUNT_SERVICE, subGroupId, accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), AccountService.class)
        .retrieve()
        .bodyToMono(AccountService.class);
  }

  public Mono<EmployerService> saveOrUpdateSubGroupEmployereNotes(
      Long subGroupId, Long accountDetailsId, EmployerService serv) {
    return webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUPS_EMPLOYER_SERVICE_NOTE,
            subGroupId,
            accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), EmployerService.class)
        .retrieve()
        .bodyToMono(EmployerService.class);
  }

  public Mono<Group> deleteBank(Long grouporSubGroupId, Long bankId, Group grp) {
    return webClient
        .put()
        .uri(RouteConstants.DELETE_BANK_HOURS, grouporSubGroupId, bankId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(grp), Group.class)
        .retrieve()
        .bodyToMono(Group.class);
  }

  public Mono<SubGroup> deleteSubGroupBank(Long subGroupId, Long bankId, SubGroup subGrp) {
    return webClient
        .put()
        .uri(RouteConstants.DELETE_BANK_HOURS_SUBGROUP, subGroupId, bankId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(subGrp), Group.class)
        .retrieve()
        .bodyToMono(SubGroup.class);
  }
}
