package com.anthem.eap.group.utils;

import com.anthem.eap.group.model.AlertModel;
import com.anthem.eap.group.model.AlertModel.Category;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.group.Alert;
import com.anthem.eap.model.group.Alert.AlertType;
import com.anthem.eap.model.group.Alias;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.TerminationInfo;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class AlertsTestUtil {

  public static Group createGroup() {

    Group group = new Group();
    group = new Group();
    group.setId(1L);
    group.setName("testGroup1");

    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    group.setHealthPlanIds(strlst);
    group.setNational(false);
    group.setTin("test");
    group.setCallCenterCode("test");
    group.setType("test");

    List<Address> addlst = new ArrayList<Address>();
    Address address = new Address();
    address.setCity("vijayawada");
    address.setCountryCd("520011");
    address.setCounty("india");
    address.setStateCd("Andhra Pradesh");
    address.setStreet1("Kedar Street");
    address.setStreet2("madhura Nagar");
    address.setStreet3("street");
    address.setType(Address.Type.HOME);
    address.setZip("523009");
    address.setZipExtn("78787");
    addlst.add(address);
    group.setAddresses(addlst);

    List<Alias> lst = new ArrayList<Alias>();
    Alias alias = new Alias();
    alias.setAlias("test");
    alias.setAliasType("test");
    lst.add(alias);
    group.setAliases(lst);

    List<TerminationInfo> terminationList = new ArrayList<TerminationInfo>();
    TerminationInfo terinfo = new TerminationInfo();
    ZonedDateTime zonedDateTime = ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    ZonedDateTime termDateTime = ZonedDateTime.of(2060, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    terinfo.setEffectiveDate(zonedDateTime);
    terinfo.setNewEAPVendor("testVendor");
    terinfo.setReinstatedBy("test");
    terinfo.setTerminatedBy("test");
    terinfo.setTerminationDate(termDateTime);
    terinfo.setTerminationNotes("terminationNote");
    terinfo.setTerminationReason("test");
    terminationList.add(terinfo);
    group.setTerminationList(terminationList);

    return group;
  }

  public static AlertModel alertMock() {
    AlertModel alert = new AlertModel();
    alert.setAlert("Alert1");
    alert.setAlertType(AlertType.Critical);
    alert.setCategory(Category.GROUP);
    alert.setGroupId(1l);
    return alert;
  }

  public static AlertModel updateAlertMock() {
    AlertModel alert = new AlertModel();
    alert.setId(1l);
    alert.setAlert("UpdatedAlert");
    alert.setAlertType(AlertType.Critical);
    alert.setCategory(Category.GROUP);
    alert.setGroupId(1l);
    return alert;
  }

  public static AlertModel activeAlertMock() {
    AlertModel alert = new AlertModel();
    alert.setAlert("Active Alert");
    alert.setAlertType(AlertType.Critical);
    alert.setCategory(Category.GROUP);
    alert.setGroupId(1l);
    alert.setEffectiveDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(2));
    alert.setTerminationDate(ZonedDateTime.now(ZoneId.of("UTC")).plusDays(2));
    return alert;
  }

  public static Group createGroupWithAlerts() {
    Group group = new Group();
    group = new Group();
    group.setId(1L);
    group.setName("testGroup1");
    group.setHealthPlanIds(getStrings());
    group.setNational(false);
    group.setTin("test");
    group.setCallCenterCode("test");
    group.setType("test");
    group.setAddresses(getAddress());
    group.setAlerts(alertsList());
    group.setTerminationList(getTerminationInfos());

    return group;
  }

  private static List<Alert> alertsList() {

    List<Alert> alerts = new ArrayList<Alert>();

    Alert a1 = new Alert();
    a1.setId(1l);
    a1.setAlert("a1");
    a1.setAlertType(AlertType.Standard);
    alerts.add(a1);
    Alert a2 = new Alert();
    a2.setId(2l);
    a2.setAlert("a2");
    a2.setAlertType(AlertType.Critical);
    a2.setEffectiveDate(ZonedDateTime.now().minusDays(2));
    a2.setTerminationDate(ZonedDateTime.now().minusDays(1));
    alerts.add(a2);

    Alert a3 = new Alert();
    a3.setId(3l);
    a3.setAlert("a3");
    a3.setAlertType(AlertType.Standard);
    a3.setEffectiveDate(ZonedDateTime.now().minusDays(2));
    a3.setTerminationDate(ZonedDateTime.now().plusDays(1));
    alerts.add(a3);

    return alerts;
  }

  public static SubGroup createSubgroupWithAlerts() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(1L);
    subGroup.setName("testSubGroup1");
    subGroup.setHealthPlanIds(getStrings());
    ;
    Address address = new Address();
    address.setCity("vijayawada");
    address.setCountryCd("520011");
    address.setCounty("india");
    address.setStateCd("Andhra Pradesh");
    address.setStreet1("Kedar Street");
    address.setStreet2("madhura Nagar");
    address.setStreet3("street");
    address.setType(Address.Type.HOME);
    address.setZip("523009");
    address.setZipExtn("78787");
    subGroup.setTin("tin");
    subGroup.setAltName("altname");
    subGroup.setEapIndicator("eapIndicator");
    subGroup.setGroupCodeData("groupCodeData");
    subGroup.setGroupCodeNameData("groupCodeNameData");
    subGroup.setGroupId(1L);
    subGroup.setMbuData("mbuData");
    subGroup.setMbuType("mbuType");
    subGroup.setNote("AbcNote");
    subGroup.setParentSubgroupId(25L);
    subGroup.setQhp("qph");
    subGroup.setRegion(28L);
    subGroup.setWareHouse("warehouse");
    subGroup.setCreatedBy("Abd");
    subGroup.setCreatedDate(ZonedDateTime.now().minusDays(5));
    subGroup.setLastModifiedBy("def");
    subGroup.setLastModifiedDate(ZonedDateTime.now());
    List<Address> addlst = getAddress();
    subGroup.setAddresses(addlst);
    subGroup.setAlertsLists(alertsList());
    subGroup.setTerminationList(getTerminationInfos());

    return subGroup;
  }

  private static List<Address> getAddress() {
    List<Address> addlst = new ArrayList<Address>();
    Address address = new Address();
    address.setCity("vijayawada");
    address.setCountryCd("520011");
    address.setCounty("india");
    address.setStateCd("Andhra Pradesh");
    address.setStreet1("Kedar Street");
    address.setStreet2("madhura Nagar");
    address.setStreet3("street");
    address.setType(Address.Type.HOME);
    address.setZip("523009");
    address.setZipExtn("78787");
    addlst.add(address);

    return addlst;
  }

  private static List<String> getStrings() {
    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    return strlst;
  }

  private static List<TerminationInfo> getTerminationInfos() {

    List<TerminationInfo> terminationList = new ArrayList<TerminationInfo>();
    TerminationInfo terinfo = new TerminationInfo();
    ZonedDateTime zonedDateTime = ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    ZonedDateTime termDateTime = ZonedDateTime.of(2060, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    terinfo.setEffectiveDate(zonedDateTime);
    terinfo.setNewEAPVendor("testVendor");
    terinfo.setReinstatedBy("test");
    terinfo.setTerminatedBy("test");
    terinfo.setTerminationDate(termDateTime);
    terinfo.setTerminationNotes("terminationNote");
    terinfo.setTerminationReason("test");
    terminationList.add(terinfo);

    return terminationList;
  }
}
