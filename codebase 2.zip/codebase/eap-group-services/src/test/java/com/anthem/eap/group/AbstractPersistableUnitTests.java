package com.anthem.eap.group;

import com.mongodb.reactivestreams.client.MongoDatabase;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

/** @author Rajesh Bandarupalli */
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public abstract class AbstractPersistableUnitTests {

  @Autowired protected ReactiveMongoTemplate mongoTemplate;
  @Autowired protected WebTestClient webClient;

  @BeforeEach
  void setup(ApplicationContext context) {
    this.clean();
  }

  @AfterEach
  void clean() {
    mongoTemplate.getMongoDatabase().flatMapMany(MongoDatabase::drop).blockLast();
  }
}
