package com.anthem.eap.group.router;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.HealthPlanRepository;
import com.anthem.eap.group.utils.HealthPlanUtil;
import com.anthem.eap.group.utils.PageModule;
import com.anthem.eap.model.group.HealthPlan;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.FluxExchangeResult;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

public class HealthPlanRouterTest extends AbstractPersistableUnitTests {

  @Autowired private HealthPlanRepository healthPlanRepository;

  private ObjectMapper objectMapper;

  @BeforeEach
  void setup(ApplicationContext context) {
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new PageModule());
    objectMapper.registerModule(new JavaTimeModule());
  }

  private void verifyHealthPlan(HealthPlan expected, HealthPlan result) {
    assertEquals(expected.getId(), result.getId());
    assertEquals(expected.getHealthPlanId(), result.getHealthPlanId());
    assertEquals(expected.getHealthPlanName(), result.getHealthPlanName());
    assertEquals(expected.getMembershipSource(), result.getMembershipSource());
    assertEquals(expected.getSubgroupId(), result.getSubgroupId());
    assertEquals(expected.getSubgroupName(), result.getSubgroupName());
    assertEquals(expected.getContractCode(), result.getContractCode());
    assertEquals(expected.getHpccCode(), result.getHpccCode());
    assertEquals(expected.getProgramName(), result.getProgramName());
    assertEquals(expected.getControlPlanCode(), result.getControlPlanCode());
    assertEquals(expected.getSourceSystem(), result.getSourceSystem());
    assertEquals(expected.getAsOfDate(), result.getAsOfDate());
    assertEquals(expected.getMemCount(), result.getMemCount());
  }

  /**
   * Unable to set Page.class as expectBody()
   * https://github.com/spring-projects/spring-data-commons/issues/1509
   */
  @Test
  void testGetAllHealthPlansPageable() {

    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "healthPlanName")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    assertEquals(response.getPageable().getPageNumber(), 0);
    assertEquals(response.getContent().size(), sortedByHealthPlanNameASC.size());

    verifyHealthPlan(response.getContent().get(0), sortedByHealthPlanNameASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByHealthPlanNameASC.get(1));
  }

  @Test
  void testSortByHealthPlanNameInASCOrder() {

    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "healthPlanName")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    verifyHealthPlan(response.getContent().get(0), sortedByHealthPlanNameASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByHealthPlanNameASC.get(1));
  }

  @Test
  void testSortByHealthPlanNameInDESCOrder() {

    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameDESC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName).reversed())
            .collect(Collectors.toList());

    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "healthPlanName")
                        .queryParam("sortOrder", "DESC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertNotNull(response.getContent());
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    verifyHealthPlan(response.getContent().get(0), sortedByHealthPlanNameDESC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByHealthPlanNameDESC.get(1));
  }

  @Test
  void testSortBySubGroupNameInASCOrder() {

    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedBysubGroupNameASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getSubgroupName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "subgroupName")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    verifyHealthPlan(response.getContent().get(0), sortedBysubGroupNameASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedBysubGroupNameASC.get(1));
  }

  @Test
  void testSortByMembershipSourceInASCOrder() {

    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByMembershipSourceASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(
                Comparator.comparing(HealthPlan::getMembershipSource)
                    .thenComparingLong(o -> Objects.requireNonNull(o.getId())))
            .collect(Collectors.toList());

    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "membershipSource")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    verifyHealthPlan(response.getContent().get(0), sortedByMembershipSourceASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByMembershipSourceASC.get(1));
    verifyHealthPlan(
        response.getContent().get(response.getContent().size() - 1),
        sortedByMembershipSourceASC.get(sortedByMembershipSourceASC.size() - 1));
  }

  @Test
  void testSortedByMemberCountInASCOrder() {
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByMemberCountASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getMemCount))
            .collect(Collectors.toList());

    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "10")
                        .queryParam("sortBy", "memCount")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertNotNull(response.getContent());
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    verifyHealthPlan(response.getContent().get(0), sortedByMemberCountASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByMemberCountASC.get(1));
  }

  //  @Test
  void testDefaultPaginationConfig() {
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameASC =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "5")
                        .queryParam("sortBy", "")
                        .queryParam("sortOrder", "")
                        .queryParam("query", "")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertNotNull(response.getContent());
    assertThat(response.getContent().size() > 0);
    assertNotNull(response.getContent().get(0));
    assertNotNull(response.getContent().get(1));

    assertEquals(response.getContent().size(), sortedByHealthPlanNameASC.size());
    assertEquals(response.getTotalElements(), sortedByHealthPlanNameASC.size());
    assertEquals(response.getNumberOfElements(), response.getTotalElements());
    assertEquals(response.getTotalPages(), 1);
    assertEquals(response.getNumber(), 0);

    verifyHealthPlan(response.getContent().get(0), sortedByHealthPlanNameASC.get(0));
    verifyHealthPlan(response.getContent().get(1), sortedByHealthPlanNameASC.get(1));
  }

  @Test
  void testPaginationWithFilterByMemberCountInteger() {
    int filterByMemberCount = 126;
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameASCAndFilterList =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .filter(d -> d.getMemCount() == filterByMemberCount)
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", "0")
                        .queryParam("pageSize", "5")
                        .queryParam("sortBy", "")
                        .queryParam("sortOrder", "")
                        .queryParam("query", filterByMemberCount)
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode,asOfDate,memCount")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertEquals(response.getContent().size(), sortedByHealthPlanNameASCAndFilterList.size());
    assertEquals(response.getTotalElements(), sortedByHealthPlanNameASCAndFilterList.size());
    assertEquals(response.getNumberOfElements(), response.getTotalElements());
  }

  @Test
  void testPaginationWithFilterByQueryAndPageSizeLimit() {
    String filterQuery = "TEST";
    int pageSize = 2;
    int pageNo = 0;
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> sortedByHealthPlanNameASCAndFilterList =
        unsorted.stream()
            .filter(d -> d.getSourceSystem().getValue().equalsIgnoreCase("edw"))
            .filter(
                d ->
                    d.getHealthPlanId().contains(filterQuery)
                        || d.getHealthPlanName().contains(filterQuery)
                        || d.getMembershipSource().contains(filterQuery)
                        || d.getSubgroupId().contains(filterQuery)
                        || d.getSubgroupName().contains(filterQuery)
                        || d.getContractCode().contains(filterQuery)
                        || d.getHpccCode().contains(filterQuery)
                        || d.getProgramName().contains(filterQuery)
                        || d.getControlPlanCode().contains(filterQuery))
            .sorted(Comparator.comparing(HealthPlan::getHealthPlanName))
            .collect(Collectors.toList());
    healthPlanRepository.saveAll(unsorted).blockLast();

    String responseBody =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/_search")
                        .queryParam("pageNo", pageNo)
                        .queryParam("pageSize", pageSize)
                        .queryParam("sortBy", "")
                        .queryParam("sortOrder", "")
                        .queryParam("query", filterQuery)
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult()
            .getResponseBody();

    Page<HealthPlan> response = null;
    try {
      response = objectMapper.readValue(responseBody, new TypeReference<Page<HealthPlan>>() {});
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    assertNotNull(response);
    assertEquals(
        response.getContent().size(),
        Math.min(pageSize, sortedByHealthPlanNameASCAndFilterList.size()));
    assertEquals(response.getTotalElements(), sortedByHealthPlanNameASCAndFilterList.size());
    assertEquals(response.getNumberOfElements(), pageSize);
    assertEquals(
        response.getTotalPages(),
        ((sortedByHealthPlanNameASCAndFilterList.size() / pageSize)
            + (sortedByHealthPlanNameASCAndFilterList.size() % pageSize > 0 ? 1 : 0)));
  }

  @Test
  void fetchHealthPlansTest() {
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan1(),
            HealthPlanUtil.getHealthPlan2(),
            HealthPlanUtil.getHealthPlan3(),
            HealthPlanUtil.getHealthPlan4(),
            HealthPlanUtil.getHealthPlan5());
    List<HealthPlan> finalHPList = Arrays.asList(HealthPlanUtil.getHealthPlan1());
    healthPlanRepository.saveAll(unsorted).blockLast();
    FluxExchangeResult<HealthPlan> response =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/stream")
                        .queryParam("sortBy", "healthPlanName")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "UNIVERSAL")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode")
                        .build())
            .accept(MediaType.TEXT_EVENT_STREAM)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(HealthPlan.class);
    assertNotNull(response);
    Flux<HealthPlan> eventFlux = response.getResponseBody();
    StepVerifier.create(eventFlux)
        .assertNext(result -> verifyHealthPlan(finalHPList.get(0), result))
        .verifyComplete();
  }

  @Test
  void fetchHealthPlansTestSortBySubgroupName() {
    List<HealthPlan> unsorted =
        Arrays.asList(
            HealthPlanUtil.getHealthPlan6(),
            HealthPlanUtil.getHealthPlan7(),
            HealthPlanUtil.getHealthPlan8(),
            HealthPlanUtil.getHealthPlan9());
    List<HealthPlan> finalHPList =
        Arrays.asList(HealthPlanUtil.getHealthPlan9(), HealthPlanUtil.getHealthPlan8());
    healthPlanRepository.saveAll(unsorted).blockLast();
    FluxExchangeResult<HealthPlan> response =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("/healthplan/stream")
                        .queryParam("sortBy", "subgroupName")
                        .queryParam("sortOrder", "ASC")
                        .queryParam("query", "2864")
                        .queryParam(
                            "fields",
                            "healthPlanId,healthPlanName,membershipSource,subgroupId,subgroupName,contractCode,hpccCode,programName,controlPlanCode")
                        .build())
            .accept(MediaType.TEXT_EVENT_STREAM)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(HealthPlan.class);
    assertNotNull(response);
    Flux<HealthPlan> eventFlux = response.getResponseBody();
    StepVerifier.create(eventFlux)
        .assertNext(result -> verifyHealthPlan(finalHPList.get(0), result))
        .assertNext(result -> verifyHealthPlan(finalHPList.get(1), result))
        .verifyComplete();
  }
}
