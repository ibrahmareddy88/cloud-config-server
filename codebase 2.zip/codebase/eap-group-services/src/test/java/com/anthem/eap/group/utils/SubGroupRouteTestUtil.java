package com.anthem.eap.group.utils;

import com.anthem.eap.group.model.SubGroupViewModel;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.group.EmployeeCount;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class SubGroupRouteTestUtil {

  // Sub group view model mock
  public static SubGroupViewModel subGroupMock(Long id) {
    SubGroupViewModel subGroup = new SubGroupViewModel();
    subGroup.setId(id);
    subGroup.setName("testGroup1");
    subGroup.setHealthPlanIds(getStrings());
    List<Address> addlst = new ArrayList<Address>();
    addlst.add(getAddress());
    subGroup.setAddresses(addlst);
    subGroup.setTin("tin");
    subGroup.setGroupId(1L);
    subGroup.setNote("AbcNote");
    return subGroup;
  }

  // health plan id's mock
  private static List<String> getStrings() {
    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    return strlst;
  }

  // addresses mock
  private static Address getAddress() {
    Address address = new Address();
    address.setCity("vijayawada");
    address.setCountryCd("520011");
    address.setCounty("india");
    address.setStateCd("Andhra Pradesh");
    address.setStreet1("Kedar Street");
    address.setStreet2("madhura Nagar");
    address.setStreet3("street");
    address.setType(Address.Type.HOME);
    address.setZip("523009");
    address.setZipExtn("78787");
    return address;
  }

  // employee count mock
  public static List<EmployeeCount> getEmployeeCounts(ZonedDateTime zonedDateTimeOf) {
    EmployeeCount empcount = new EmployeeCount();
    empcount.setCount("1234");
    empcount.setAsOfDate(zonedDateTimeOf);
    List<EmployeeCount> empcountlst = new ArrayList<EmployeeCount>();
    empcountlst.add(empcount);
    return empcountlst;
  }
}
