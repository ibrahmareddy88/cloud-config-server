package com.anthem.eap.group.router;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.model.SubGroupTreeViewModel;
import com.anthem.eap.group.model.SubGroupViewModel;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.utils.AlertsTestUtil;
import com.anthem.eap.group.utils.SubGroupRouteTestUtil;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZonedDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;

public class SubGroupRouterTest extends AbstractPersistableUnitTests {

  @Autowired private SubGroupRepository subGroupRepository;
  @Autowired GroupRepository groupRepository;

  // Test case for saving subgroup.
  @DisplayName("saving subgroup")
  @Test
  void saveSubGroupTest() {
    groupRepository.save(AlertsTestUtil.createGroupWithAlerts()).block();
    Mono<SubGroupViewModel> subGroupMono = Mono.just(SubGroupRouteTestUtil.subGroupMock(null));
    webClient
        .post()
        .uri("/subgroup/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(subGroupMono, SubGroupViewModel.class)
        .exchange()
        .expectStatus()
        .isOk();
    mongoTemplate
        .findById(1L, SubGroup.class)
        .flatMap(
            map -> {
              assertSaveSubGroup(map);
              return Mono.just(map);
            });
  }

  // Test case for subgroup tree list.
  @DisplayName("subgroup tree list")
  @Test
  public void getsubgroups() {

    groupRepository.save(AlertsTestUtil.createGroupWithAlerts()).block();
    SubGroup s1 = new SubGroup();
    BeanUtils.copyProperties(SubGroupRouteTestUtil.subGroupMock(1L), s1);
    subGroupRepository.save(s1).block();
    SubGroup s2 = new SubGroup();
    BeanUtils.copyProperties(SubGroupRouteTestUtil.subGroupMock(2L), s2);
    subGroupRepository.save(s2).block();

    webClient
        .get()
        .uri("/subgroup/treeview/?groupId=1&groupName=testGroup1")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(SubGroupTreeViewModel.class)
        .value(
            result -> {
              asertTreeList(result);
            });
  }

  // Test case for update subgroup.
  @DisplayName("update  subgroup")
  @Test
  public void updateSubgroupTest() {

    groupRepository.save(AlertsTestUtil.createGroupWithAlerts()).block();
    SubGroup s1 = new SubGroup();
    BeanUtils.copyProperties(SubGroupRouteTestUtil.subGroupMock(1L), s1);
    subGroupRepository.save(s1).block();
    SubGroupViewModel viewModel = SubGroupRouteTestUtil.subGroupMock(1L);
    viewModel.setEmployeeCountList(SubGroupRouteTestUtil.getEmployeeCounts(ZonedDateTime.now()));
    viewModel.setName("subgroup Updated");
    webClient
        .put()
        .uri("/subgroup/1")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(viewModel), SubGroupViewModel.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(SubGroup.class)
        .value(
            result -> {
              asertSubGroup(result, s1);
            });
  }

  // update sub group assertions
  private void asertSubGroup(SubGroup result, SubGroup source) {
    assertNotNull(result);
    assertNotEquals(result.getName(), source.getName());
    assertEquals(result.getName(), "subgroup Updated");
    assertNotNull(result.getEmployeeCountList());
    assertEquals(result.getEmployeeCountList().size(), 1);
    assertNull(source.getEmployeeCountList());
  }

  // tree view assertions
  private void asertTreeList(SubGroupTreeViewModel result) {
    assertNotNull(result);
    assertEquals(result.getSubGroupId(), 1L);
    assertEquals(result.getSubGroupName(), "testGroup1");
    assertEquals(result.getSubGroupId(), 1L);
    assertEquals(result.getSubGroupList().size(), 2);
    assertEquals(result.getHierarchyLevel(), 0);
    assertEquals(result.getSubGroupList().get(0).getSubGroupName(), "testGroup1");
    assertEquals(result.getSubGroupList().get(0).getHierarchyLevel(), 1L);
    assertEquals(result.getSubGroupList().get(0).getHierarchyLevel(), 1L);
    assertEquals(result.getSubGroupList().get(0).getGroupId(), 1L);
    assertEquals(result.getSubGroupList().get(0).getSubGroupId(), 1L);
  }

  // save sub group assertions
  private void assertSaveSubGroup(SubGroup subGroupResponse) {
    assertThat(subGroupResponse.getName()).isEqualTo("testGroup1");
    assertThat(subGroupResponse.getId()).isEqualTo(1L);
    assertThat(subGroupResponse.getHealthPlanIds().listIterator(0).next()).isEqualTo("test1");
    assertThat(subGroupResponse.getHealthPlanIds().listIterator(1).next()).isEqualTo("test2");
    assertThat(subGroupResponse.getTin()).isEqualTo("tin");
    assertThat(subGroupResponse.getAddresses().listIterator(0).next().getCity())
        .isEqualTo("vijayawada");
    assertThat(subGroupResponse.getAddresses().listIterator(0).next().getCountryCd())
        .isEqualTo("520011");
    assertThat(subGroupResponse.getAddresses().listIterator(0).next().getCounty())
        .isEqualTo("india");
    assertThat(subGroupResponse.getAddresses().listIterator(0).next().getZip()).isEqualTo("523009");
    assertThat(subGroupResponse.getAddresses().listIterator(0).next().getZipExtn())
        .isEqualTo("78787");
  }
}
