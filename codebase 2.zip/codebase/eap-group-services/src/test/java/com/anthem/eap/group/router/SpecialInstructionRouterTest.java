package com.anthem.eap.group.router;

import static com.anthem.eap.group.constants.GroupConstants.ZONE_UTC;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.utils.SpecialInstructionUtil;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.SpecialInstruction;
import com.anthem.eap.model.group.AbstractGroup;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@DisplayName("Add/Update/Delete special instructions for an active account profile of a group")
class SpecialInstructionRouterTest extends AbstractPersistableUnitTests {

  @Autowired private GroupRepository groupRepository;
  @Autowired private SubGroupRepository subGroupRepository;

  String SUBGROUP = "/subgroup";

  @BeforeEach
  private void scriptInitialize() {
    groupRepository
        .saveAll(
            Arrays.asList(
                SpecialInstructionUtil.getGroupWithSpecialInstructions(),
                SpecialInstructionUtil.getGroupWithOutSpecialInstructions()))
        .blockLast();
    subGroupRepository
        .saveAll(
            Arrays.asList(
                SpecialInstructionUtil.getSubGroupWithSpecialInstructions(),
                SpecialInstructionUtil.getSubGroupWithOutSpecialInstructions()))
        .blockLast();
  }

  @Test
  @DisplayName(
      "Add a special instruction when active account profile specialInstructions are empty")
  @Order(1)
  void addOneSpecialInstructionOfGroupTest() {
    SpecialInstruction requestSPIns1 = SpecialInstructionUtil.getSpecialInstruction1();
    List<SpecialInstruction> spIns = Arrays.asList(requestSPIns1);

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(1, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
            });

    Mono<Group> dbObject = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbObject)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Add multiple special instructions when active account profile specialInstructions are empty")
  @Order(2)
  void addMultipleSpecialInstructionsOfGroupTest() {
    SpecialInstruction requestSPIns1 = SpecialInstructionUtil.getSpecialInstruction1();
    SpecialInstruction requestSPIns2 = SpecialInstructionUtil.getSpecialInstruction3();
    SpecialInstruction requestSPIns3 = SpecialInstructionUtil.getSpecialInstruction5();
    List<SpecialInstruction> spIns = Arrays.asList(requestSPIns1, requestSPIns2, requestSPIns3);

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(3, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(requestSPIns2, response.get(1));
              assertSpecialInstruction(requestSPIns3, response.get(2));
            });

    Mono<Group> dbObject = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbObject)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Update the instruction for one of the existing special instruction")
  @Order(3)
  void updateSpecialInstructionOfGroupTest() {
    Group group = SpecialInstructionUtil.getGroupWithSpecialInstructions();
    final List<SpecialInstruction> spIns = getAccountDetails(group, 2L).getSpecialInstructions();
    Mono<Group> dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 2L).getSpecialInstructions();
              for (int i = 0; i < spIns.size(); i++) {
                assertSpecialInstruction(spIns.get(i), resIns.get(i));
              }
            })
        .verifyComplete();

    SpecialInstruction requestSPIns1 = spIns.get(0);
    requestSPIns1.setInstruction("ins1_update");
    requestSPIns1.setSpecialInstructionType("INTERNATIONAL_EAP_SERVICES");
    final List<SpecialInstruction> specialInstructions2 =
        Arrays.asList(requestSPIns1, spIns.get(1), spIns.get(2));

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 2L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(specialInstructions2)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(3, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(spIns.get(1), response.get(1));
              assertSpecialInstruction(spIns.get(2), response.get(2));
            });

    dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(specialInstructions2, result, 2L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Update all the existing instructions")
  @Order(4)
  void updateSpecialInstructionsOfGroupTest() {
    Group group = SpecialInstructionUtil.getGroupWithSpecialInstructions();
    final List<SpecialInstruction> spIns = getAccountDetails(group, 2L).getSpecialInstructions();
    Mono<Group> dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 2L).getSpecialInstructions();
              assertEquals(3, resIns.size());
              for (int i = 0; i < spIns.size(); i++) {
                assertSpecialInstruction(spIns.get(i), resIns.get(i));
              }
            })
        .verifyComplete();

    SpecialInstruction requestSPIns1 = spIns.get(0);
    requestSPIns1.setInstruction("ins1_update");
    requestSPIns1.setSpecialInstructionType("INTERNATIONAL_EAP_SERVICES");
    SpecialInstruction requestSPIns2 = spIns.get(1);
    requestSPIns2.setInstruction("ONSITE_PROVIDER");
    SpecialInstruction requestSPIns3 = spIns.get(2);
    requestSPIns3.setInstruction("ORGANIZATIONAL_CHANGES");
    requestSPIns3.setEffDate(requestSPIns3.getEffDate().plusDays(30));
    final List<SpecialInstruction> specialInstructions2 =
        Arrays.asList(requestSPIns1, requestSPIns2, requestSPIns3);

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 2L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(specialInstructions2)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(3, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(requestSPIns2, response.get(1));
              assertSpecialInstruction(requestSPIns3, response.get(2));
            });

    dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(specialInstructions2, result, 2L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Replace all existing special instructions with the selected special instructions")
  @Order(5)
  void replaceAllSpecialInstructionsOfGroupTest() {
    Mono<Group> dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 2L).getSpecialInstructions();
              assertEquals(3, resIns.size());
            })
        .verifyComplete();

    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction2(),
            SpecialInstructionUtil.getSpecialInstruction3(),
            SpecialInstructionUtil.getSpecialInstruction4(),
            SpecialInstructionUtil.getSpecialInstruction5());

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 2L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(5, response.size());
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction1(), response.get(0));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction2(), response.get(1));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction3(), response.get(2));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction4(), response.get(3));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction5(), response.get(4));
            });

    dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 2L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Delete all existing special instructions, when all special instructions are unselected")
  @Order(6)
  void deleteAllSpecialInstructionsOfGroupTest() {
    Mono<Group> dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 2L).getSpecialInstructions();
              assertEquals(3, resIns.size());
            })
        .verifyComplete();

    final List<SpecialInstruction> spIns = Arrays.asList();

    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 2L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(0, response.size());
            });

    dbGroup = mongoTemplate.findById(1L, Group.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 2L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Negative Test: Throw group not found exception when the group doesn't exist with given Id")
  @Order(7)
  void throwGroupNotFoundExceptionTest() {
    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction5());
    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 100L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(spIns), new ParameterizedTypeReference<List<SpecialInstruction>>() {})
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @DisplayName(
      "Negative Test: Throw account profile not found exception when the account profile doesn't exist with given Id")
  @Order(8)
  void throwGroupAccountProfileNotFoundExceptionTest() {
    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction5());
    webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 100L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(spIns), new ParameterizedTypeReference<List<SpecialInstruction>>() {})
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @DisplayName(
      "Add a special instruction when active account profile specialInstructions are empty")
  @Order(9)
  void addOneSpecialInstructionOfSubGroupTest() {
    SpecialInstruction requestSPIns1 = SpecialInstructionUtil.getSpecialInstruction1();
    List<SpecialInstruction> spIns = Arrays.asList(requestSPIns1);

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(1, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
            });

    Mono<SubGroup> dbObject = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbObject)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Add multiple special instructions when active account profile specialInstructions are empty")
  @Order(10)
  void addMultipleSpecialInstructionsTest() {
    SpecialInstruction requestSPIns1 = SpecialInstructionUtil.getSpecialInstruction1();
    SpecialInstruction requestSPIns2 = SpecialInstructionUtil.getSpecialInstruction5();
    List<SpecialInstruction> spIns = Arrays.asList(requestSPIns1, requestSPIns2);

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(2, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(requestSPIns2, response.get(1));
            });

    Mono<SubGroup> dbObject = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbObject)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Update the instruction for one of the existing special instruction")
  @Order(11)
  void updateSpecialInstructionTest() {
    SubGroup subGroup = SpecialInstructionUtil.getSubGroupWithSpecialInstructions();
    final List<SpecialInstruction> spIns = getAccountDetails(subGroup, 1L).getSpecialInstructions();
    Mono<SubGroup> dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 1L).getSpecialInstructions();
              assertEquals(2, resIns.size());
              for (int i = 0; i < spIns.size(); i++) {
                assertSpecialInstruction(spIns.get(i), resIns.get(i));
              }
            })
        .verifyComplete();

    SpecialInstruction requestSPIns1 = spIns.get(0);
    requestSPIns1.setInstruction("ins1_update");
    requestSPIns1.setSpecialInstructionType("INTERNATIONAL_EAP_SERVICES");
    final List<SpecialInstruction> specialInstructions2 =
        Arrays.asList(requestSPIns1, spIns.get(1));

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(specialInstructions2)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(2, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(spIns.get(1), response.get(1));
            });

    dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(specialInstructions2, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Update all the existing instructions")
  @Order(12)
  void updateSpecialInstructionsTest() {
    SubGroup group = SpecialInstructionUtil.getSubGroupWithSpecialInstructions();
    final List<SpecialInstruction> spIns = getAccountDetails(group, 1L).getSpecialInstructions();
    Mono<SubGroup> dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 1L).getSpecialInstructions();
              assertEquals(2, resIns.size());
              for (int i = 0; i < spIns.size(); i++) {
                assertSpecialInstruction(spIns.get(i), resIns.get(i));
              }
            })
        .verifyComplete();

    SpecialInstruction requestSPIns1 = spIns.get(0);
    requestSPIns1.setInstruction("ins1_update");
    requestSPIns1.setSpecialInstructionType("INTERNATIONAL_EAP_SERVICES");
    SpecialInstruction requestSPIns2 = spIns.get(1);
    requestSPIns2.setInstruction("ONSITE_PROVIDER");
    SpecialInstruction requestSPIns3 = SpecialInstructionUtil.getSpecialInstruction3();
    final List<SpecialInstruction> specialInstructions2 =
        Arrays.asList(requestSPIns1, requestSPIns2, requestSPIns3);

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(specialInstructions2)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(3, response.size());
              assertSpecialInstruction(requestSPIns1, response.get(0));
              assertSpecialInstruction(requestSPIns2, response.get(1));
              assertSpecialInstruction(requestSPIns3, response.get(2));
            });

    dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(specialInstructions2, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName("Replace all existing special instructions with the selected special instructions")
  @Order(13)
  void replaceAllSpecialInstructionsTest() {
    Mono<SubGroup> dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 1L).getSpecialInstructions();
              assertEquals(2, resIns.size());
            })
        .verifyComplete();

    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction2(),
            SpecialInstructionUtil.getSpecialInstruction4(),
            SpecialInstructionUtil.getSpecialInstruction5());

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(4, response.size());
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction1(), response.get(0));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction2(), response.get(1));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction4(), response.get(2));
              assertSpecialInstruction(
                  SpecialInstructionUtil.getSpecialInstruction5(), response.get(3));
            });

    dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Delete all existing special instructions, when all special instructions are unselected")
  @Order(14)
  void deleteAllSpecialInstructionsOfAnActiveAccountProfile() {
    Mono<SubGroup> dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(
            result -> {
              List<SpecialInstruction> resIns =
                  getAccountDetails(result, 1L).getSpecialInstructions();
              assertEquals(2, resIns.size());
            })
        .verifyComplete();

    final List<SpecialInstruction> spIns = Arrays.asList();

    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(spIns)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SpecialInstruction.class)
        .value(
            response -> {
              assertNotNull(response);
              assertEquals(0, response.size());
            });

    dbGroup = mongoTemplate.findById(1L, SubGroup.class);
    StepVerifier.create(dbGroup)
        .assertNext(result -> verifySpecialInstructions(spIns, result, 1L))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Negative Test: Throw group not found exception when the group doesn't exist with given Id")
  @Order(15)
  void throwGroupNotFoundException() {
    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction5());
    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 100L, 1L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(spIns), new ParameterizedTypeReference<List<SpecialInstruction>>() {})
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @DisplayName(
      "Negative Test: Throw account profile not found exception when the account profile doesn't exist with given Id")
  @Order(16)
  void throwAccountProfileNotFoundException() {
    final List<SpecialInstruction> spIns =
        Arrays.asList(
            SpecialInstructionUtil.getSpecialInstruction1(),
            SpecialInstructionUtil.getSpecialInstruction5());
    webClient
        .put()
        .uri(SUBGROUP + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_SPECIAL_INSTRUCTIONS_PATH, 1L, 100L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(spIns), new ParameterizedTypeReference<List<SpecialInstruction>>() {})
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @DisplayName(
      "Negative Test: Throw account profile not active exception when the account profile is found to be inactive")
  @Order(17)
  void throwAccountProfileNotActiveException() {
    assertTrue(true);
  }

  private void assertSpecialInstruction(SpecialInstruction request, SpecialInstruction response) {
    assertNotNull(response);
    assertEquals(request.getInstruction(), response.getInstruction());
    assertEquals(request.getSpecialInstructionType(), response.getSpecialInstructionType());
    ZonedDateTime reqEffDate = request.getEffDate().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    ZonedDateTime resEffDate = response.getEffDate().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    assertEquals(reqEffDate.getYear(), resEffDate.getYear());
    assertEquals(reqEffDate.getMonth(), resEffDate.getMonth());
    assertEquals(reqEffDate.getDayOfMonth(), resEffDate.getDayOfMonth());
  }

  private void verifySpecialInstructions(
      List<SpecialInstruction> specialInstructions, AbstractGroup response, Long accountId) {
    assertNotNull(response.getAccountDetails());
    AccountDetails accountDetails = getAccountDetails(response, accountId);
    List<SpecialInstruction> resIns = accountDetails.getSpecialInstructions();
    assertNotNull(resIns);
    assertEquals(specialInstructions.size(), resIns.size());
    for (int i = 0; i < specialInstructions.size(); i++) {
      assertSpecialInstruction(specialInstructions.get(i), resIns.get(i));
    }

    // Assert Group/Sub Group lastModifiedBy and lastModifiedDate
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    ZonedDateTime groupLastModifiedDate =
        response.getLastModifiedDate().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    ZonedDateTime accountLastModifiedDate =
        accountDetails.getLastModifiedDate().withZoneSameInstant(ZoneId.of(ZONE_UTC));

    assertEquals("System", response.getLastModifiedBy());
    assertEquals(todayDate.getYear(), groupLastModifiedDate.getYear());
    assertEquals(todayDate.getMonth(), groupLastModifiedDate.getMonth());
    assertEquals(todayDate.getDayOfMonth(), groupLastModifiedDate.getDayOfMonth());

    // Assert AccountDetails lastModifiedBy and lastModifiedDate
    assertEquals("System", accountDetails.getLastModifiedBy());
    assertEquals(todayDate.getYear(), accountLastModifiedDate.getYear());
    assertEquals(todayDate.getMonth(), accountLastModifiedDate.getMonth());
    assertEquals(todayDate.getDayOfMonth(), accountLastModifiedDate.getDayOfMonth());
  }

  private AccountDetails getAccountDetails(AbstractGroup response, Long accountId) {
    return response.getAccountDetails().stream()
        .filter(a -> Objects.equals(a.getId(), accountId))
        .findFirst()
        .get();
  }
}
