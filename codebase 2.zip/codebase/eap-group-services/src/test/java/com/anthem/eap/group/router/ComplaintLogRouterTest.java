package com.anthem.eap.group.router;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.ComplaintLogRepository;
import com.anthem.eap.group.utils.ComplaintLogUtils;
import com.anthem.eap.model.complaints.ComplaintLog;
import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class ComplaintLogRouterTest extends AbstractPersistableUnitTests {
  @Autowired private ComplaintLogRepository repository;

  @BeforeEach
  private void scriptInitialize() {
    ComplaintLog complaint1 = ComplaintLogUtils.getComplaintLog1();
    ComplaintLog complaint2 = ComplaintLogUtils.getComplaintLog2();
    repository.saveAll(Arrays.asList(complaint1, complaint2)).blockLast();
  }

  @Test
  void createComplaintLog() {
    ComplaintLog complaint = ComplaintLogUtils.getComplaintLog3();
    webClient
        .post()
        .uri("/complaint")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(complaint), ComplaintLog.class)
        .exchange()
        .expectHeader()
        .location("/complaint/3")
        .expectStatus()
        .isCreated();

    Mono<ComplaintLog> dbObject = mongoTemplate.findById(3L, ComplaintLog.class);

    StepVerifier.create(dbObject)
        .assertNext(result -> verifyComplaintLog(complaint, result))
        .verifyComplete();
  }

  @Test
  void getComplaintById() {

    webClient
        .get()
        .uri("/complaint/{id}", "2")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ComplaintLog.class)
        .consumeWith(
            response -> {
              ComplaintLog result = response.getResponseBody();
              verifyComplaintLog(ComplaintLogUtils.getComplaintLog2(), result);
            });
  }

  @Test
  void updateComplaint1() {
    ComplaintLog complaint = ComplaintLogUtils.getComplaintLog2();
    complaint.setGroupType("groups");
    complaint.setGroup(ComplaintLogUtils.createGroupDetails(complaint, 2L));
    complaint.setNotes("Complaint about group update");
    complaint.setActivityType("OTHER_COMPLAINT_ISSUE");
    complaint.setComplaintAbout("MARKETING");
    complaint.setOtherGroup("");

    webClient
        .put()
        .uri("/complaint/{id}", "2")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(complaint), ComplaintLog.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<ComplaintLog> dbObject = mongoTemplate.findById(2L, ComplaintLog.class);
    StepVerifier.create(dbObject)
        .assertNext(results -> verifyComplaintLog(complaint, results))
        .verifyComplete();
  }

  @Test
  void updateComplaint2() {
    ComplaintLog complaint = ComplaintLogUtils.getComplaintLog1();
    complaint.setGroupType("other");
    complaint.setGroup(null);
    complaint.setNotes("Complaint about other group update");
    complaint.setActivityType("QUALITY_OF_SERVICE");
    complaint.setComplaintAbout("MARKETING");
    complaint.setOtherGroup("Other group update1");

    webClient
        .put()
        .uri("/complaint/{id}", "1")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(complaint), ComplaintLog.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<ComplaintLog> dbObject = mongoTemplate.findById(1L, ComplaintLog.class);
    StepVerifier.create(dbObject)
        .assertNext(results -> verifyComplaintLog(complaint, results))
        .verifyComplete();
  }

  @Test
  void getAllComplaints() {
    Flux<ComplaintLog> complaints =
        webClient
            .get()
            .uri("/complaint")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(ComplaintLog.class)
            .getResponseBody();

    StepVerifier.create(complaints)
        .assertNext(result -> verifyComplaintLog(ComplaintLogUtils.getComplaintLog2(), result))
        .assertNext(result -> verifyComplaintLog(ComplaintLogUtils.getComplaintLog1(), result))
        .verifyComplete();
  }

  private void verifyComplaintLog(ComplaintLog expected, ComplaintLog result) {

    assertEquals(expected.getId(), result.getId());
    assertEquals(expected.getActivityType(), result.getActivityType());
    assertEquals(expected.getComplaintAbout(), result.getComplaintAbout());
    assertEquals(expected.getGroupType(), result.getGroupType());
    if (StringUtils.equals("groups", result.getGroupType())) {
      assertEquals(expected.getGroup().getId(), result.getGroup().getId());
      assertEquals("", expected.getOtherGroup());
    } else {
      assertEquals(null, expected.getGroup());
      assertEquals(expected.getOtherGroup(), result.getOtherGroup());
    }
    assertEquals(expected.getNotes(), result.getNotes());
    assertEquals(expected.getCreatedBy(), result.getCreatedBy());
    assertEquals(expected.getLogDate().getYear(), result.getLogDate().getYear());
    assertEquals(expected.getLogDate().getMonth(), result.getLogDate().getMonth());
    assertEquals(expected.getLogDate().getDayOfMonth(), result.getLogDate().getDayOfMonth());
  }
}
