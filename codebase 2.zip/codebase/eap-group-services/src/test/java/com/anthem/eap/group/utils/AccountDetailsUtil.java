package com.anthem.eap.group.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AccountDetailsUtil {

  public static AccountDetails getAccountDetails() {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setProduct("Product");
    accountDetails.setPlan("Plan");
    accountDetails.setDcbtPortal("Portal Name");
    accountDetails.setEapPhone("EAP PHONE");
    accountDetails.setProgramName("Program Name");
    accountDetails.setEligibilityNotes("Eligibility Notes");
    accountDetails.setOrigEffDate(LocalDate.parse("2021-09-22"));
    accountDetails.setEffectiveDate(LocalDate.parse("2021-10-22"));
    accountDetails.setExpiryDate(LocalDate.parse("2022-09-22"));
    return accountDetails;
  }

  public static AccountDetails updateGroupAccountDetails() {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setProduct("Product Update");
    accountDetails.setPlan("Plan Update");
    accountDetails.setDcbtPortal("Portal Name Update");
    accountDetails.setEapPhone("EAP PHONE Update");
    accountDetails.setProgramName("Program Name Update");
    accountDetails.setEligibilityNotes("Eligibility Notes Update....");
    accountDetails.setOrigEffDate(LocalDate.parse("2022-10-22"));
    accountDetails.setEffectiveDate(LocalDate.parse("2022-10-22"));
    accountDetails.setExpiryDate(LocalDate.parse("2022-12-22"));
    return accountDetails;
  }

  public static AccountDetails updateSubGroupAccountDetails() {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setProduct("Sub Group Product Update");
    accountDetails.setPlan("Sub Group Plan Update");
    accountDetails.setDcbtPortal("Sub Group Portal Name Update");
    accountDetails.setEapPhone("Sub Group EAP PHONE Update");
    accountDetails.setProgramName("Sub Group Program Name Update");
    accountDetails.setEligibilityNotes("Sub Group Eligibility Notes Update....");
    accountDetails.setOrigEffDate(LocalDate.parse("2022-10-22"));
    accountDetails.setEffectiveDate(LocalDate.parse("2022-10-22"));
    accountDetails.setExpiryDate(LocalDate.parse("2022-12-22"));
    return accountDetails;
  }

  public static AccountDetails getActiveAccounts1(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    LocalDate currentDate = (LocalDate.parse("2021-11-29"));
    accountDetails.setProduct("Product Update");
    accountDetails.setPlan("Plan Update");
    accountDetails.setDcbtPortal("Portal Name Update");
    accountDetails.setEapPhone("EAP PHONE Update");
    accountDetails.setProgramName("Program Name Update");
    accountDetails.setEligibilityNotes("Eligibility Notes Update....");
    accountDetails.setOrigEffDate(LocalDate.parse("2022-10-22"));
    accountDetails.setEffectiveDate(LocalDate.parse("2021-10-22"));
    accountDetails.setExpiryDate(LocalDate.parse("2023-12-22"));
    if (accountDetails.getEffectiveDate().isBefore(currentDate)
        && accountDetails.getExpiryDate().isAfter(currentDate)) {
      return accountDetails;
    } else return null;
  }

  public static AccountDetails getActiveAccounts2(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    LocalDate currentDate = (LocalDate.parse("2021-11-29"));
    accountDetails.setProduct("Product");
    accountDetails.setPlan("Plan");
    accountDetails.setDcbtPortal("Portal Name");
    accountDetails.setEapPhone("EAP PHONE");
    accountDetails.setProgramName("Program Name");
    accountDetails.setEligibilityNotes("Eligibility Notes....");
    accountDetails.setOrigEffDate(LocalDate.parse("2022-10-22"));
    accountDetails.setEffectiveDate(LocalDate.parse("2021-10-22"));
    accountDetails.setExpiryDate(LocalDate.parse("2023-12-22"));
    if (accountDetails.getEffectiveDate().isBefore(currentDate)
        && accountDetails.getExpiryDate().isAfter(currentDate)) {
      return accountDetails;
    } else return null;
  }

  public static Group getGroup() {
    Group group = new Group();
    group.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails = getAccountProfile(1l);
    accountDetails.add(accDetails);
    group.setAccountDetails(accountDetails);
    return group;
  }

  public static SubGroup getSubGroup() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails = getAccountProfile(1l);
    accountDetails.add(accDetails);
    subGroup.setAccountDetails(accountDetails);
    return subGroup;
  }

  private static AccountDetails getAccountProfile(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    return accountDetails;
  }

  public static Group getGroupWithActiveAccount() {
    Group group = new Group();
    group.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails activeAccount = getActiveAccounts1(1l);
    accountDetails.add(activeAccount);
    group.setAccountDetails(accountDetails);
    return group;
  }

  public static SubGroup getSubGroupWithActiveAccount() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails activeSubGroup = getActiveAccounts2(1l);
    accountDetails.add(activeSubGroup);
    subGroup.setAccountDetails(accountDetails);
    return subGroup;
  }

  public static Group getGroupRenewalAccountDetails() {
    Group group = new Group();
    group.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accountData = new AccountDetails();
    accountData.setProduct("Product");
    accountData.setPlan("Plan");
    accountData.setDcbtPortal("Portal Name");
    accountData.setEapPhone("EAP PHONE");
    accountData.setProgramName("Program Name");
    accountData.setEligibilityNotes("Eligibility Notes");
    accountData.setOrigEffDate(LocalDate.parse("2021-09-22"));
    accountData.setEffectiveDate(LocalDate.parse("2021-10-22"));
    accountData.setExpiryDate(LocalDate.parse("2022-09-22"));
    accountData.setRenewalDate(LocalDate.parse("2021-11-30"));
    if (accountData.getRenewalDate() != null) {
      accountData.setEffectiveDate(accountData.getRenewalDate());
    } else {
      accountData.setEffectiveDate(accountData.getExpiryDate().plusDays(1));
    }
    group.setAccountDetails(accountDetails);
    return group;
  }

  public static SubGroup getSubGroupRenewalAccountDetails() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(1l);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accountData = new AccountDetails();
    accountData.setProduct("Product Sub Group");
    accountData.setPlan("Plan");
    accountData.setProgramName("Program Name Sub Group");
    accountData.setEligibilityNotes("Eligibility Notes");
    accountData.setOrigEffDate(LocalDate.parse("2020-09-21"));
    accountData.setEffectiveDate(LocalDate.parse("2021-12-22"));
    accountData.setExpiryDate(LocalDate.parse("2022-09-22"));
    accountData.setRenewalDate(LocalDate.parse("2022-10-30"));
    if (accountData.getRenewalDate() != null) {
      accountData.setEffectiveDate(accountData.getRenewalDate());
    } else {
      accountData.setEffectiveDate(accountData.getExpiryDate().plusDays(1));
    }
    subGroup.setAccountDetails(accountDetails);
    return subGroup;
  }

  public static void verifyAccountDetails(Group result, AccountDetails expected) {
    assertNotNull(expected);
    assertNotNull(expected.getId());
    assertEquals(
        expected.getProduct(), result.getAccountDetails().listIterator(0).next().getProduct());
    assertEquals(expected.getPlan(), result.getAccountDetails().listIterator(0).next().getPlan());
    assertEquals(
        expected.getProgramName(),
        result.getAccountDetails().listIterator(0).next().getProgramName());
    assertEquals(
        expected.getDcbtPortal(),
        result.getAccountDetails().listIterator(0).next().getDcbtPortal());
    assertEquals(
        expected.getEapPhone(), result.getAccountDetails().listIterator(0).next().getEapPhone());
    assertEquals(
        expected.getEligibilityNotes(),
        result.getAccountDetails().listIterator(0).next().getEligibilityNotes());
    assertEquals(
        expected.getOrigEffDate(),
        result.getAccountDetails().listIterator(0).next().getOrigEffDate());
    assertEquals(
        expected.getEffectiveDate(),
        result.getAccountDetails().listIterator(0).next().getEffectiveDate());
    assertEquals(
        expected.getExpiryDate(),
        result.getAccountDetails().listIterator(0).next().getExpiryDate());
  }
}
