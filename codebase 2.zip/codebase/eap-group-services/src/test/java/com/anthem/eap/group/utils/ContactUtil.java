package com.anthem.eap.group.utils;

import static com.anthem.eap.group.constants.GroupConstants.ZONE_UTC;

import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.user.Name;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ContactUtil {

  public static Contact contactTestData_1() {

    Contact contact = new Contact();
    contact.setId(1L);

    Name name = new Name();
    name.setFirstName("Linda");
    name.setLastName("Smith");

    contact.setName(name);
    contact.setAccountName("Linda001");
    contact.setEmail("linda1@verizon.com");
    contact.setTitle("Account Rep");
    contact.setBrokerNumber(34453424L);
    contact.setTin(55555L);
    contact.setNotes("Added Primary address");
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);

    Address address = new Address();
    address.setStreet1("232 Main street");
    address.setStreet2("Suite 222");
    address.setCity("Savannah2");
    address.setStateCd("KY");
    address.setZip("05551");

    Phone phone = new Phone();
    phone.setNumber("8812522577");
    address.setPhone(phone);

    contact.setAddress(address);
    return contact;
  }

  public static Contact contactTestData_2() {

    Contact contact = new Contact();
    contact.setId(2L);

    Name name = new Name();
    name.setFirstName("Jon");
    name.setLastName("Wilson");

    contact.setName(name);
    contact.setAccountName("JonWilson002");
    contact.setEmail("linda2@verizon.com");
    contact.setTitle("Account Rep");
    contact.setTin(12345L);
    contact.setBrokerNumber(34453424L);
    contact.setNotes("Added Wison address");
    ZonedDateTime todayDate =
        ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC)).plusMinutes(10);
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);

    Address address = new Address();
    address.setStreet1("232 Eve street");
    address.setStreet2("Suite 232");
    address.setCity("Savannah");
    address.setStateCd("GA");
    address.setZip("05553");

    Phone phone = new Phone();
    phone.setNumber("8812522578");
    address.setPhone(phone);

    contact.setAddress(address);
    return contact;
  }

  public static Contact contactTestData_3() {
    Contact contact = new Contact();
    contact.setId(3L);

    Name name = new Name();
    name.setFirstName("Tim");
    name.setLastName("Smith");

    contact.setName(name);
    contact.setAccountName("TimSmith003");
    contact.setEmail("linda3@verizon.com");
    contact.setTitle("Account Rep");
    contact.setBrokerNumber(34453427L);
    contact.setNotes("Added Address of Tim");
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);

    Address address = new Address();
    address.setStreet1("232 Avenue");
    address.setStreet2("Suite 100");
    address.setCity("Savannah");
    address.setStateCd("GA");
    address.setCountryCd("US");
    address.setZip("05552");

    Phone phone = new Phone();
    phone.setNumber("8812522579");
    address.setPhone(phone);

    contact.setAddress(address);
    return contact;
  }
}
