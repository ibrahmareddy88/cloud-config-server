package com.anthem.eap.group.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public class EmployerBenefitsUtil {

  public static SABank getSABank() {
    SABank saBank = new SABank();
    saBank.setBankName("Bank1");
    saBank.setPerYear(100);

    return saBank;
  }

  public static AccountService getAccService() {
    AccountService accServ = new AccountService();
    accServ.setServiceType("CIR Facilitation");
    accServ.setFfsType("N/A");
    return accServ;
  }

  public static EmployerService getEmployerBenefitNote() {
    EmployerService accServ = new EmployerService();
    accServ.setBenefitNotes("Testing Benefit Notes");
    return accServ;
  }

  public static Group getGroup() {
    Group group1 = new Group();
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails1 = getAccountProfile(1L);
    EmployerService empServ = new EmployerService();
    SABank saBank = getSABank();
    saBank.setId(1L);
    SABank saBank2 = new SABank();
    saBank2.setId(13L);
    saBank2.setBankName("Test Bank 2");
    List<SABank> saBankList = new ArrayList<>();
    saBankList.add(saBank);
    empServ.setSaBank(saBankList);
    AccountService accServ = getAccService();
    accServ.setId(3L);
    accServ.setBank(saBank.getId());
    AccountService accServ2 = getAccService();
    accServ2.setId(13L);
    List<AccountService> accServList = new ArrayList<>();
    accServList.add(accServ);
    accDetails1.setEmployerServices(empServ);
    accountDetails.add(accDetails1);
    group1.setAccountDetails(accountDetails);
    return group1;
  }

  public static SubGroup getSubGroup() {
    SubGroup group1 = new SubGroup();
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails1 = getAccountProfile(1L);
    EmployerService empServ = new EmployerService();
    SABank saBank = getSABank();
    saBank.setId(1L);
    SABank saBank2 = new SABank();
    saBank2.setId(14L);
    saBank2.setBankName("Test Bank 3");
    List<SABank> saBankList = new ArrayList<>();
    saBankList.add(saBank);
    saBankList.add(saBank2);
    empServ.setSaBank(saBankList);
    empServ.setBenefitNotes(getEmployerBenefitNote().getBenefitNotes());
    AccountService accServ = new AccountService();
    accServ.setId(3L);
    List<AccountService> accServList = new ArrayList<>();
    accServList.add(accServ);
    empServ.setAccountServices(accServList);
    accDetails1.setEmployerServices(empServ);
    accountDetails.add(accDetails1);
    group1.setAccountDetails(accountDetails);
    return group1;
  }

  public static Group updateSABankGroupTestData(Long bankId) {
    Group group3 = getGroup();
    List<SABank> saBankList =
        group3.getAccountDetails().listIterator(0).next().getEmployerServices().getSaBank();
    saBankList.removeIf(bank -> bank.getId().longValue() == bankId.longValue());
    return group3;
  }

  public static SubGroup updateSABankSubGroupTestData(Long bankId) {
    SubGroup subGroup = getSubGroup();
    List<SABank> saBankList =
        subGroup.getAccountDetails().listIterator(0).next().getEmployerServices().getSaBank();
    saBankList.removeIf(bank -> bank.getId().longValue() == bankId.longValue());
    return subGroup;
  }

  public static AccountDetails getAccountProfile(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    return accountDetails;
  }

  public static void verifySABank(SABank bankDetails, SABank expected) {
    assertNotNull(expected);
    assertNotNull(expected.getId());
    assertEquals(expected.getBankName(), bankDetails.getBankName());
    assertEquals(expected.getPerYear(), expected.getPerYear());
  }

  public static void verifyAccountService(AccountService serviceDetails, AccountService expected) {
    assertNotNull(expected);
    assertNotNull(expected.getId());
    assertEquals(expected.getServiceType(), serviceDetails.getServiceType());
    assertEquals(expected.getFfsType(), serviceDetails.getFfsType());
  }

  public static void verifyEmployerServiceWithNote(
      EmployerService empService, EmployerService expected) {
    assertNotNull(expected);
    assertNotNull(expected.getBenefitNotes());
    assertEquals(expected.getBenefitNotes(), empService.getBenefitNotes());
  }

  public static void enqueueMockResponse(MockWebServer mockWebServer, SABank bank)
      throws JsonProcessingException {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(bank)));
  }
}
