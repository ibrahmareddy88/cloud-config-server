package com.anthem.eap.group.utils;

import com.anthem.eap.model.complaints.ComplaintLog;
import com.anthem.eap.model.complaints.ComplaintLog.GroupDetails;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ComplaintLogUtils {

  public static ComplaintLog getComplaintLog1() {
    ComplaintLog complaint = new ComplaintLog();
    complaint.setId(1L);
    complaint.setActivityType("ACCESS_TO_SERVICE");
    complaint.setComplaintAbout("BILLING_FINANCE_CLAIMS");
    complaint.setGroupType("groups");
    complaint.setGroup(createGroupDetails(complaint, 1L));
    complaint.setNotes("Complaint about group1");
    complaint.setCreatedBy("System");
    complaint.setOtherGroup("");
    complaint.setLogDate(
        ZonedDateTime.of(2021, 8, 2, 10, 44, 45, 567, ZoneId.of("America/New_York")));
    return complaint;
  }

  public static ComplaintLog getComplaintLog2() {
    ComplaintLog complaint = new ComplaintLog();
    complaint.setId(2L);
    complaint.setActivityType("QUALITY_OF_SERVICE");
    complaint.setComplaintAbout("BLI_TRAINER");
    complaint.setGroupType("other");
    complaint.setOtherGroup("Other Group Name");
    complaint.setNotes("Complaint about other group");
    complaint.setCreatedBy("System");
    complaint.setGroup(null);
    complaint.setLogDate(
        ZonedDateTime.of(2021, 8, 2, 10, 44, 45, 567, ZoneId.of("America/New_York")));
    return complaint;
  }

  public static ComplaintLog getComplaintLog3() {
    ComplaintLog complaint = new ComplaintLog();
    complaint.setId(3L);
    complaint.setActivityType("QUALITY_OF_SERVICE");
    complaint.setComplaintAbout("OPERATIONS_CCR");
    complaint.setGroupType("groups");
    complaint.setGroup(createGroupDetails(complaint, 2L));
    complaint.setNotes("Complaint about group2 note");
    complaint.setCreatedBy("System");
    complaint.setOtherGroup("");
    complaint.setLogDate(
        ZonedDateTime.of(2021, 8, 2, 10, 44, 45, 567, ZoneId.of("America/New_York")));
    return complaint;
  }

  public static GroupDetails createGroupDetails(ComplaintLog conplaintLog, long id) {
    GroupDetails groupDetails = conplaintLog.new GroupDetails();
    groupDetails.setId(1L);
    return groupDetails;
  }
}
