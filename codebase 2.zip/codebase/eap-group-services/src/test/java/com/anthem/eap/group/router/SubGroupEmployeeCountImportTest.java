package com.anthem.eap.group.router;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.GroupEmployeeCountUploadTest;
import com.anthem.eap.group.model.SubGroupEmployeeCountImport;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.service.EmployeeCountUploadService;
import com.anthem.eap.group.util.SubGroupUtil;
import com.anthem.eap.model.group.EmployeeCount;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import okhttp3.mockwebserver.MockWebServer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;

class SubGroupEmployeeCountImportTest extends AbstractPersistableUnitTests {
  @Autowired EmployeeCountUploadService employeeCountUploadService;
  @Autowired SubGroupRepository subGroupRepository;
  @Autowired GroupRepository groupRepository;
  EmployeeCount employeeCount = new EmployeeCount();
  public static final Log log = LogFactory.getLog(GroupEmployeeCountUploadTest.class);

  private static Group group = new Group();
  private static SubGroup subGroup = new SubGroup();
  private static final ZonedDateTime zonedDateTimeOf =
      ZonedDateTime.of(2021, 11, 11, 0, 0, 0, 0, ZoneId.of("UTC"));
  private MockWebServer mockWebServer = new MockWebServer();

  @BeforeEach
  private void init() {

    subGroup = getSubGroupWithEmployeeCount();
    group = getGroupDetails();
    groupRepository.save(group).block();
    subGroupRepository.save(subGroup).block();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  @Order(1)
  @Description("should upload sub group employee count")
  void uploadSubGroupEmployeeCountSuccess() {

    List<SubGroupEmployeeCountImport> employeeCountsList =
        SubGroupUtil.employeeCountTestData(
            "Group 1", "1L", "1L", "Sub Group 1", "120", "10/11/2021");

    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(employeeCountsList), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> importData = response.getResponseBody();
              assertNotNull(importData.get(0).getError());
              assertEquals("1L", importData.get(0).getGroupId());
              assertEquals(subGroup.getGroupId(), group.getId());
              assertEquals("1L", importData.get(0).getSubGroupId());
              assertNotEquals(
                  subGroup.getEmployeeCountList().get(0).getCount(), importData.get(0).getCount());
              assertEquals("10/11/2021", importData.get(0).getAsOfDate());
              importData.clear();
            });
  }

  @Test
  @Order(2)
  @Description("upload failed with response invalid group id and as of date")
  void testEmployeeCountWithNullGroupIdAndInvalidAsOfDate() {
    SubGroupEmployeeCountImport groupEmployeeCountImport =
        SubGroupUtil.subGroupEmployeeCountImportTestData(null, "1", "120", "07/06/20z");
    SubGroupUtil.validateGroupAndSubGroup(group, groupEmployeeCountImport, subGroup);
    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(groupEmployeeCountImport), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> responseData = response.getResponseBody();
              assertEquals("Invalid Group ID, Invalid As Of Date", responseData.get(0).getError());
              responseData.clear();
            });
  }

  @Test
  @Order(3)
  @Description("upload failed with response  invalid format fields")
  void testEmployeeCountWithInValidFormatAttributes() {
    SubGroupEmployeeCountImport groupEmployeeCountImport =
        SubGroupUtil.subGroupEmployeeCountImportTestData("1z", "1", "120z", "07/06/20z");
    SubGroupUtil.validateGroupAndSubGroup(group, groupEmployeeCountImport, subGroup);

    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(groupEmployeeCountImport), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> importData = response.getResponseBody();
              assertEquals(
                  "Invalid Group ID, Invalid Employee Count, Invalid As Of Date",
                  importData.get(0).getError());

              importData.clear();
            });
  }

  @Test
  @Order(4)
  @Description("upload failed with response null group and subgroup id")
  void testEmployeeCountWithGroupIdAndSubGroupIdNullAttributes() {
    SubGroupEmployeeCountImport groupEmployeeCountImport1 =
        SubGroupUtil.subGroupEmployeeCountImportTestData(null, null, "20", "10/11/2021");
    SubGroupUtil.validateGroupAndSubGroup(group, groupEmployeeCountImport1, subGroup);
    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(groupEmployeeCountImport1), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> importData = response.getResponseBody();
              assertEquals("Invalid Group ID, Invalid Subgroup ID", importData.get(0).getError());
              importData.clear();
            });
  }

  @Test
  @Order(5)
  @Description("upload failed with response duplicate record")
  void testDuplicateRecord() {
    List<SubGroupEmployeeCountImport> employeeCountsList =
        new ArrayList<SubGroupEmployeeCountImport>();
    SubGroupEmployeeCountImport grpEmpCountData = new SubGroupEmployeeCountImport();

    String grpName = "anthem";
    String grpId = "1";
    String count = "120";
    String asOfDate = "";
    employeeCountsList =
        SubGroupUtil.employeeCountTestData(grpName, grpId, "1", "anthem", count, asOfDate);
    grpEmpCountData.setAsOfDate(asOfDate);
    grpEmpCountData.setCount(count);
    grpEmpCountData.setGroupId(grpId);
    grpEmpCountData.setGroupName(grpName);
    grpEmpCountData.setSubGroupId("1");
    grpEmpCountData.setSubgroupName("anthem");
    employeeCountsList.add(1, grpEmpCountData);
    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(employeeCountsList), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> employeeCountsList1 = response.getResponseBody();
              employeeCountsList1.get(0).setError("");
              employeeCountsList1.get(1).setError("");
              SubGroupUtil.verifyForDuplicateRecords(employeeCountsList1);
              assertEquals("Duplicate Record", employeeCountsList1.get(0).getError());
              assertEquals("Duplicate Record", employeeCountsList1.get(1).getError());
            });
  }

  @Test
  @Order(6)
  @Description("upload failed with response  group and subgroup id not exists in the system")
  void testEmployeeCountWithGroupIdAndSubGroupIdNotExists() {
    SubGroupEmployeeCountImport groupEmployeeCountImport1 =
        SubGroupUtil.subGroupEmployeeCountImportTestData("2L", "2L", "20", "10/11/2021");
    SubGroupUtil.validateGroupAndSubGroup(group, groupEmployeeCountImport1, subGroup);
    webClient
        .post()
        .uri("/subgroup/upload/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(groupEmployeeCountImport1), SubGroupEmployeeCountImport.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(SubGroupEmployeeCountImport.class)
        .consumeWith(
            response -> {
              List<SubGroupEmployeeCountImport> importData = response.getResponseBody();
              assertEquals("Invalid Group ID, Invalid Subgroup ID", importData.get(0).getError());
            });
  }

  private SubGroup getSubGroupWithEmployeeCount() {
    EmployeeCount empcount = new EmployeeCount();
    empcount.setCount("100");
    empcount.setAsOfDate(zonedDateTimeOf);
    List<EmployeeCount> empcountlst = new ArrayList<EmployeeCount>();
    empcountlst.add(empcount);
    subGroup.setGroupId(getGroupDetails().getId());
    subGroup.setId(1L);
    subGroup.setName("Sub Group 1");
    subGroup.setEmployeeCountList(empcountlst);
    return subGroup;
  }

  private Group getGroupDetails() {
    Group grp = new Group();
    grp.setId(1L);
    grp.setName("Group 1");
    return grp;
  }
}
