package com.anthem.eap.group.utils;

import com.anthem.eap.model.group.HealthPlan;
import com.anthem.eap.model.group.HealthPlan.SourceSystem;
import java.time.LocalDate;

public class HealthPlanUtil {

  public static HealthPlan getHealthPlan1() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(1L);
    healthPlan.setHealthPlanId("46");
    healthPlan.setHealthPlanName("UNIVERSAL LEAF TOBACCO CO.INC.");
    healthPlan.setMembershipSource("GROUP TEST");
    healthPlan.setSubgroupId("000046M001");
    healthPlan.setSubgroupName("UNIVERSAL LEAF");
    healthPlan.setContractCode("4FU5");
    healthPlan.setHpccCode("HN0P");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("654");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(126);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan2() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(2L);
    healthPlan.setHealthPlanId("47");
    healthPlan.setHealthPlanName("VIRGINIA BANKERS ASSOCIATION");
    healthPlan.setMembershipSource("TEST GRP");
    healthPlan.setSubgroupId("000047A027");
    healthPlan.setSubgroupName("PIONEER BANK");
    healthPlan.setContractCode("3ZPL");
    healthPlan.setHpccCode("HMVQ");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("453");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(13);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan3() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(3L);
    healthPlan.setHealthPlanId("3628");
    healthPlan.setHealthPlanName("STONINGTON TOWN AND BOARD OF EDUCATION");
    healthPlan.setMembershipSource("GROUP 1");
    healthPlan.setSubgroupId("003628M100");
    healthPlan.setSubgroupName("SPS MISC PPO");
    healthPlan.setContractCode("5HT6");
    healthPlan.setHpccCode("H07U");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-25"));
    healthPlan.setMemCount(2);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan4() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(4L);
    healthPlan.setHealthPlanId("6041");
    healthPlan.setHealthPlanName("CANTON TOWN AND BOARD OF EDUCATION");
    healthPlan.setMembershipSource("EMP GRP SOURCE");
    healthPlan.setSubgroupId("006041M130");
    healthPlan.setSubgroupName("CANTON BOE HSA PARAS");
    healthPlan.setContractCode("5H9H");
    healthPlan.setHpccCode("H05U");
    healthPlan.setProgramName("EAP BASIC");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(58);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan5() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(5L);
    healthPlan.setHealthPlanId("46");
    healthPlan.setHealthPlanName("UNIVERSAL LEAF TOBACCO CO.INC.");
    healthPlan.setMembershipSource("TEST SOURCE");
    healthPlan.setSubgroupId("000046M012");
    healthPlan.setSubgroupName("CIFI");
    healthPlan.setContractCode("4FU5");
    healthPlan.setHpccCode("HN0P");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("098");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(3);
    healthPlan.setSourceSystem(SourceSystem.WGS);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan6() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(6L);
    healthPlan.setHealthPlanId("939");
    healthPlan.setHealthPlanName("TOWN OF MADISON");
    healthPlan.setMembershipSource("EAP TEST");
    healthPlan.setSubgroupId("000939M600");
    healthPlan.setSubgroupName("TOWN OF MADISON POLICE ACTIVE HMO / LOCAL 456");
    healthPlan.setContractCode("5HZ4");
    healthPlan.setHpccCode("H0EU");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(14);
    healthPlan.setSourceSystem(SourceSystem.ISG);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan7() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(7L);
    healthPlan.setHealthPlanId("675");
    healthPlan.setHealthPlanName("HARTFORD PUBLIC SCHOOLS");
    healthPlan.setMembershipSource("EAB");
    healthPlan.setSubgroupId("000675M154");
    healthPlan.setSubgroupName("HARTFORD BD OF ED SUBSTITUTE TEACHERS");
    healthPlan.setContractCode("5X16");
    healthPlan.setHpccCode("H07R");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(15);
    healthPlan.setSourceSystem(SourceSystem.ISG);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan8() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(8L);
    healthPlan.setHealthPlanId("676");
    healthPlan.setHealthPlanName("HARTFORD PUBLIC SCHOOLS");
    healthPlan.setMembershipSource("808");
    healthPlan.setSubgroupId("000675M154");
    healthPlan.setSubgroupName("HARTFORD BD OF ED SUBSTITUTE TEACHERS");
    healthPlan.setContractCode("5X16");
    healthPlan.setHpccCode("H07R");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(15);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }

  public static HealthPlan getHealthPlan9() {
    HealthPlan healthPlan = new HealthPlan();
    healthPlan.setId(9L);
    healthPlan.setHealthPlanId("939");
    healthPlan.setHealthPlanName("CANTON TOWN AND BOARD OF EDUCATION");
    healthPlan.setMembershipSource("EAP TEST");
    healthPlan.setSubgroupId("000939M600");
    healthPlan.setSubgroupName("CANTON BOE HSA PARAS");
    healthPlan.setContractCode("5HZ4");
    healthPlan.setHpccCode("H0EU");
    healthPlan.setProgramName("EAP ENHANCED");
    healthPlan.setControlPlanCode("2864");
    healthPlan.setAsOfDate(LocalDate.parse("2021-09-22"));
    healthPlan.setMemCount(14);
    healthPlan.setSourceSystem(SourceSystem.EDW);
    return healthPlan;
  }
}
