package com.anthem.eap.group.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.common.Phone.PhoneType;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;

public class VendorDetailsUtil {

	public static VendorDetails getVendorDetails() {
		VendorDetails vendorDetails = new VendorDetails();
		Phone phone = new Phone();
		phone.setExtension("111111111L");
		phone.setNumber("12345");
		phone.setType(PhoneType.FAX);
		vendorDetails.setVendorType("Vendor");
		vendorDetails.setName("Vendor_Name");
		vendorDetails.setInstruction("Instruction");
		vendorDetails.setPhone(phone);
		return vendorDetails;
	}
	
	public static VendorDetails updateGroupVendorDetails() {
		VendorDetails vendorDetails = new VendorDetails();
		Phone phone = new Phone();
		phone.setExtension("222222222222L");
		phone.setNumber("0000111223");
		phone.setType(PhoneType.CELL);
		vendorDetails.setVendorType("Vendor Updated");
		vendorDetails.setName("Vendor_Name_Updated");
		vendorDetails.setInstruction("Instruction Updated........");
		vendorDetails.setPhone(phone);
		return vendorDetails;
	}
	

	public static Group getGroup() {
		Group group = new Group();
		group.setId(1l);
		List<AccountDetails> accountDetails = new ArrayList<>();
		AccountDetails accDetails = getAccountProfile(1l);
		VendorDetails vendorDetails = getVendorDetails();
		vendorDetails.setId(1l);
		List<VendorDetails> vendorList = new ArrayList<>();
		vendorList.add(vendorDetails);
		accountDetails.add(accDetails);
		group.setAccountDetails(accountDetails);
		return group;
	}

	public static SubGroup getSubGroup() {
		SubGroup subGroup = new SubGroup();
		subGroup.setId(1l);
		List<AccountDetails> accountDetails = new ArrayList<>();
		AccountDetails accDetails = getAccountProfile(1l);
		VendorDetails vendorDetails = getVendorDetails();
		vendorDetails.setId(1l);
		List<VendorDetails> vendorsList = new ArrayList<>();
		vendorsList.add(vendorDetails);
		accDetails.setVendorDetails(vendorsList);
		accountDetails.add(accDetails);
		subGroup.setAccountDetails(accountDetails);
		return subGroup;
	}

	private static AccountDetails getAccountProfile(Long id) {
		AccountDetails accountDetails = new AccountDetails();
		accountDetails.setId(id);
		return accountDetails;
	}


	public static void verifyVendorDetails(VendorDetails vendorDetails, VendorDetails expected) {
		assertNotNull(expected);
		assertNotNull(expected.getId());
		assertEquals(expected.getVendorType(), vendorDetails.getVendorType());
		assertEquals(expected.getName(), vendorDetails.getName());
		assertEquals(expected.getInstruction(), vendorDetails.getInstruction());
		assertNotNull(expected.getPhone());
		assertEquals(expected.getPhone().getExtension(), vendorDetails.getPhone().getExtension());
		assertEquals(expected.getPhone().getNumber(), vendorDetails.getPhone().getNumber());
		assertEquals(expected.getPhone().getType(), vendorDetails.getPhone().getType());

	}
}
