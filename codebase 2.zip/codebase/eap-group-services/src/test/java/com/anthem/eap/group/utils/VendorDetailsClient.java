package com.anthem.eap.group.utils;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.anthem.eap.group.router.RouteConstants;
import com.anthem.eap.model.accountProfile.VendorDetails;

import reactor.core.publisher.Mono;

public class VendorDetailsClient {

	private WebClient webClient;

	public VendorDetailsClient(WebClient webClient) {
		this.webClient = webClient;
	}

	public Mono<VendorDetails> saveOrUpdateGroupVendor(Long groupId, Long accountDetailsId,
			VendorDetails vendorDetails) {
		return webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, groupId, accountDetailsId)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).retrieve()
				.bodyToMono(VendorDetails.class);
	}

	public Mono<VendorDetails> saveOrUpdateSubGroupVendor(Long groupId, Long accountDetailsId,
			VendorDetails vendorDetails) {
		return webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, groupId, accountDetailsId)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).retrieve()
				.bodyToMono(VendorDetails.class);
	}
}