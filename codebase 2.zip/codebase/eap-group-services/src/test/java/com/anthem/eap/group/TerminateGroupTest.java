package com.anthem.eap.group;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import com.anthem.eap.group.handler.GroupHandler;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.router.GroupRouter;
import com.anthem.eap.group.service.GroupService;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.TerminationInfo;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {GroupRouter.class, GroupHandler.class})
@WebFluxTest
public class TerminateGroupTest {
  private static final Group group;
  private static final ZonedDateTime zonedDateTimeOf =
      ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
  @Autowired private ApplicationContext context;
  @MockBean private GroupService groupService;
  @MockBean private SubGroupService subGroupService;
  @MockBean private GroupRepository groupRepository;
  private WebTestClient webTestClient;

  static {
    group = new Group();
    group.setId(1L);
    group.setName("testGroup1");

    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    group.setHealthPlanIds(strlst);
    group.setNational(false);
    group.setTin("test");
    group.setCallCenterCode("test");
    group.setType("test");

    List<TerminationInfo> terminationList = new ArrayList<TerminationInfo>();
    TerminationInfo terinfo = new TerminationInfo();
    ZonedDateTime zonedDateTime = ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    terinfo.setEffectiveDate(zonedDateTime);
    terinfo.setNewEAPVendor("testVendor");
    terinfo.setReinstatedBy("test");
    terinfo.setTerminatedBy("test");
    terinfo.setTerminationDate(zonedDateTime);
    terinfo.setTerminationNotes("terminationNote");
    terinfo.setTerminationReason("test");
    terminationList.add(terinfo);
    group.setTerminationList(terminationList);
  }

  @BeforeEach
  public void setUp() {
    webTestClient = WebTestClient.bindToApplicationContext(context).build();
  }

  /* test group termination functionality on submit */
  @Test
  void terminateGroupTest() {
    Mono<Group> groupMono = Mono.just(group);
    group.setCreatedDate(zonedDateTimeOf);
    group.setLastModifiedBy("test");
    group.setLastModifiedDate(zonedDateTimeOf);
    group.setCreatedBy("test");
    Mockito.when(groupService.save(any(Group.class))).thenReturn(groupMono);
    /* service call */
    webTestClient
        .post()
        .uri("/group")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(group), Group.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Group.class)
        .value(
            groupResponse -> {
              ZonedDateTime zonedDateTime =
                  ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getEffectiveDate())
                  .isEqualTo(zonedDateTime);
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getNewEAPVendor())
                  .isEqualTo("testVendor");
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getReinstatedBy())
                  .isEqualTo("test");
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getTerminatedBy())
                  .isEqualTo("test");
            });
  }
}
