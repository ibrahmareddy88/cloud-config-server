package com.anthem.eap.group.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.BrokerCommission;
import com.anthem.eap.model.common.ContactInfo;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.GroupSubgroupContact.ContactType;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.model.user.Name;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public class BrokerCommissionUtil {

  public static BrokerCommission getBrokerCommission() {
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setTin(111111111L);
    contactInfo.setContactId(1L);
    contactInfo.setName(new Name());
    BrokerCommission brokerCommission = new BrokerCommission();
    brokerCommission.setCommission(new BigDecimal(1000));
    brokerCommission.setCommissionPaidBy("ANTHEM_HEALTH_PLAN");
    brokerCommission.setCommissionSchedule("MONTHLY");
    brokerCommission.setContactInfo(contactInfo);
    brokerCommission.setCommType("PEPM");
    brokerCommission.setNote("instructions....");
    return brokerCommission;
  }

  public static Group getGroup() {
    Group group = new Group();
    List<GroupSubgroupContact> contacts = new ArrayList<>();
    GroupSubgroupContact contact1 = new GroupSubgroupContact();
    Name name1 = new Name("first", "last");
    ContactInfo contactInfo = new ContactInfo(1L, name1, 987654321L);
    contact1.setId(1L);
    contact1.setContactType(ContactType.BROKER);
    contact1.setEffectiveDate(ZonedDateTime.now());
    contact1.setContactInfo(contactInfo);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails1 = getAccountProfile(1L);
    AccountDetails accDetails2 = getAccountProfile(2L);
    BrokerCommission broker = getBrokerCommission();
    broker.setId(1L);
    List<BrokerCommission> brokersList = new ArrayList<>();
    brokersList.add(broker);
    accDetails2.setBrokerCommissions(brokersList);
    accountDetails.add(accDetails1);
    accountDetails.add(accDetails2);
    group.setAccountDetails(accountDetails);
    group.setContacts(contacts);
    return group;
  }

  public static SubGroup getSubGroup() {
    SubGroup subGroup = new SubGroup();
    List<GroupSubgroupContact> contacts = new ArrayList<>();
    GroupSubgroupContact contact1 = new GroupSubgroupContact();
    Name name1 = new Name("first", "last");
    ContactInfo contactInfo = new ContactInfo(1L, name1, 987654321L);
    contact1.setId(1L);
    contact1.setContactType(ContactType.BROKER);
    contact1.setEffectiveDate(ZonedDateTime.now());
    contact1.setContactInfo(contactInfo);
    List<AccountDetails> accountDetails = new ArrayList<>();
    AccountDetails accDetails1 = getAccountProfile(1L);
    AccountDetails accDetails2 = getAccountProfile(2L);
    BrokerCommission broker = getBrokerCommission();
    broker.setId(1L);
    List<BrokerCommission> brokersList = new ArrayList<>();
    brokersList.add(broker);
    accDetails2.setBrokerCommissions(brokersList);
    accountDetails.add(accDetails1);
    accountDetails.add(accDetails2);
    subGroup.setAccountDetails(accountDetails);
    subGroup.setContacts(contacts);
    return subGroup;
  }

  public static void enqueueMockResponse(MockWebServer mockWebServer, BrokerCommission broker)
      throws JsonProcessingException {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(broker)));
  }

  private static AccountDetails getAccountProfile(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    return accountDetails;
  }

  public static void assertBrokerCommission(BrokerCommission broker, BrokerCommission br) {
    assertNotNull(br);
    assertNotNull(br.getId());
    assertEquals(br.getCommType(), broker.getCommType());
    assertEquals(br.getCommission(), broker.getCommission());
    assertEquals(br.getCommissionPaidBy(), broker.getCommissionPaidBy());
    assertEquals(br.getCommissionSchedule(), broker.getCommissionSchedule());
    assertNotNull(br.getContactInfo());
    assertEquals(br.getContactInfo().getContactId(), broker.getContactInfo().getContactId());
    assertEquals(br.getContactInfo().getTin(), broker.getContactInfo().getTin());
  }
}
