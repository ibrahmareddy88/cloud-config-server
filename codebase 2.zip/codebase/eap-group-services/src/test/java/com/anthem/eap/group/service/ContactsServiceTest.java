package com.anthem.eap.group.service;

import static org.junit.jupiter.api.Assertions.*;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.ContactRepository;
import com.anthem.eap.group.utils.ContactUtil;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.user.Name;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@DisplayName("List And Save Contact Tests")
class ContactsServiceTest extends AbstractPersistableUnitTests {
  @Autowired private ContactRepository contactRepository;

  @BeforeEach
  private void scriptInitialize() {
    Contact contact1 = ContactUtil.contactTestData_1();
    Contact contact2 = ContactUtil.contactTestData_2();
    contactRepository.saveAll(Arrays.asList(contact1, contact2)).blockLast();
  }

  @Test
  @DisplayName("Save Contact::save a Contact")
  @Order(1)
  void saveContact() {
    Contact contact = ContactUtil.contactTestData_3();
    webClient
        .post()
        .uri("/contact")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(contact), Contact.class)
        .exchange()
        .expectHeader()
        .location("/contact/3")
        .expectStatus()
        .isCreated();

    Mono<Contact> dbObject = mongoTemplate.findById(3L, Contact.class);

    StepVerifier.create(dbObject)
        .assertNext(result -> verifyContact(contact, result))
        .verifyComplete();
  }

  @Test
  @DisplayName("Get Contact:: get a contact by Id")
  @Order(2)
  void getContactById() {
    webClient
        .get()
        .uri("/contact/{id}", "2")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Contact.class)
        .consumeWith(
            response -> {
              Contact result = response.getResponseBody();
              assertNotNull(result);
              verifyContact(ContactUtil.contactTestData_2(), result);
            });
  }

  @Test
  @DisplayName("Edit Contact:: update a contact by Id")
  @Order(3)
  void updateContactById() {
    Contact contact = ContactUtil.contactTestData_1();
    contact.setAccountName("LindaSmith001");

    webClient
        .put()
        .uri("/contact/{id}", "1")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(contact), Contact.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<Contact> dbObject = mongoTemplate.findById(1L, Contact.class);
    StepVerifier.create(dbObject)
        .assertNext(results -> verifyContact(contact, results))
        .verifyComplete();
  }

  @Test
  @DisplayName("Edit Contact:: update a contact by Id")
  @Order(4)
  void updateContact2() {
    Contact contact = ContactUtil.contactTestData_2();
    Name name = new Name();
    name.setFirstName("John");
    name.setLastName("Wilson");
    name.setMiddleName("E");
    contact.setName(name);
    Address address = new Address();
    address.setStreet1("100 Main st");
    Phone phone = new Phone();
    phone.setNumber("8812522578");
    address.setPhone(phone);
    contact.setAddress(address);
    contact.setNotes("Contact 2 has been updated");

    webClient
        .put()
        .uri("/contact/{id}", "2")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(contact), Contact.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<Contact> dbObject = mongoTemplate.findById(2L, Contact.class);
    StepVerifier.create(dbObject)
        .assertNext(results -> verifyContact(contact, results))
        .verifyComplete();
  }

  @Test
  @DisplayName("Get All Contacts::get all contacts added")
  @Order(5)
  void getAllContacts() {
    Flux<Contact> contacts =
        webClient
            .get()
            .uri("/contact")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(Contact.class)
            .getResponseBody();

    StepVerifier.create(contacts)
        .assertNext(result -> verifyContact(ContactUtil.contactTestData_2(), result))
        .assertNext(result -> verifyContact(ContactUtil.contactTestData_1(), result))
        .verifyComplete();
  }

  private void verifyContact(Contact expected, Contact result) {

    assertEquals(expected.getId(), result.getId());
    assertEquals(expected.getName().getFirstName(), result.getName().getFirstName());
    assertEquals(expected.getName().getLastName(), result.getName().getLastName());
    assertEquals(expected.getEmail(), result.getEmail());
    assertEquals(expected.getAccountName(), result.getAccountName());
    assertEquals(expected.getBrokerNumber(), result.getBrokerNumber());
    assertEquals(expected.getNotes(), result.getNotes());
    assertEquals(expected.getTitle(), result.getTitle());
    assertEquals(expected.getAddress().getStreet1(), result.getAddress().getStreet1());
    assertEquals(expected.getAddress().getStreet2(), result.getAddress().getStreet2());
    assertEquals(expected.getAddress().getCity(), result.getAddress().getCity());
    assertEquals(expected.getAddress().getStateCd(), result.getAddress().getStateCd());
    assertEquals(expected.getAddress().getZip(), result.getAddress().getZip());
    assertEquals(
        expected.getAddress().getPhone().getNumber(), result.getAddress().getPhone().getNumber());

    ZonedDateTime currentDateInUTC = ZonedDateTime.now().withZoneSameInstant(ZoneOffset.UTC);
    ZonedDateTime lastModifiedDateInUTC =
        result.getLastModifiedDate().withZoneSameInstant(ZoneOffset.UTC);
    ZonedDateTime createdDateInUTC = result.getCreatedDate().withZoneSameInstant(ZoneOffset.UTC);

    assertEquals(expected.getCreatedBy(), result.getCreatedBy());
    assertEquals(currentDateInUTC.getYear(), createdDateInUTC.getYear());
    assertEquals(currentDateInUTC.getMonth(), createdDateInUTC.getMonth());
    assertEquals(currentDateInUTC.getDayOfMonth(), createdDateInUTC.getDayOfMonth());

    assertEquals("System", result.getLastModifiedBy());
    assertEquals(currentDateInUTC.getYear(), lastModifiedDateInUTC.getYear());
    assertEquals(currentDateInUTC.getMonth(), lastModifiedDateInUTC.getMonth());
    assertEquals(currentDateInUTC.getDayOfMonth(), lastModifiedDateInUTC.getDayOfMonth());
  }

  @Test
  @DisplayName(
      "Verify Contact Exist With Email Id::contact should exist with the emailid sent in request header")
  @Order(6)
  void contactShouldExistWithEmailId() {
    String testExistingEmail = "linda1@verizon.com";
    Flux<Contact> contacts =
        webClient
            .get()
            .uri("/contact")
            .header("email", testExistingEmail)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(Contact.class)
            .getResponseBody();
    StepVerifier.create(contacts)
        .assertNext(result -> assertEquals(result.getEmail(), testExistingEmail))
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Verify Contact Exist With Email Id::contact should not exist with the emailid sent in request header")
  @Order(7)
  void contactShouldNotExistWithEmailId() {
    String testNonExistingEmail = "lindaNotDuplicate@verizon.com";
    Flux<Contact> contacts =
        webClient
            .get()
            .uri("/contact")
            .header("email", testNonExistingEmail)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(Contact.class)
            .getResponseBody();

    StepVerifier.create(contacts).expectNextCount(0).verifyComplete();
  }

  @Test
  @DisplayName("Edit Contact:: update a contact should fail which has incorrect request body")
  @Order(8)
  void updateContactShouldFailWithInvalidRequestPayload() {
    Contact contact = new Contact();
    webClient
        .put()
        .uri("/contact/{id}", "2")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(contact), Contact.class)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @DisplayName("Edit Contact:: update a contact should fail with incorrect uri")
  @Order(9)
  void updateContactShouldFailWithIncorrectURI() {
    webClient.get().uri("/contacts/{id}", "2").exchange().expectStatus().is4xxClientError();
  }

  @Test
  @DisplayName("Create Contact:::create a contact should fail with incorrect uri")
  @Order(10)
  void failContactCreationWithIncorrectUri() {
    Contact contact = ContactUtil.contactTestData_3();
    webClient
        .post()
        .uri("/contacts")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(contact), Contact.class)
        .exchange()
        .expectStatus()
        .is4xxClientError();
  }

  @Test
  @DisplayName("Get Contact:: contact should not exist with id 5")
  @Order(11)
  void contactShouldNotExistWithId5() {
    webClient
        .get()
        .uri("/contact/{id}", "5")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Contact.class)
        .consumeWith(
            response -> {
              Contact result = response.getResponseBody();
              assertNull(result);
            });
  }

  private void verifyMatchContact(Contact expected, Contact result) {
    assertEquals(result.getEmail(), expected.getEmail());
    assertEquals(result.getTin(), expected.getTin());
    assertEquals(result.getAddress().getCity(), expected.getAddress().getCity());
    assertEquals(result.getAddress().getStateCd(), expected.getAddress().getStateCd());
    assertEquals(result.getAddress().getStreet1(), expected.getAddress().getStreet1());
    assertEquals(result.getAddress().getStreet2(), expected.getAddress().getStreet2());
    assertEquals(result.getAddress().getZip(), expected.getAddress().getZip());
    assertEquals(
        result.getAddress().getPhone().getNumber(), expected.getAddress().getPhone().getNumber());
  }
}
