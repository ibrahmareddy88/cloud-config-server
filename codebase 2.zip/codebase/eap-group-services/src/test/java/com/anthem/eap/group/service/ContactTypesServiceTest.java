package com.anthem.eap.group.service;

import static org.junit.jupiter.api.Assertions.*;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.dto.ContactTypeResultDto;
import com.anthem.eap.group.dto.TerminateRoleResponseDto;
import com.anthem.eap.group.repository.ContactRepository;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.router.RouteConstants;
import com.anthem.eap.group.utils.ContactTypeUtil;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@DisplayName("List And Save Contact Type Tests")
class ContactTypesServiceTest extends AbstractPersistableUnitTests {
  @Autowired private GroupRepository groupRepository;
  @Autowired private SubGroupRepository subGroupRepository;
  @Autowired private ContactRepository contactRepository;

  @BeforeEach
  private void initScript() {
    Group group1 = ContactTypeUtil.getGroup1();
    Group group2 = ContactTypeUtil.getGroup2();
    Group group3 = ContactTypeUtil.getGroup3();
    Group group4 = ContactTypeUtil.getGroup4();
    Group group5 = ContactTypeUtil.getGroup5();
    groupRepository.saveAll(Arrays.asList(group1, group2, group3, group4, group5)).blockLast();

    SubGroup subGroup1 = ContactTypeUtil.getSubGroup1();
    SubGroup subGroup2 = ContactTypeUtil.getSubGroup2();
    SubGroup subGroup3 = ContactTypeUtil.getSubGroup3();
    SubGroup subGroup4 = ContactTypeUtil.getSubGroup4();
    SubGroup subGroup5 = ContactTypeUtil.getSubGroup5();
    SubGroup subGroup6 = ContactTypeUtil.getSubGroup6();
    SubGroup subGroup7 = ContactTypeUtil.getSubGroup7();
    subGroupRepository
        .saveAll(
            Arrays.asList(
                subGroup1, subGroup2, subGroup3, subGroup4, subGroup5, subGroup6, subGroup7))
        .blockLast();

    Contact contact1 = ContactTypeUtil.contactTestData_1();
    Contact contact2 = ContactTypeUtil.contactTestData_2();
    Contact contact3 = ContactTypeUtil.contactTestData_3();
    contactRepository.saveAll(Arrays.asList(contact1, contact2, contact3)).blockLast();
  }

  @Test
  @DisplayName("List Contacts: Fetch Contacts of a Group and associated Subgroup(s) by groupId")
  @Order(1)
  void getContactsOfGroupAndAssociatedSubGroupByGroupId() {
    Flux<ContactTypeResultDto> contactTypes =
        webClient
            .get()
            .uri(RouteConstants.GET_CONTACT_TYPES, "100")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(ContactTypeResultDto.class)
            .getResponseBody();
    StepVerifier.create(contactTypes).expectNextCount(6).verifyComplete();
  }

  @Test
  @DisplayName(
      "List Contacts: Should return empty Flux when the given Group and associated Subgroup contacts are empty")
  @Order(2)
  void shouldReturnEmptyFluxWhenGroupAndAssociatedSubGroupContactsAreEmpty() {
    Flux<ContactTypeResultDto> contactTypes =
        webClient
            .get()
            .uri(RouteConstants.GET_CONTACT_TYPES, "101")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(ContactTypeResultDto.class)
            .getResponseBody();
    StepVerifier.create(contactTypes).expectNextCount(0).verifyComplete();
  }

  @Test
  @DisplayName(
      "List Contacts: Should return contacts of subgroups when Groups contacts are empty but associated subgroup has contacts")
  @Order(3)
  void shouldReturnSubGroupContacts() {
    Flux<ContactTypeResultDto> contactTypes =
        webClient
            .get()
            .uri(RouteConstants.GET_CONTACT_TYPES, "102")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(ContactTypeResultDto.class)
            .getResponseBody();
    StepVerifier.create(contactTypes)
        .assertNext(
            result -> {
              verifyMatchContactTypeForSubGroup(
                  ContactTypeUtil.getSubGroup4(), result, 1, ContactTypeUtil.contactTestData_1());
              assertEquals(ContactTypeResultDto.ContactStatus.ACTIVE, result.getStatus());
            })
        .assertNext(
            result -> {
              verifyMatchContactTypeForSubGroup(
                  ContactTypeUtil.getSubGroup4(), result, 0, ContactTypeUtil.contactTestData_2());
              assertEquals(ContactTypeResultDto.ContactStatus.IN_ACTIVE, result.getStatus());
            })
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Save Contacts: Save Contacts of a Group(Group-5) and associated Subgroup(s)(SubGroup-5)")
  @Order(4)
  void saveContactsOfGroup5AndAssociatedSubGroup5() {
    Flux<GroupSubgroupContact> contacts =
        webClient
            .post()
            .uri(RouteConstants.POST_CONTACT_TYPES, "102")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(
                Flux.just(
                    ContactTypeUtil.contactTypeFormTestData_1(),
                    ContactTypeUtil.contactTypeFormTestData_2()),
                ContactTypeResultDto.class)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(GroupSubgroupContact.class)
            .getResponseBody();

    StepVerifier.create(contacts)
        .assertNext(
            contact -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.PROMOTION_EMAIL_CONTACT,
                  contact.getContactType());
              assertEquals(55555L, contact.getContactInfo().getTin());
              verifyAuditFields(contact);
            })
        .assertNext(
            contact -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.INVOICE_RECIPIENT, contact.getContactType());
              assertEquals(12345L, contact.getContactInfo().getTin());
              verifyAuditFields(contact);
            })
        .verifyComplete();
  }

  @Test
  @DisplayName("Save Contacts: Save Contacts of a Group(Group-2)")
  @Order(5)
  void saveContactsOfGroup2() {
    Flux<GroupSubgroupContact> contacts =
        webClient
            .post()
            .uri(RouteConstants.POST_CONTACT_TYPES, "101")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(
                Flux.just(ContactTypeUtil.contactTypeFormTestData_3()), ContactTypeResultDto.class)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(GroupSubgroupContact.class)
            .getResponseBody();

    StepVerifier.create(contacts)
        .assertNext(
            contact -> {
              assertEquals(GroupSubgroupContact.ContactType.BROKER, contact.getContactType());
              assertEquals(12347L, contact.getContactInfo().getTin());
              verifyAuditFields(contact);
            })
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Verify Existence of Contact and Group/Subgroup mapping : Should return false as contact(Contact-3) is not associated to Group(Group-5) and associated Subgroup contacts")
  @Order(6)
  void shouldReturnFalseAsContactIsNotAssociatedWithGroupAndAssociatedSubGroupContacts() {
    webClient
        .get()
        .uri(RouteConstants.CONTACT_SEARCH_BY_GROUPID, "1236", "101")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Boolean.class)
        .consumeWith(response -> assertEquals(Boolean.FALSE, response.getResponseBody()));
  }

  @Test
  @DisplayName(
      "Verify Existence of Contact and Group/Subgroup mapping: Should return true as contact(Contact-2) is associated to Subgroup of Group(Group-3)")
  @Order(7)
  void shouldReturnTrueAsContactIsAssociatedWithGroupAndAssociatedSubGroupContacts() {
    webClient
        .get()
        .uri(RouteConstants.CONTACT_SEARCH_BY_GROUPID, "1234", "102")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Boolean.class)
        .consumeWith(response -> assertEquals(Boolean.TRUE, response.getResponseBody()));
  }

  @Test
  @DisplayName("Update Contact: Should update Group(Group-4) contact data")
  @Order(8)
  void updateGroup5ContactData() {
    Mono<Group> group = mongoTemplate.findById(108L, Group.class);
    StepVerifier.create(group)
        .assertNext(
            results -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.ACCOUNT_CONTACT,
                  results.getContacts().get(0).getContactType());
              assertEquals(333L, results.getContacts().get(0).getContactInfo().getTin());
            })
        .verifyComplete();
    webClient
        .post()
        .uri(RouteConstants.POST_CONTACT_TYPES, "108")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(ContactTypeUtil.contactTypeFormTestData_4()), ContactTypeResultDto.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<Group> resultGroup = mongoTemplate.findById(108L, Group.class);
    StepVerifier.create(resultGroup)
        .assertNext(
            results -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.BROKER,
                  results.getContacts().get(0).getContactType());
              assertEquals(4443L, results.getContacts().get(0).getContactInfo().getTin());
            })
        .verifyComplete();
  }

  @Test
  @DisplayName(
      "Update Contact: Should update only subGroup(7) of group(4) contact data but not group(4) contact data")
  @Order(9)
  void updateSubgroup7ContactDataOnly() {
    Mono<SubGroup> subGroup = mongoTemplate.findById(120L, SubGroup.class);
    StepVerifier.create(subGroup)
        .assertNext(
            results -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.PROMOTION_EMAIL_CONTACT,
                  results.getContacts().get(0).getContactType());
              assertEquals(555L, results.getContacts().get(0).getContactInfo().getTin());
            })
        .verifyComplete();
    webClient
        .post()
        .uri(RouteConstants.POST_CONTACT_TYPES, "120")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(ContactTypeUtil.contactTypeFormTestData_5()), ContactTypeResultDto.class)
        .exchange()
        .expectStatus()
        .isOk();

    Mono<SubGroup> resultSubGroup = mongoTemplate.findById(120L, SubGroup.class);
    StepVerifier.create(resultSubGroup)
        .assertNext(
            results -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.HP_CONTACT,
                  results.getContacts().get(0).getContactType());
              assertEquals(3455L, results.getContacts().get(0).getContactInfo().getTin());
            })
        .verifyComplete();
    Mono<Group> resultGroup = mongoTemplate.findById(108L, Group.class);
    StepVerifier.create(resultGroup)
        .assertNext(
            results -> {
              assertEquals(
                  GroupSubgroupContact.ContactType.ACCOUNT_CONTACT,
                  results.getContacts().get(0).getContactType());
              assertEquals(333L, results.getContacts().get(0).getContactInfo().getTin());
            })
        .verifyComplete();
  }

  @Test
  @DisplayName("Update contactType Termination Date if effective date is before termination date")
  @Order(9)
  void updateTerminationDateSuccess() {

    Flux<TerminateRoleResponseDto> responseBody =
        webClient
            .put()
            .uri("/contacttype/group/108/terminatecontact/1290")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .header("terminationDate", "01/16/2026")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(TerminateRoleResponseDto.class)
            .getResponseBody();

    StepVerifier.create(responseBody)
        .assertNext(
            response -> {
              assertEquals(1, response.getTotalContactTypes());
              assertEquals(1, response.getValidContactTypes());
            })
        .verifyComplete();

    Mono<SubGroup> resultSubGroup = mongoTemplate.findById(120L, SubGroup.class);

    StepVerifier.create(resultSubGroup)
        .assertNext(
            results -> {
              assertEquals(
                  "2026-01-16T00:00Z[UTC]",
                  results.getContacts().get(0).getTerminationDate().toString());
            })
        .verifyComplete();
  }

  @Test
  @DisplayName("No update of Termination Date if effective date is after termination date")
  @Order(10)
  void updateTerminationDateFailure() {

    Flux<TerminateRoleResponseDto> responseBody =
        webClient
            .put()
            .uri("/contacttype/group/108/terminatecontact/1290")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .header("terminationDate", "01/16/2020")
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(TerminateRoleResponseDto.class)
            .getResponseBody();

    StepVerifier.create(responseBody)
        .assertNext(
            response -> {
              assertEquals(1, response.getTotalContactTypes());
              assertEquals(0, response.getValidContactTypes());
            })
        .verifyComplete();
  }

  private void verifyMatchContactTypeForSubGroup(
      SubGroup expected, ContactTypeResultDto result, int index, Contact contact) {
    assertEquals(result.getSubGroupName(), expected.getName());
    assertEquals(result.getSubGroupId(), expected.getId());
    assertEquals(
        result.getEffectiveDate().toLocalDate(),
        expected.getContacts().get(index).getEffectiveDate().toLocalDate());
    assertEquals(
        result.getTerminationDate().toLocalDate(),
        expected.getContacts().get(index).getTerminationDate().toLocalDate());
    assertEquals(
        result.getContactInfo().getTin(),
        expected.getContacts().get(index).getContactInfo().getTin());
    assertEquals(
        result.getContactInfo().getContactId(),
        expected.getContacts().get(index).getContactInfo().getContactId());
    assertEquals(
        result.getContactInfo().getName().getFullName(),
        expected.getContacts().get(index).getContactInfo().getName().getFullName());
    assertEquals(result.getEmail(), contact.getEmail());
    assertEquals(result.getBrokerNumber(), contact.getBrokerNumber());
    assertEquals(result.getAccountName(), contact.getAccountName());
    assertEquals(result.getPhoneNumber(), contact.getAddress().getPhone().getNumber());
    assertEquals(result.getTitle(), contact.getTitle());
    assertNull(result.getGroupName());
    assertEquals(result.getGroupId(), expected.getGroupId());
  }

  private void verifyAuditFields(GroupSubgroupContact contact) {
    assertEquals("System", contact.getCreatedBy());
    assertEquals(
        contact.getCreatedDate().toLocalDate(), ZonedDateTime.now(ZoneId.of("UTC")).toLocalDate());
    assertEquals(
        contact.getLastModifiedDate().toLocalDate(),
        ZonedDateTime.now(ZoneId.of("UTC")).toLocalDate());
    assertEquals("System", contact.getLastModifiedBy());
  }
}
