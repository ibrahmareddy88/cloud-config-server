package com.anthem.eap.group.utils;

import com.anthem.eap.group.router.RouteConstants;
import com.anthem.eap.model.accountProfile.BrokerCommission;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

public class BrokerCommissionClient {

  private WebClient webClient;

  public BrokerCommissionClient(WebClient webClient) {
    this.webClient = webClient;
  }

  public Mono<BrokerCommission> saveOrUpdateGroupBroker(
      Long groupId, Long accountDetailsId, BrokerCommission broker) {
    return webClient
        .put()
        .uri(RouteConstants.GROUP_ACCOUNT_DETAILS_BROKER_PATH, groupId, accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .retrieve()
        .bodyToMono(BrokerCommission.class);
  }

  public Mono<BrokerCommission> saveOrUpdateSubGroupBroker(
      Long groupId, Long accountDetailsId, BrokerCommission broker) {
    return webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUP_ACCOUNT_DETAILS_BROKER_PATH,
            groupId,
            accountDetailsId)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(broker), BrokerCommission.class)
        .retrieve()
        .bodyToMono(BrokerCommission.class);
  }
}
