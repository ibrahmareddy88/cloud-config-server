package com.anthem.eap.group.router;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.IOException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.MediaType;
import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.utils.VendorDetailsUtil;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.fasterxml.jackson.core.JsonProcessingException;

import okhttp3.mockwebserver.MockWebServer;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class VendorDetailsRouterTest extends AbstractPersistableUnitTests {

	@Autowired
	private SubGroupService subGroupService;

	@Autowired
	private GroupRepository groupRepository;

	private Group group;

	private SubGroup subGroup;

	private MockWebServer mockWebServer = new MockWebServer();

	@BeforeEach
	private void init() {
		group = VendorDetailsUtil.getGroup();
		subGroup = VendorDetailsUtil.getSubGroup();
		groupRepository.save(group).block();
		subGroupService.saveSubGroup(subGroup).block();
	}

	@AfterEach
	void tearDown() throws IOException {
		mockWebServer.shutdown();
	}

	@Test
	@Order(1)
	@Description("should create vendor within a group")
	void createVendorDetails() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, group.getId(), 1l)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(vendorDetails), VendorDetails.class).exchange().expectStatus().isOk()
				.expectBody(VendorDetails.class).consumeWith(response -> {
					VendorDetails vendorDetailsData = response.getResponseBody();
					assertNotNull(vendorDetailsData);
					assertNotNull(vendorDetailsData.getId());
					VendorDetailsUtil.verifyVendorDetails(vendorDetails, vendorDetailsData);
				});
	}

	@Test
	@Order(2)
	@Description("should fail when group account profile not found")
	void addVendorForGroupProfileFailTest() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, group.getId(), 10L).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(vendorDetails), VendorDetails.class).exchange().expectStatus().is5xxServerError();
	}

	@Test
	@Order(3)
	@Description("should update vendor details within a group if already exists")
	void updateVendorForGroupProfileTest() throws JsonProcessingException, InterruptedException {
		VendorDetails updateVendorDetails = VendorDetailsUtil.updateGroupVendorDetails();
		updateVendorDetails.setVendorType("Vendor Updated");
		updateVendorDetails.setName("Vendor_Name_Updated");
		updateVendorDetails.setInstruction("Instruction Updated........");

		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, group.getId(), 1l)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(updateVendorDetails), VendorDetails.class).exchange().expectStatus().isOk()
				.expectBody(VendorDetails.class).consumeWith(response -> {
					VendorDetails updatedVendorRes = response.getResponseBody();
					Flux<VendorDetails> dbObject = groupRepository.findAllVendorDetails(group.getId(), 1l);
					StepVerifier.create(dbObject).assertNext(result -> {
						assertNotNull(result);
						VendorDetailsUtil.verifyVendorDetails(result, updatedVendorRes);

					}).verifyComplete();
				});
	}

	@Test
	@Order(4)
	@Description("should create vendor within a subgroup")
	void addVendorForSubGroupProfileTest() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, subGroup.getId(), 1l)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).exchange()
				.expectStatus().isOk().expectBody(VendorDetails.class).consumeWith(response -> {
					VendorDetails vendor = response.getResponseBody();
					assertNotNull(vendor);
					assertNotNull(vendor.getId());
				});
	}

	@Test
	@Order(5)
	@Description("should fail when sub group account profile not found")
	void addVendorForSubGroupProfileFailTest() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, subGroup.getId(), 10L)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).exchange()
				.expectStatus().is5xxServerError();
	}

	@Test
	@Order(6)
	@Description("should update vendor details within a Sub group if already exists")
	void updateVendorForSubGroupProfileTest() throws JsonProcessingException, InterruptedException {
		VendorDetails updateSubGroupVendorDetails = VendorDetailsUtil.getVendorDetails();
		updateSubGroupVendorDetails.setVendorType("Vendor Sub Group Updated");
		updateSubGroupVendorDetails.setName("Sub_Group_Vendor");
		updateSubGroupVendorDetails.setInstruction("Sub Group Instruction Updated");

		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, subGroup.getId(), 1l)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(updateSubGroupVendorDetails), VendorDetails.class).exchange().expectStatus().isOk()
				.expectBodyList(VendorDetails.class).value(result -> {
					assertThat(result).isNotEmpty();
					assertEquals(result.listIterator().next().getInstruction(),
							updateSubGroupVendorDetails.getInstruction());
					assertEquals(result.listIterator().next().getVendorType(),
							updateSubGroupVendorDetails.getVendorType());
					assertEquals(result.listIterator().next().getName(), updateSubGroupVendorDetails.getName());
				});
	}

	@Test
	@Order(7)
	@Description("should fail when Group vendorId is not valid")
	void findGroupVendorDetailsforInvalidVendorId() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, group.getId(), 3l)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(vendorDetails), VendorDetails.class).exchange().expectStatus().is5xxServerError();
	}

	@Test
	@Order(8)
	@Description("should fail when Sub Group vendorId is not valid")
	void findSubGroupVendorDetailsforInvalidVendorId() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, subGroup.getId(), 5l)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(vendorDetails), VendorDetails.class).exchange().expectStatus().is5xxServerError();
	}

	@Test
	@Order(9)
	@Description("should fail when groupId is null")
	void returnEmptyWhenGroupIdIsNull() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, null, 1l).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(vendorDetails), VendorDetails.class).exchange().expectStatus().isNotFound();
	}

	@Test
	@Order(10)
	@Description("should fail when subGroupId is null")
	void returnEmptyWhenSubGroupIdIsNull() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, null, 1l)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).exchange()
				.expectStatus().isNotFound();
	}

	@Test
	@Order(11)
	@Description("should fail when Group vendorId is null")
	void returnEmptyWhenGroupVendorIdIsNull() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri(RouteConstants.GROUPS_VENDOR_DETAILS, group.getId(), null)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).exchange()
				.expectStatus().isNotFound();
	}

	@Test
	@Order(12)
	@Description("should fail when Sub Group vendorId is null")
	void returnEmptyWhenSubGroupVendorIdIsNull() {
		VendorDetails vendorDetails = VendorDetailsUtil.getVendorDetails();
		assertNull(vendorDetails.getId());
		webClient.put().uri("/subgroup" + RouteConstants.SUBGROUPS_VENDOR_DETAILS, subGroup.getId(), null)
				.accept(MediaType.APPLICATION_JSON).body(Mono.just(vendorDetails), VendorDetails.class).exchange()
				.expectStatus().isNotFound();
	}
}