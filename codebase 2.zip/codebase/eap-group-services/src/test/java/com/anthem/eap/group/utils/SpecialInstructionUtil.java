package com.anthem.eap.group.utils;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.SpecialInstruction;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;

public class SpecialInstructionUtil {

  public static Group getGroupWithSpecialInstructions() {
    Group group = new Group();
    group.setId(1L);
    AccountDetails accDetails1 = getAccountProfile(1L);
    AccountDetails accDetails2 = getAccountProfile(2L);
    accDetails2.setSpecialInstructions(
        Arrays.asList(
            getSpecialInstruction1(), getSpecialInstruction2(), getSpecialInstruction5()));
    group.setAccountDetails(Arrays.asList(accDetails1, accDetails2));
    return group;
  }

  public static Group getGroupWithOutSpecialInstructions() {
    Group group = new Group();
    group.setId(2L);
    AccountDetails accDetails1 = getAccountProfile(1L);
    group.setAccountDetails(Arrays.asList(accDetails1));
    return group;
  }

  public static SubGroup getSubGroupWithSpecialInstructions() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(1L);
    subGroup.setGroupId(1L);
    AccountDetails accDetails1 = getAccountProfile(1L);
    accDetails1.setSpecialInstructions(
        Arrays.asList(getSpecialInstruction3(), getSpecialInstruction4()));
    AccountDetails accDetails2 = getAccountProfile(2L);
    subGroup.setAccountDetails(Arrays.asList(accDetails1, accDetails2));
    return subGroup;
  }

  public static SubGroup getSubGroupWithOutSpecialInstructions() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(2L);
    subGroup.setGroupId(2L);
    AccountDetails accDetails1 = getAccountProfile(1L);
    subGroup.setAccountDetails(Arrays.asList(accDetails1));
    return subGroup;
  }

  private static AccountDetails getAccountProfile(Long id) {
    AccountDetails accountDetails = new AccountDetails();
    accountDetails.setId(id);
    return accountDetails;
  }

  public static SpecialInstruction getSpecialInstruction1() {
    SpecialInstruction sp = new SpecialInstruction();
    sp.setInstruction("instruction1");
    sp.setSpecialInstructionType("CHEMICAL_DEPENDENCY_PROTOCOLS");
    sp.setEffDate(ZonedDateTime.now(ZoneId.of("UTC")));
    return sp;
  }

  public static SpecialInstruction getSpecialInstruction2() {
    SpecialInstruction sp = new SpecialInstruction();
    sp.setInstruction("instruction2");
    sp.setSpecialInstructionType("1_CUSTOM_GROUP_SERVICES");
    sp.setEffDate(ZonedDateTime.now(ZoneId.of("UTC")).plusDays(10));
    return sp;
  }

  public static SpecialInstruction getSpecialInstruction3() {
    SpecialInstruction sp = new SpecialInstruction();
    sp.setInstruction("instruction3");
    sp.setSpecialInstructionType("HEALTH_SERVICES_ONSITE");
    sp.setEffDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(5));
    return sp;
  }

  public static SpecialInstruction getSpecialInstruction4() {
    SpecialInstruction sp = new SpecialInstruction();
    sp.setInstruction("instruction4");
    sp.setSpecialInstructionType("VIOLENCE_WORKPLACE SAFETY");
    sp.setEffDate(ZonedDateTime.now(ZoneId.of("UTC")));
    return sp;
  }

  public static SpecialInstruction getSpecialInstruction5() {
    SpecialInstruction sp = new SpecialInstruction();
    sp.setInstruction("instruction5");
    sp.setSpecialInstructionType("ORGANIZATIONAL_CHANGES");
    sp.setEffDate(ZonedDateTime.now(ZoneId.of("UTC")));
    return sp;
  }
}
