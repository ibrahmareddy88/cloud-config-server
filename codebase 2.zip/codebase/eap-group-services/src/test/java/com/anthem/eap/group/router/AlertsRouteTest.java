package com.anthem.eap.group.router;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.model.AlertModel;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.utils.AlertsTestUtil;
import com.anthem.eap.model.group.Alert;
import com.anthem.eap.model.group.Group;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class AlertsRouteTest extends AbstractPersistableUnitTests {

  @Autowired GroupRepository groupRepository;
  @Autowired private SubGroupRepository subGroupRepository;

  @DisplayName("Adding infinate ALerts to a Group")
  @Test
  void addInfinateAlertTest() {
    groupRepository.save(AlertsTestUtil.createGroup()).block();
    webClient
        .post()
        .uri("/alert/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(AlertsTestUtil.alertMock()), AlertModel.class)
        .exchange()
        .expectStatus()
        .isOk();
    Mono<Group> dbObject = mongoTemplate.findById(1L, Group.class);

    StepVerifier.create(dbObject)
        .assertNext(result -> verifyInfinateAlertAssert(result.getAlerts(), AlertsTestUtil.alertMock()))
        .verifyComplete();
  }

  @DisplayName("Adding Active ALerts to a Group")
  @Test
  void addAlertTest() {

    groupRepository.save(AlertsTestUtil.createGroup()).block();
    webClient
        .post()
        .uri("/alert/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(AlertsTestUtil.activeAlertMock()), AlertModel.class)
        .exchange()
        .expectStatus()
        .isOk();
    Mono<Group> dbObject = mongoTemplate.findById(1L, Group.class);

    StepVerifier.create(dbObject)
        .assertNext(result -> verifyActiveAlert(result.getAlerts(), AlertsTestUtil.activeAlertMock()))
        .verifyComplete();
  }

  @DisplayName("Get ALerts list ")
  @Test
  void getAlertListTest() {

    groupRepository.save(AlertsTestUtil.createGroupWithAlerts()).block();
    subGroupRepository.save(AlertsTestUtil.createSubgroupWithAlerts()).block();
    webClient
        .get()
        .uri("/alert/search/?id=" + "1")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(AlertModel.class)
        .value(
            result -> {
              asertAlertsList(result);
            });
  }

  @DisplayName("Edit ALert Test")
  @Test
  void editAlertTest() {

    groupRepository.save(AlertsTestUtil.createGroupWithAlerts()).block();
    webClient
        .post()
        .uri("/alert/")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(AlertsTestUtil.updateAlertMock()), AlertModel.class)
        .exchange()
        .expectStatus()
        .isOk();
    Mono<Group> dbObject = mongoTemplate.findById(1L, Group.class);

    StepVerifier.create(dbObject)
        .assertNext(result -> verifyUpdatedAlert(result.getAlerts(), AlertsTestUtil.updateAlertMock()))
        .verifyComplete();
  }

  private void verifyUpdatedAlert(List<Alert> alerts, AlertModel updateAlertMock) {
    assertNotNull(alerts);
    assertEquals(alerts.size(), 3);
    Alert alert =
        alerts.stream().filter(a -> a.getId() == updateAlertMock.getId()).findFirst().get();
    assertEquals(alert.getAlert(), updateAlertMock.getAlert());
  }

  private void asertAlertsList(List<AlertModel> result) {
    assertEquals(result.size(), 6);
    // infinite alerts
    assertEquals(result.get(0).getAlert(), "a1");
    assertEquals(result.get(1).getAlert(), "a1");
    // active aerts
    assertEquals(result.get(2).getAlert(), "a3");
    assertEquals(result.get(3).getAlert(), "a3");
    // termed aerts
    assertEquals(result.get(4).getAlert(), "a2");
    assertEquals(result.get(5).getAlert(), "a2");
  }

  private void verifyInfinateAlertAssert(List<Alert> result, AlertModel alertMock) {

    assertNotNull(result);
    assertNotEquals(result.size(), 0);
    Alert alert = result.get(0);
    assertEquals(alert.getAlert(), alertMock.getAlert());
    assertEquals(alert.getAlertType(), alertMock.getAlertType());
  }

  private void verifyActiveAlert(List<Alert> result, AlertModel alertMock) {

    assertNotNull(result);
    assertEquals(result.size(), 1);
    Alert alert = result.get(0);
    assertEquals(alert.getAlert(), alertMock.getAlert());
    assertEquals(alert.getAlertType(), alertMock.getAlertType());
    assertEquals(
        alert.getEffectiveDate().toLocalDate(), alertMock.getEffectiveDate().toLocalDate());
    assertEquals(
        alert.getTerminationDate().toLocalDate(), alertMock.getTerminationDate().toLocalDate());
  }
}
