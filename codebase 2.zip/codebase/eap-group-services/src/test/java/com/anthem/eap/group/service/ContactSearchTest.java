package com.anthem.eap.group.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.constants.ContactConstants;
import com.anthem.eap.group.repository.ContactRepository;
import com.anthem.eap.group.router.RouteConstants;
import com.anthem.eap.group.utils.ContactUtil;
import com.anthem.eap.model.contacts.Contact;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@DisplayName("Contact Search Tests")
class ContactSearchTest extends AbstractPersistableUnitTests {
  @Autowired private ContactRepository contactRepository;

  @BeforeEach
  private void init() {
    Contact contact1 = ContactUtil.contactTestData_1();
    Contact contact2 = ContactUtil.contactTestData_2();
    contactRepository.saveAll(Arrays.asList(contact1, contact2)).blockLast();
  }

  @Test
  @DisplayName("Contact Search: Searching with name Linda should return 2 contact records")
  @Order(1)
  void searchContactWithNameLinda() {
    Flux<Contact> contacts =
        webClient
            .get()
            .uri(
                builder ->
                    builder
                        .path(RouteConstants.CONTACT_SEARCH)
                        .queryParam(ContactConstants.SEARCH_QUERY_REQUEST_PARAM, "Linda")
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(Contact.class)
            .getResponseBody();

    StepVerifier.create(contacts)
        .assertNext(result -> verifyMatchContact(ContactUtil.contactTestData_2(), result))
        .assertNext(result -> verifyMatchContact(ContactUtil.contactTestData_1(), result))
        .verifyComplete();
  }

  @Test
  @DisplayName("Contact Search: Throws error when search param has less than 3 characters")
  @Order(2)
  void throwsErrorWhenSearchParamLengthIsLessThan3Characters() {
    webClient
        .get()
        .uri(
            builder ->
                builder
                    .path(RouteConstants.CONTACT_SEARCH)
                    .queryParam(ContactConstants.SEARCH_QUERY_REQUEST_PARAM, "te")
                    .build())
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(String.class)
        .value(
            response -> {
              assertThat(
                  response.equals(
                      "Search parameter is empty or length of Search parameter is < 3 characters"));
            });
  }

  @Test
  @DisplayName("Contact Search: Return 204 if search result is empty")
  @Order(3)
  void return204IfSearchResultEmpty() {
    webClient
        .get()
        .uri(
            builder ->
                builder
                    .path(RouteConstants.CONTACT_SEARCH)
                    .queryParam(ContactConstants.SEARCH_QUERY_REQUEST_PARAM, "test")
                    .build())
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  @DisplayName("Contact Search: Throws error when 'query' queryparam is missing in request")
  @Order(4)
  void throwsErrorWhenQueryParamIsMissing() {
    webClient
        .get()
        .uri(builder -> builder.path(RouteConstants.CONTACT_SEARCH).build())
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(String.class)
        .value(
            response -> {
              assertThat(response.equals("Query parameter (query) is missing in url"));
            });
  }

  private void verifyMatchContact(Contact expected, Contact result) {
    assertEquals(result.getEmail(), expected.getEmail());
    assertEquals(result.getTin(), expected.getTin());
    assertEquals(result.getAddress().getCity(), expected.getAddress().getCity());
    assertEquals(result.getAddress().getStateCd(), expected.getAddress().getStateCd());
    assertEquals(result.getAddress().getStreet1(), expected.getAddress().getStreet1());
    assertEquals(result.getAddress().getStreet2(), expected.getAddress().getStreet2());
    assertEquals(result.getAddress().getZip(), expected.getAddress().getZip());
    assertEquals(
        result.getAddress().getPhone().getNumber(), expected.getAddress().getPhone().getNumber());
  }
}
