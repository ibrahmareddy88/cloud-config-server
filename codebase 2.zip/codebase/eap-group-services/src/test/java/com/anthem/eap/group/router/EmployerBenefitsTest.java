package com.anthem.eap.group.router;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.utils.EmployerBenefitsClient;
import com.anthem.eap.group.utils.EmployerBenefitsUtil;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class EmployerBenefitsTest extends AbstractPersistableUnitTests {
  @Autowired private GroupRepository groupRepository;

  @Autowired private SubGroupService subGroupService;

  private Group group;

  private SubGroup subGroup;

  private MockWebServer mockWebServer = new MockWebServer();
  private EmployerBenefitsClient empBenefitsClient =
      new EmployerBenefitsClient(WebClient.create(mockWebServer.url("/").toString()));

  @BeforeEach
  private void init() {
    group = EmployerBenefitsUtil.getGroup();
    subGroup = EmployerBenefitsUtil.getSubGroup();
    groupRepository.save(group).block();
    subGroupService.saveSubGroup(subGroup).block();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  @Order(1)
  @Description("should create SABank within a group")
  void addSABankForGroupProfileTest() {
    SABank bank = EmployerBenefitsUtil.getSABank();
    assertNull(bank.getId());
    webClient
        .put()
        .uri(RouteConstants.GROUPS_EMP_SERVICE_SA_BANK, group.getId(), 1L, bank)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(bank), SABank.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(SABank.class)
        .consumeWith(
            response -> {
              SABank br = response.getResponseBody();
              EmployerBenefitsUtil.verifySABank(bank, br);
            });
  }

  @Test
  @Order(2)
  @Description("should update SA  details within a group if already exists")
  void updateSABankForGroupProfileTest() throws JsonProcessingException, InterruptedException {
    SABank bank = EmployerBenefitsUtil.getSABank();
    bank.setId(1L);
    bank.setBankName("Bank_1");
    EmployerBenefitsUtil.enqueueMockResponse(mockWebServer, bank);
    Mono<SABank> brokerMono = empBenefitsClient.saveOrUpdateGroupSABank(group.getId(), 1L, bank);
    StepVerifier.create(brokerMono)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("Bank_1", b.getBankName());
              assertEquals(bank.getId(), b.getId());
            })
        .verifyComplete();
  }

  @Test
  @Order(3)
  @Description("should create Employer Service within a group")
  void addAccountServiceForGroupProfileTest() {
    AccountService serv = EmployerBenefitsUtil.getAccService();

    assertNull(serv.getId());
    webClient
        .put()
        .uri(RouteConstants.GROUPS_ACCOUNT_SERVICE, group.getId(), 1L, serv)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), AccountService.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountService.class)
        .consumeWith(
            response -> {
              AccountService br = response.getResponseBody();
              EmployerBenefitsUtil.verifyAccountService(serv, br);
            });
  }

  @Test
  @Order(4)
  @Description("should update service  details within a group if already exists")
  void updateAccountServiceForGroupProfileTest()
      throws JsonProcessingException, InterruptedException {
    AccountService accService = EmployerBenefitsUtil.getAccService();
    accService.setId(3L);
    accService.setServiceType("EAP-Other");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(accService)));
    Mono<AccountService> brokerMono =
        empBenefitsClient.saveOrUpdateGroupAccountService(group.getId(), 1L, accService);
    StepVerifier.create(brokerMono)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("EAP-Other", b.getServiceType());
              assertEquals(accService.getId(), b.getId());
            })
        .verifyComplete();
  }

  @Test
  @Order(5)
  @Description("should create Employer Benefit Note  within a group")
  void addEmployerBenefitNoteForGroupProfileTest() {
    EmployerService serv = EmployerBenefitsUtil.getEmployerBenefitNote();

    webClient
        .put()
        .uri(RouteConstants.GROUPS_EMPLOYER_SERVICE_NOTE, group.getId(), 1L, serv)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), EmployerService.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(EmployerService.class)
        .consumeWith(
            response -> {
              EmployerService br = response.getResponseBody();
              EmployerBenefitsUtil.verifyEmployerServiceWithNote(serv, br);
            });
  }

  @Test
  @Order(6)
  @Description("should create sabBank within a subgroup")
  void addBankForSubGroupProfileTest() {
    SABank bank = EmployerBenefitsUtil.getSABank();
    assertNull(bank.getId());

    webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_EMP_SERVICE_SA_BANK, subGroup.getId(), 1L)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(bank), SABank.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(SABank.class)
        .consumeWith(
            response -> {
              SABank br = response.getResponseBody();
              EmployerBenefitsUtil.verifySABank(bank, br);
            });
  }

  @Test
  @Order(7)
  @Description("should update SA Bank details within a sub group if already exists")
  void updateSABankForSubGroupProfileTest() throws JsonProcessingException, InterruptedException {
    SABank bank = EmployerBenefitsUtil.getSABank();
    bank.setId(1L);
    bank.setBankName("Bank_1");
    EmployerBenefitsUtil.enqueueMockResponse(mockWebServer, bank);
    Mono<SABank> brokerMono =
        empBenefitsClient.saveOrUpdateSubGroupSABank(subGroup.getId(), 1L, bank);
    StepVerifier.create(brokerMono)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("Bank_1", b.getBankName());
              assertEquals(bank.getId(), b.getId());
            })
        .verifyComplete();
  }

  @Test
  @Order(8)
  @Description("should create Employer Service within a group")
  void addAccountServiceForSubGroupProfileTest() {
    AccountService serv = EmployerBenefitsUtil.getAccService();

    assertNull(serv.getId());
    webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_ACCOUNT_SERVICE, subGroup.getId(), 1L, serv)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), AccountService.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountService.class)
        .consumeWith(
            response -> {
              AccountService br = response.getResponseBody();
              EmployerBenefitsUtil.verifyAccountService(serv, br);
            });
  }

  @Test
  @Order(9)
  @Description("should update service  details within a SUB group if already exists")
  void updateAccountServiceForSubGroupProfileTest()
      throws JsonProcessingException, InterruptedException {
    AccountService accService = EmployerBenefitsUtil.getAccService();
    accService.setId(3L);
    accService.setServiceType("EAP-Other");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(accService)));
    Mono<AccountService> accServ =
        empBenefitsClient.saveOrUpdateSubGroupAccountService(subGroup.getId(), 1L, accService);
    StepVerifier.create(accServ)
        .assertNext(
            b -> {
              assertNotNull(b);
              assertEquals("EAP-Other", b.getServiceType());
              assertEquals(accService.getId(), b.getId());
            })
        .verifyComplete();
  }

  @Test
  @Order(10)
  @Description("should create Employer Benefit Note  within a sub group")
  void addEmployerBenefitNoteForSubGroupProfileTest() {
    EmployerService serv = EmployerBenefitsUtil.getEmployerBenefitNote();

    webClient
        .put()
        .uri(
            "/subgroup" + RouteConstants.SUBGROUPS_EMPLOYER_SERVICE_NOTE,
            subGroup.getId(),
            1L,
            serv)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(serv), EmployerService.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(EmployerService.class)
        .consumeWith(
            response -> {
              EmployerService br = response.getResponseBody();
              EmployerBenefitsUtil.verifyEmployerServiceWithNote(serv, br);
            });
  }

  @Test
  @Order(11)
  @Description("should update benefit notes within a SUB group if already exists")
  void updateEmployerNotesForSubGroupProfileTest()
      throws JsonProcessingException, InterruptedException {
    EmployerService empService = EmployerBenefitsUtil.getEmployerBenefitNote();
    empService.setBenefitNotes("Benefit Notes updated");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(empService)));
    Mono<EmployerService> accServ =
        empBenefitsClient.saveOrUpdateSubGroupEmployereNotes(subGroup.getId(), 1L, empService);
    StepVerifier.create(accServ)
        .assertNext(
            b -> {
              assertEquals("Benefit Notes updated", b.getBenefitNotes());
            })
        .verifyComplete();
  }

  @Test
  @Order(12)
  @Description("remove SA Bank from Group")
  void deleteSABankGroupProfileTest() throws JsonProcessingException {

    Group grp = EmployerBenefitsUtil.updateSABankGroupTestData(13L);

    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(grp)));
    Mono<Group> updatedGroup = empBenefitsClient.deleteBank(group.getId(), 13L, grp);
    StepVerifier.create(updatedGroup)
        .assertNext(
            b -> {
              assertThat(b.getAccountDetails().get(0).getEmployerServices().getSaBank().size())
                  .isEqualTo(1);
            })
        .verifyComplete();
  }

  @Test
  @Order(13)
  @Description("remove SA Bank from Sub Group")
  void deleteSABankSubGroupProfileTest() throws JsonProcessingException {

    SubGroup subGrp = EmployerBenefitsUtil.updateSABankSubGroupTestData(14L);

    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(200)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(new ObjectMapper().writeValueAsString(subGrp)));
    Mono<SubGroup> updatedGroup =
        empBenefitsClient.deleteSubGroupBank(subGroup.getId(), 13L, subGrp);
    StepVerifier.create(updatedGroup)
        .assertNext(
            b -> {
              assertThat(b.getAccountDetails().get(0).getEmployerServices().getSaBank().size())
                  .isEqualTo(1);
            })
        .verifyComplete();
  }
}
