package com.anthem.eap.group.utils;

import static com.anthem.eap.group.constants.GroupConstants.ZONE_UTC;

import com.anthem.eap.group.dto.ContactTypeResultDto;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.ContactInfo;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.model.user.Name;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class ContactTypeUtil {
  public static Group getGroup1() {
    Group group = new Group();
    group.setId(100L);
    group.setName("Verizon");
    group.setNational(false);
    group.setTin("123");
    group.setCallCenterCode("CallCenter123");
    group.setType("groupType");
    group.setContacts(getContactsList());
    return group;
  }

  public static Group getGroup2() {
    Group group = new Group();
    group.setId(101L);
    group.setName("Amazon");
    group.setNational(false);
    group.setTin("124");
    group.setCallCenterCode("CallCenter124");
    group.setType("groupType");
    return group;
  }

  public static Group getGroup3() {
    Group group = new Group();
    group.setId(102L);
    group.setName("Cosco");
    group.setNational(false);
    group.setTin("125");
    group.setCallCenterCode("CallCenter125");
    group.setType("groupType");
    return group;
  }

  public static Group getGroup4() {
    Group group = new Group();
    group.setId(108L);
    group.setName("Verizon");
    group.setNational(false);
    group.setTin("128");
    group.setCallCenterCode("CallCenter128");
    group.setType("groupType");
    List<GroupSubgroupContact> contactList = new ArrayList();
    GroupSubgroupContact contact1 = new GroupSubgroupContact();
    contact1.setId(150L);
    ContactInfo contactInfo1 = new ContactInfo();
    Name name1 = new Name();
    name1.setFullName("Smith2");
    name1.setFirstName("Jon1");
    name1.setLastName("Wilson1");
    contactInfo1.setContactId(1290L);
    contactInfo1.setName(name1);
    contactInfo1.setTin(333L);
    contact1.setContactInfo(contactInfo1);
    contact1.setContactType(GroupSubgroupContact.ContactType.ACCOUNT_CONTACT);
    contact1.setEffectiveDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(10));
    contact1.setTerminationDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(2));
    contactList.add(contact1);
    group.setContacts(contactList);
    return group;
  }

  public static Group getGroup5() {
    Group group = new Group();
    group.setId(112L);
    group.setName("Cosco-Wireless");
    group.setNational(false);
    group.setTin("1288");
    group.setCallCenterCode("CallCenter1288");
    group.setType("groupType");
    return group;
  }

  public static SubGroup getSubGroup1() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(103L);
    subGroup.setName("Verizon-WireLess1");
    subGroup.setGroupId(100L);
    subGroup.setContacts(getContactsList());
    return subGroup;
  }

  public static SubGroup getSubGroup2() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(104L);
    subGroup.setName("Verizon-WireLess2");
    subGroup.setGroupId(100L);
    subGroup.setContacts(getContactsList());
    return subGroup;
  }

  public static SubGroup getSubGroup3() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(105L);
    subGroup.setName("Amazon-WireLess1");
    subGroup.setGroupId(101L);
    return subGroup;
  }

  public static SubGroup getSubGroup4() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(106L);
    subGroup.setName("Amazon-WireLess2");
    subGroup.setGroupId(102L);
    subGroup.setContacts(getContactsList());
    return subGroup;
  }

  public static SubGroup getSubGroup5() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(110L);
    subGroup.setName("Cosco-Wireless-SG1");
    subGroup.setGroupId(112L);
    return subGroup;
  }

  public static SubGroup getSubGroup6() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(113L);
    subGroup.setName("Cosco-Wireless-SG2");
    subGroup.setGroupId(112L);
    return subGroup;
  }

  public static SubGroup getSubGroup7() {
    SubGroup subGroup = new SubGroup();
    subGroup.setId(120L);
    subGroup.setName("Verizon-SG1");
    subGroup.setGroupId(108L);
    List<GroupSubgroupContact> contactList = new ArrayList();
    GroupSubgroupContact contact1 = new GroupSubgroupContact();
    contact1.setId(151L);
    ContactInfo contactInfo1 = new ContactInfo();
    Name name1 = new Name();
    name1.setFullName("Smith2");
    name1.setFirstName("Jon1");
    name1.setLastName("Wilson1");
    contactInfo1.setContactId(1290L);
    contactInfo1.setName(name1);
    contactInfo1.setTin(555L);
    contact1.setContactInfo(contactInfo1);
    contact1.setContactType(GroupSubgroupContact.ContactType.PROMOTION_EMAIL_CONTACT);
    contact1.setEffectiveDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(10));
    contact1.setTerminationDate(null);
    contactList.add(contact1);
    subGroup.setContacts(contactList);
    return subGroup;
  }

  private static List<GroupSubgroupContact> getContactsList() {
    List<GroupSubgroupContact> contactList = new ArrayList();
    GroupSubgroupContact contact1 = new GroupSubgroupContact();
    ContactInfo contactInfo1 = new ContactInfo();
    Name name1 = new Name();
    name1.setFullName("Smith2");
    contactInfo1.setContactId(1235L);
    contactInfo1.setName(name1);
    contactInfo1.setTin(333L);
    contact1.setContactInfo(contactInfo1);
    contact1.setContactType(GroupSubgroupContact.ContactType.ACCOUNT_CONTACT);
    contact1.setEffectiveDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(10));
    contact1.setTerminationDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(2));
    contactList.add(contact1);

    GroupSubgroupContact contact2 = new GroupSubgroupContact();
    ContactInfo contactInfo2 = new ContactInfo();
    Name name = new Name();
    name.setFullName("John2");
    contactInfo2.setContactId(1234L);
    contactInfo2.setName(name);
    contactInfo2.setTin(444L);
    contact2.setContactInfo(contactInfo2);
    contact2.setContactType(GroupSubgroupContact.ContactType.ACCOUNT_CONTACT);
    contact2.setEffectiveDate(ZonedDateTime.now(ZoneId.of("UTC")).minusDays(5));
    contact2.setTerminationDate(ZonedDateTime.now(ZoneId.of("UTC")).plusDays(5));
    contactList.add(contact2);
    return contactList;
  }

  public static Contact contactTestData_1() {
    Contact contact = new Contact();
    contact.setId(1234L);
    Name name = new Name();
    name.setFirstName("Linda");
    name.setLastName("Smith");
    contact.setName(name);
    contact.setAccountName("Linda001");
    contact.setEmail("linda1@verizon.com");
    contact.setTitle("Account Rep");
    contact.setBrokerNumber(34453424L);
    contact.setTin(55555L);
    contact.setNotes("Added Primary address");
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);
    Address address = new Address();
    address.setStreet1("232 Main street");
    address.setStreet2("Suite 222");
    address.setCity("Savannah2");
    address.setStateCd("KY");
    address.setZip("05551");
    Phone phone = new Phone();
    phone.setNumber("8812522577");
    address.setPhone(phone);
    contact.setAddress(address);
    return contact;
  }

  public static Contact contactTestData_2() {
    Contact contact = new Contact();
    contact.setId(1235L);
    Name name = new Name();
    name.setFirstName("Jon");
    name.setLastName("Wilson");
    contact.setName(name);
    contact.setAccountName("JonWilson002");
    contact.setEmail("linda2@verizon.com");
    contact.setTitle("Account Rep");
    contact.setTin(12345L);
    contact.setBrokerNumber(34453424L);
    contact.setNotes("Added Wison address");
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);
    Address address = new Address();
    address.setStreet1("232 Eve street");
    address.setStreet2("Suite 232");
    address.setCity("Savannah");
    address.setStateCd("GA");
    address.setZip("05553");
    Phone phone = new Phone();
    phone.setNumber("8812522578");
    address.setPhone(phone);
    contact.setAddress(address);
    return contact;
  }

  public static Contact contactTestData_3() {
    Contact contact = new Contact();
    contact.setId(1236L);
    Name name = new Name();
    name.setFirstName("Jon1");
    name.setLastName("Wilson1");
    contact.setName(name);
    contact.setAccountName("JonWilson1002");
    contact.setEmail("linda3@verizon.com");
    contact.setTitle("Account Rep");
    contact.setTin(12347L);
    contact.setBrokerNumber(232323L);
    contact.setNotes("Added Wison1 address");
    ZonedDateTime todayDate = ZonedDateTime.now().withZoneSameInstant(ZoneId.of(ZONE_UTC));
    contact.setCreatedBy("System");
    contact.setCreatedDate(todayDate);
    contact.setLastModifiedBy("abc");
    contact.setLastModifiedDate(todayDate);
    Address address = new Address();
    address.setStreet1("234 Eve street");
    address.setStreet2("Suite 234");
    address.setCity("Savannah");
    address.setStateCd("GA");
    address.setZip("05555");
    Phone phone = new Phone();
    phone.setNumber("8812522599");
    address.setPhone(phone);
    contact.setAddress(address);
    return contact;
  }

  public static ContactTypeResultDto contactTypeFormTestData_1() {
    Name name = new Name();
    name.setFirstName("Linda");
    name.setLastName("Smith");
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setContactId(1234L);
    contactInfo.setTin(55555L);
    contactInfo.setName(name);
    ContactTypeResultDto contactTypeResultDto1 = new ContactTypeResultDto();
    contactTypeResultDto1.setEffectiveDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(3));
    contactTypeResultDto1.setTerminationDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(10));
    contactTypeResultDto1.setGroupId(112L);
    contactTypeResultDto1.setSubGroupId(110L);
    contactTypeResultDto1.setSubGroupName("Cosco-Wireless-SG1");
    contactTypeResultDto1.setContactType(GroupSubgroupContact.ContactType.PROMOTION_EMAIL_CONTACT);
    contactTypeResultDto1.setContactInfo(contactInfo);
    return contactTypeResultDto1;
  }

  public static ContactTypeResultDto contactTypeFormTestData_2() {
    Name name = new Name();
    name.setFirstName("Jon");
    name.setLastName("Wilson");
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setContactId(1235L);
    contactInfo.setTin(12345L);
    contactInfo.setName(name);
    ContactTypeResultDto contactTypeResultDto2 = new ContactTypeResultDto();
    contactTypeResultDto2.setEffectiveDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(3));
    contactTypeResultDto2.setTerminationDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(10));
    contactTypeResultDto2.setGroupId(112L);
    contactTypeResultDto2.setSubGroupName("Cosco-Wireless");
    contactTypeResultDto2.setContactType(GroupSubgroupContact.ContactType.INVOICE_RECIPIENT);
    contactTypeResultDto2.setContactInfo(contactInfo);
    return contactTypeResultDto2;
  }

  public static ContactTypeResultDto contactTypeFormTestData_3() {
    Name name = new Name();
    name.setFirstName("Jon1");
    name.setLastName("Wilson1");
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setContactId(1236L);
    contactInfo.setTin(12347L);
    contactInfo.setName(name);
    ContactTypeResultDto contactTypeResultDto2 = new ContactTypeResultDto();
    contactTypeResultDto2.setEffectiveDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(3));
    contactTypeResultDto2.setTerminationDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(10));
    contactTypeResultDto2.setGroupId(101L);
    contactTypeResultDto2.setGroupName("Amazon");
    contactTypeResultDto2.setContactType(GroupSubgroupContact.ContactType.BROKER);
    contactTypeResultDto2.setContactInfo(contactInfo);
    return contactTypeResultDto2;
  }

  public static ContactTypeResultDto contactTypeFormTestData_4() {
    Name name = new Name();
    name.setFirstName("Jon1");
    name.setLastName("Wilson1");
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setContactId(1290L);
    contactInfo.setTin(4443L);
    contactInfo.setName(name);
    ContactTypeResultDto contactTypeResultDto2 = new ContactTypeResultDto();
    contactTypeResultDto2.setEffectiveDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(3));
    contactTypeResultDto2.setTerminationDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(10));
    contactTypeResultDto2.setGroupId(108L);
    contactTypeResultDto2.setGroupName("Verizon");
    contactTypeResultDto2.setContactType(GroupSubgroupContact.ContactType.BROKER);
    contactTypeResultDto2.setContactInfo(contactInfo);
    contactTypeResultDto2.setContactTypeId(150L);
    return contactTypeResultDto2;
  }

  public static ContactTypeResultDto contactTypeFormTestData_5() {
    Name name = new Name();
    name.setFirstName("Jon1");
    name.setLastName("Wilson1");
    ContactInfo contactInfo = new ContactInfo();
    contactInfo.setContactId(1290L);
    contactInfo.setTin(3455L);
    contactInfo.setName(name);
    ContactTypeResultDto contactTypeResultDto2 = new ContactTypeResultDto();
    contactTypeResultDto2.setEffectiveDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(3));
    contactTypeResultDto2.setTerminationDate(ZonedDateTime.now(ZoneId.of(ZONE_UTC)).minusDays(10));
    contactTypeResultDto2.setGroupId(108L);
    contactTypeResultDto2.setContactTypeId(151L);
    contactTypeResultDto2.setSubGroupId(120L);
    contactTypeResultDto2.setGroupName("Verizon");
    contactTypeResultDto2.setSubGroupName("Verizon-SG1");
    contactTypeResultDto2.setContactType(GroupSubgroupContact.ContactType.HP_CONTACT);
    contactTypeResultDto2.setContactInfo(contactInfo);
    return contactTypeResultDto2;
  }
}
