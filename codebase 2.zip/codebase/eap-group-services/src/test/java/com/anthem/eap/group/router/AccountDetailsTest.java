package com.anthem.eap.group.router;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.anthem.eap.group.AbstractPersistableUnitTests;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.utils.AccountDetailsUtil;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class AccountDetailsTest extends AbstractPersistableUnitTests {

  @Autowired private SubGroupService subGroupService;

  @Autowired private GroupRepository groupRepository;

  @Autowired private SubGroupRepository subGroupRepo;

  private Group group;

  private SubGroup subGroup;

  private MockWebServer mockWebServer = new MockWebServer();

  @BeforeEach
  private void init() {
    group = AccountDetailsUtil.getGroup();
    subGroup = AccountDetailsUtil.getSubGroup();
    groupRepository.save(group).block();
    subGroupService.saveSubGroup(subGroup).block();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  @Order(1)
  @Description("should create account details within a group")
  void createAccountDetails() {
    AccountDetails accountDetails = AccountDetailsUtil.getAccountDetails();
    assertNull(accountDetails.getId());
    webClient
        .put()
        .uri(RouteConstants.GROUPS_ACCOUNT_DETAILS, group.getId())
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(accountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountDetails.class)
        .consumeWith(
            response -> {
              AccountDetails accountDetailsData = response.getResponseBody();
              assertNotNull(accountDetailsData);
              assertNotNull(accountDetailsData.getId());
            });
  }

  @Test
  @Order(2)
  @Description("should update account details within a group if already exists")
  void updateAccountForGroupProfileTest() throws JsonProcessingException, InterruptedException {
    AccountDetails updateAccountDetails = AccountDetailsUtil.updateGroupAccountDetails();
    updateAccountDetails.setProduct("Product Update");
    updateAccountDetails.setPlan("Plan Update");
    updateAccountDetails.setDcbtPortal("Portal Name Update");

    webClient
        .put()
        .uri(RouteConstants.GROUPS_ACCOUNT_DETAILS, 1l)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(updateAccountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountDetails.class)
        .consumeWith(
            response -> {
              AccountDetails updatedAccountRes = response.getResponseBody();
              Mono<Group> dbObject = groupRepository.findById(1l);
              StepVerifier.create(dbObject)
                  .assertNext(
                      result -> {
                        assertNotNull(result);
                        AccountDetailsUtil.verifyAccountDetails(result, updatedAccountRes);
                      })
                  .verifyComplete();
            });
  }

  @Test
  @Order(3)
  @Description("view active account details for group id")
  void getActiveAccountForValidGroupId() throws NullPointerException {
    Group activeGroupAccountDetails = AccountDetailsUtil.getGroupWithActiveAccount();
    groupRepository.save(activeGroupAccountDetails).block();
    webClient
        .get()
        .uri(RouteConstants.ACTIVE_GROUP_ACCOUNT_DETAILS_SEARCH, 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(AccountDetails.class)
        .value(accountData -> assertNotNull(accountData));
  }

  @Test
  @Order(4)
  @Description("should fail for active account details when groupId is invalid")
  void getActiveAccountForInvalidGroupId() {
    group.setId(null);
    webClient
        .get()
        .uri(RouteConstants.ACTIVE_GROUP_ACCOUNT_DETAILS_SEARCH, group.getId())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  @Order(5)
  @Description("view renewal group account details")
  void getRenewAccountDetailsByGroupId() throws NullPointerException {
    Group renewalGroupAccountDetails = AccountDetailsUtil.getGroupRenewalAccountDetails();
    groupRepository.save(renewalGroupAccountDetails).block();
    webClient
        .get()
        .uri(RouteConstants.GROUP_ACCOUNT_RENEWAL, group.getId(), 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(AccountDetails.class)
        .value(accountData -> assertNotNull(accountData));
  }

  @Test
  @Order(6)
  @Description("should fail for renewal account details when group id is invalid")
  void returnEmptyWhenRenewalGroupIdIsInvalid() throws NullPointerException {
    webClient
        .get()
        .uri(RouteConstants.GROUP_ACCOUNT_RENEWAL, 10l, 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @Order(7)
  @Description("should create account details within a subgroup")
  void addACcountForSubGroupProfileTest() {
    AccountDetails accountDetails = AccountDetailsUtil.getAccountDetails();
    assertNull(accountDetails.getId());
    webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_ACCOUNT_DETAILS, 1l)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(accountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountDetails.class)
        .consumeWith(
            response -> {
              AccountDetails accountRes = response.getResponseBody();
              assertNotNull(accountRes);
              assertNotNull(accountRes.getId());
            });
  }

  @Test
  @Order(8)
  @Description("should update account details within a sub group if already exists")
  void updateAccountForSubGroupProfileTest() {
    AccountDetails updateAccountDetails = AccountDetailsUtil.updateSubGroupAccountDetails();
    updateAccountDetails.setPlan("Sub Group Plan Update");
    updateAccountDetails.setDcbtPortal("Sub Group Portal Name Update");
    updateAccountDetails.setEapPhone("Sub Group EAP PHONE Update");
    updateAccountDetails.setProgramName("Sub Group Program Name Update");

    webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_ACCOUNT_DETAILS, 1l)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(updateAccountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(AccountDetails.class)
        .consumeWith(
            response -> {
              AccountDetails updatedAccountRes = response.getResponseBody();
              Mono<Group> dbObject = groupRepository.findById(1l);
              StepVerifier.create(dbObject)
                  .assertNext(
                      result -> {
                        assertNotNull(result);
                        AccountDetailsUtil.verifyAccountDetails(result, updatedAccountRes);
                      })
                  .verifyComplete();
            });
  }

  @Test
  @Order(9)
  @Description("view renewal sub group account details")
  void getRenewAccountDetailsBySubGroupId() throws NullPointerException {
    SubGroup renewalSubGroupAccountDetails = AccountDetailsUtil.getSubGroupRenewalAccountDetails();
    subGroupRepo.save(renewalSubGroupAccountDetails).block();
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.SUB_GROUP_ACCOUNT_RENEWAL, subGroup.getId(), 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(AccountDetails.class)
        .value(accountData -> assertNotNull(accountData));
  }

  @Test
  @Order(10)
  @Description("should fail for renewal account details when sub group id is invalid")
  void returnEmptyWhenRenewalSubGroupIdIsInvalid() throws NullPointerException {
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.SUB_GROUP_ACCOUNT_RENEWAL, 40l, 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  @Order(11)
  @Description("view active account details for sub group id")
  void getActiveAccountForValidSubGroupId() {
    SubGroup activeSubGroupAccountDetails = AccountDetailsUtil.getSubGroupWithActiveAccount();
    subGroupRepo.save(activeSubGroupAccountDetails).block();
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.ACTIVE_SUB_GROUP_ACCOUNT_DETAILS_SEARCH, 1l)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(AccountDetails.class)
        .value(accountData -> assertNotNull(accountData));
  }

  @Test
  @Order(12)
  @Description("should fail for active account details when sub groupId is invalid")
  void getActiveAccountForInvalidSubGroupId() {
    subGroup.setId(null);
    webClient
        .get()
        .uri("/subgroup" + RouteConstants.ACTIVE_SUB_GROUP_ACCOUNT_DETAILS_SEARCH, subGroup.getId())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  @Order(13)
  @Description("should fail for account details when groupId is invalid")
  void returnEmptyWhenGroupIdIsNull() {
    AccountDetails accountDetails = AccountDetailsUtil.getAccountDetails();
    group.setId(null);
    webClient
        .put()
        .uri(RouteConstants.GROUPS_ACCOUNT_DETAILS, group.getId())
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(accountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  @Order(14)
  @Description("should fail for account details when subGroupId is invalid")
  void returnEmptyWhenSubGroupIdIsNull() {
    AccountDetails accountDetails = AccountDetailsUtil.getAccountDetails();
    subGroup.setId(null);
    webClient
        .put()
        .uri("/subgroup" + RouteConstants.SUBGROUPS_ACCOUNT_DETAILS, subGroup.getId())
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(accountDetails), AccountDetails.class)
        .exchange()
        .expectStatus()
        .isNotFound();
  }
}
