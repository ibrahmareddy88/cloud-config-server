package com.anthem.eap.group;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import com.anthem.eap.group.model.GroupEmployeeCountImport;
import com.anthem.eap.group.service.GroupEmployeeCountUploadService;
import com.anthem.eap.group.util.EmployeeCountUploadUtil;
import com.anthem.eap.model.group.EmployeeCount;
import com.anthem.eap.model.group.Group;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class GroupEmployeeCountUploadTest extends AbstractPersistableUnitTests {
  @Autowired GroupEmployeeCountUploadService employeeCountUploadService;
  EmployeeCount employeeCount = new EmployeeCount();
  public static final Log log = LogFactory.getLog(GroupEmployeeCountUploadTest.class);

  private static final Group group = new Group();
  private static final ZonedDateTime zonedDateTimeOf =
      ZonedDateTime.of(2021, 10, 10, 0, 0, 0, 0, ZoneId.of("UTC"));

  @Test
  void testUploadCountSuccess() {
    employeeCountDataInDb();
    String grpName = "anthem";
    String grpId = "1";
    String count = "120";
    String asOfDate = "10/10/2021";
    List<GroupEmployeeCountImport> employeeCountsList =
        employeeCountInputForTest(grpName, grpId, count, asOfDate);
    try {
      employeeCountUploadService.processUploadingEmployeeCounts(employeeCountsList);
    } catch (Exception e) {
      log.info(e.getMessage());
    }
    assertEquals(group.getId(), Long.parseLong(grpId));
    assertEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals("10/11/2021", employeeCount.getAsOfDate().toLocalDate());
      assertEquals(120L, employeeCount.getCount());
    }
    assertEquals(null, employeeCountsList.get(0).getError());
    employeeCountsList.clear();
  }

  @Test
  void testUploadCountScenariosWithErrorMessages() throws Exception {
    GroupEmployeeCountImport groupEmployeeCountImport = new GroupEmployeeCountImport();
    // group name validation
    String grpName = null;
    String grpId = "1";
    String count = "120";
    String asOfDate = "10/10/2021";
    groupEmployeeCountImport = groupEmployeeCountImportTestData(grpId, grpName, count, asOfDate);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(group.getId(), Long.parseLong(grpId));
    assertNotEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals("10/11/2021", employeeCount.getAsOfDate().toLocalDate());
      assertEquals(120L, employeeCount.getCount());
    }
    assertEquals("Invalid group name", groupEmployeeCountImport.getError());
    // group Id validation
    grpName = "anthem";
    grpId = null;
    groupEmployeeCountImport = groupEmployeeCountImportTestData(grpId, grpName, count, asOfDate);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertNotEquals(group.getId(), grpId);
    assertEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals("10/11/2021", employeeCount.getAsOfDate().toLocalDate());
      assertEquals(120L, employeeCount.getCount());
    }
    assertEquals("Invalid EAP group id", groupEmployeeCountImport.getError());

    // asOfDate validation
    grpId = "1";
    asOfDate = null;
    groupEmployeeCountImport = groupEmployeeCountImportTestData(grpId, grpName, count, asOfDate);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(group.getId(), Long.parseLong(grpId));
    assertEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals(null, employeeCount.getAsOfDate().toLocalDate());
      assertEquals(120L, employeeCount.getCount());
    }
    assertEquals("Invalid as of date", groupEmployeeCountImport.getError());

    // Count validation
    asOfDate = "10/10/2021";
    count = null;
    groupEmployeeCountImport = groupEmployeeCountImportTestData(grpId, grpName, count, asOfDate);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(group.getId(), Long.parseLong(grpId));
    assertEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals("10/10/2021", employeeCount.getAsOfDate().toLocalDate());
      assertEquals(null, employeeCount.getCount());
    }
    assertEquals("Invalid employee count", groupEmployeeCountImport.getError());

    // multiple comma seperated count input
    count = "1,00,000,112";
    groupEmployeeCountImport = groupEmployeeCountImportTestData(grpId, grpName, count, asOfDate);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(group.getId(), Long.parseLong(grpId));
    assertEquals(group.getName(), grpName);
    if (group.getId().equals(grpId) && group.getName().equals(grpName)) {
      assertEquals(count, employeeCount.getCount());
    }
    assertEquals(null, groupEmployeeCountImport.getError());
  }

  @Test
  void testUploadCountCombinedErrorMessages() {
    GroupEmployeeCountImport groupEmployeeCountImport = new GroupEmployeeCountImport();
    groupEmployeeCountImport = groupEmployeeCountImportTestData(null, null, null, null);
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(
        "Invalid group name, Invalid EAP group id, Invalid as of date, Invalid employee count",
        groupEmployeeCountImport.getError());
  }

  @Test
  void testCombinedErrorMessagesForInvalidAndNullInputs() throws Exception {
    employeeCountDataInDb();
    GroupEmployeeCountImport groupEmployeeCountImport = new GroupEmployeeCountImport();
    groupEmployeeCountImport =
        groupEmployeeCountImportTestData(null, "anthem", "1000", "07/06/2023");
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals("Invalid EAP group id", groupEmployeeCountImport.getError());
    // wrong input data
    groupEmployeeCountImport =
        groupEmployeeCountImportTestData("1", "anthemtest", "1000", "07/06/20z");
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals("Invalid group name, Invalid as of date", groupEmployeeCountImport.getError());
    // wrong input data alongwith null
    groupEmployeeCountImport =
        groupEmployeeCountImportTestData("1", "anthemtest", null, "07/06/20z");
    EmployeeCountUploadUtil.validateGroupAndSubGroup(groupEmployeeCountImport, group, null, null);
    assertEquals(
        "Invalid group name, Invalid as of date, Invalid employee count",
        groupEmployeeCountImport.getError());
  }
  // duplicate record check
  @Test
  void testDuplicateRecord() {
    List<GroupEmployeeCountImport> employeeCountsList = new ArrayList<GroupEmployeeCountImport>();
    GroupEmployeeCountImport grpEmpCountData = new GroupEmployeeCountImport();
    employeeCountDataInDb();
    String grpName = "anthem";
    String grpId = "1";
    String count = "120";
    String asOfDate = "10/10/2021";
    employeeCountsList = employeeCountInputForTest(grpName, grpId, count, asOfDate);
    grpEmpCountData.setAsOfDate(asOfDate);
    grpEmpCountData.setCount(count);
    grpEmpCountData.setGroupId(grpId);
    grpEmpCountData.setGroupName(grpName);
    employeeCountsList.add(1, grpEmpCountData);
    try {
      employeeCountUploadService.processUploadingEmployeeCounts(employeeCountsList);
    } catch (Exception e) {
      log.info(e.getMessage());
    }
    assertEquals("Duplicate record", employeeCountsList.get(0).getError());
    assertEquals("Duplicate record", employeeCountsList.get(1).getError());
    employeeCountsList.clear();
  }

  private Group employeeCountDataInDb() {
    EmployeeCount empcount = new EmployeeCount();
    empcount.setCount("120");
    empcount.setAsOfDate(zonedDateTimeOf);
    List<EmployeeCount> empcountlst = new ArrayList<EmployeeCount>();
    empcountlst.add(empcount);
    group.setId(1L);
    group.setName("anthem");
    group.setEmployeeCount(empcountlst);
    mongoTemplate.save(group);
    return group;
  }

  private List<GroupEmployeeCountImport> employeeCountInputForTest(
      String grpName, String grpId, String count, String asOfDate) {
    List<GroupEmployeeCountImport> employeeCountsList = new ArrayList<GroupEmployeeCountImport>();
    GroupEmployeeCountImport empCountList = new GroupEmployeeCountImport();
    empCountList.setGroupName(grpName);
    empCountList.setGroupId(grpId);
    empCountList.setCount(count);
    empCountList.setAsOfDate(asOfDate);
    employeeCountsList.add(empCountList);
    return employeeCountsList;
  }

  private GroupEmployeeCountImport groupEmployeeCountImportTestData(
      String groupId, String groupName, String count, String asOfDate) {
    GroupEmployeeCountImport groupEmployeeCountImport = new GroupEmployeeCountImport();
    groupEmployeeCountImport.setGroupId(groupId);
    groupEmployeeCountImport.setGroupName(groupName);
    groupEmployeeCountImport.setCount(count);
    groupEmployeeCountImport.setAsOfDate(asOfDate);
    return groupEmployeeCountImport;
  }
}
