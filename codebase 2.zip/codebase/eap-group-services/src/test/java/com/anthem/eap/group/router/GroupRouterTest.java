package com.anthem.eap.group.router;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;

import com.anthem.eap.group.dto.HealthPlanIdGroupSearchResultDTO;
import com.anthem.eap.group.handler.GroupHandler;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.service.GroupService;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.utils.SubGroupRouteTestUtil;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.ContactInfo;
import com.anthem.eap.model.group.Alert;
import com.anthem.eap.model.group.Alias;
import com.anthem.eap.model.group.EmployeeCount;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.TerminationInfo;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.model.user.Name;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Description;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** @author Legato */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {GroupRouter.class, GroupHandler.class})
@WebFluxTest
class GroupRouterTest {
  private static final Group group;
  private static final ZonedDateTime zonedDateTimeOf =
      ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
  private static final GroupSearchResultsDto GROUP_DTO =
      new GroupSearchResultsDto(
          1L,
          "testGroup1",
          "Group",
          "",
          "testAddressName",
          "Active",
          null,
          null,
          null,
          null,
          "112456",
          null,
          null);

  static {
    group = new Group();
    group.setId(1L);
    group.setName("testGroup1");
    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    group.setHealthPlanIds(strlst);
    group.setNational(false);
    group.setTin("test");
    group.setCallCenterCode("test");
    group.setType("test");

    List<Address> addlst = new ArrayList<Address>();
    Address address = new Address();
    address.setCity("vijayawada");
    address.setCountryCd("520011");
    address.setCounty("india");
    address.setStateCd("Andhra Pradesh");
    address.setStreet1("Kedar Street");
    address.setStreet2("madhura Nagar");
    address.setStreet3("street");
    address.setType(Address.Type.HOME);
    address.setZip("523009");
    address.setZipExtn("78787");
    addlst.add(address);
    group.setAddresses(addlst);

    List<Alias> lst = new ArrayList<Alias>();
    Alias alias = new Alias();
    alias.setAlias("test");
    alias.setAliasType("test");
    lst.add(alias);
    group.setAliases(lst);

    List<Alert> alrt = new ArrayList<Alert>();
    Alert alert = new Alert();
    alert.setAlert("test");
    alert.setCreateOrEditBy("created");
    ZonedDateTime zonedDateTimeOf = ZonedDateTime.of(2021, 06, 01, 0, 0, 0, 0, ZoneId.of("UTC"));
    alert.setEffectiveDate(zonedDateTimeOf);
    alrt.add(alert);
    group.setAlerts(alrt);

    List<GroupSubgroupContact> grpcontlst = new ArrayList<GroupSubgroupContact>();
    GroupSubgroupContact grpCon = new GroupSubgroupContact();
    ContactInfo contactInfo = new ContactInfo();
    Name name = new Name();
    name.setFullName("full Name");
    contactInfo.setContactId(666L);
    contactInfo.setName(name);
    contactInfo.setTin(123456789L);
    grpCon.setContactInfo(contactInfo);
    grpCon.setContactType(GroupSubgroupContact.ContactType.ACCOUNT_CONTACT);
    grpCon.setEffectiveDate(zonedDateTimeOf);
    grpCon.setTerminationDate(zonedDateTimeOf);
    group.setContacts(grpcontlst);

    EmployeeCount empcount = new EmployeeCount();
    empcount.setCount("1234");
    empcount.setAsOfDate(zonedDateTimeOf);
    List<EmployeeCount> empcountlst = new ArrayList<EmployeeCount>();
    empcountlst.add(empcount);
    group.setEmployeeCount(empcountlst);

    List<TerminationInfo> terminationList = new ArrayList<TerminationInfo>();
    TerminationInfo terinfo = new TerminationInfo();
    ZonedDateTime zonedDateTime = ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
    terinfo.setEffectiveDate(zonedDateTime);
    terinfo.setNewEAPVendor("testVendor");
    terinfo.setReinstatedBy("test");
    terinfo.setTerminatedBy("test");
    terinfo.setTerminationDate(zonedDateTime);
    terinfo.setTerminationNotes("terminationNote");
    terinfo.setTerminationReason("test");
    terminationList.add(terinfo);
    group.setTerminationList(terminationList);
    group.setIndustryNote("industryNote");
  }

  @Autowired private ApplicationContext context;
  @MockBean private GroupService groupService;
  @MockBean private SubGroupService subGroupService;
  @MockBean private GroupRepository groupRepository;

  private WebTestClient webTestClient;

  @BeforeEach
  public void setUp() {

    webTestClient = WebTestClient.bindToApplicationContext(context).build();
  }

  @Test
  @Order(3)
  void createGroupTest() {
    Mono<Group> groupMono = Mono.just(group);
    group.setCreatedDate(zonedDateTimeOf);
    group.setLastModifiedBy("test");
    group.setLastModifiedDate(zonedDateTimeOf);
    group.setCreatedBy("test");
    Mockito.when(groupService.save(any(Group.class))).thenReturn(groupMono);

    webTestClient
        .post()
        .uri("/group")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(group), Group.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Group.class)
        .value(
            groupResponse -> {
              ZonedDateTime zonedDateTimeOf =
                  ZonedDateTime.of(2021, 06, 01, 0, 0, 0, 0, ZoneId.of("UTC"));
              ZonedDateTime zonedDateTime =
                  ZonedDateTime.of(2021, 06, 10, 0, 0, 0, 0, ZoneId.of("UTC"));
              assertThat(groupResponse.getName()).isEqualTo("testGroup1");
              assertThat(groupResponse.getId()).isEqualTo(1L);
              assertThat(groupResponse.getHealthPlanIds().listIterator(0).next())
                  .isEqualTo("test1");
              assertThat(groupResponse.getHealthPlanIds().listIterator(1).next())
                  .isEqualTo("test2");
              assertThat(groupResponse.isNational()).isFalse();
              assertThat(groupResponse.getTin()).isEqualTo("test");
              assertThat(groupResponse.getCallCenterCode()).isEqualTo("test");
              assertThat(groupResponse.getAddresses().listIterator(0).next().getCity())
                  .isEqualTo("vijayawada");
              assertThat(groupResponse.getAddresses().listIterator(0).next().getCountryCd())
                  .isEqualTo("520011");
              assertThat(groupResponse.getAddresses().listIterator(0).next().getCounty())
                  .isEqualTo("india");
              assertThat(groupResponse.getAddresses().listIterator(0).next().getZip())
                  .isEqualTo("523009");
              assertThat(groupResponse.getAddresses().listIterator(0).next().getZipExtn())
                  .isEqualTo("78787");
              assertThat(groupResponse.getAliases().listIterator(0).next().getAlias())
                  .isEqualTo("test");
              assertThat(groupResponse.getAliases().listIterator(0).next().getAliasType())
                  .isEqualTo("test");
              assertThat(groupResponse.getAlerts().listIterator(0).next().getAlert())
                  .isEqualTo("test");
              assertThat(groupResponse.getAlerts().listIterator(0).next().getCreateOrEditBy())
                  .isEqualTo("created");
              assertThat(groupResponse.getAlerts().listIterator(0).next().getEffectiveDate())
                  .isEqualTo(zonedDateTimeOf);
              assertThat(groupResponse.getEmployeeCount().listIterator(0).next().getCount())
                  .isEqualTo("1234");
              assertThat(groupResponse.getEmployeeCount().listIterator(0).next().getAsOfDate())
                  .isEqualTo(zonedDateTimeOf);
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getEffectiveDate())
                  .isEqualTo(zonedDateTime);
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getNewEAPVendor())
                  .isEqualTo("testVendor");
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getReinstatedBy())
                  .isEqualTo("test");
              assertThat(
                      groupResponse.getTerminationList().listIterator(0).next().getTerminatedBy())
                  .isEqualTo("test");
            });
  }

  @Test
  @Order(1)
  void testHasGroupName() {
    Mockito.when(groupService.findByName("testGroup1")).thenReturn(Flux.just(group));
    String groupName = "testGroup1";
    webTestClient
        .get()
        .uri("/group?name=" + groupName)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(Group.class)
        .value(
            groupResponse -> {
              assertNotNull(groupResponse);
            });
  }

  @Test
  @Order(2)
  void testGetGroupById() {
    Long id = 1L;
    Mockito.when(groupService.getGroupById(1L)).thenReturn(Mono.just(group));
    webTestClient
        .get()
        .uri("/group/" + id)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Group.class)
        .value(
            groupResponse -> {
              assertThat(groupResponse.getName()).isEqualTo("testGroup1");
            });
  }

  @Test
  @Order(4)
  void testGetGroups() {
    Mockito.when(groupService.findGroupsByKeyword(any(), anyBoolean()))
        .thenReturn(Flux.just(GROUP_DTO));
    webTestClient
        .get()
        .uri("/group?filterBy=ver")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(GroupSearchResultsDto.class);
  }

  @Test
  @Order(5)
  void testGetGroupsWithoutFilter() {
    Mockito.when(groupService.findGroupsByKeyword(any(), anyBoolean()))
        .thenReturn(Flux.just(GROUP_DTO));
    webTestClient
        .get()
        .uri("/group")
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(GroupSearchResultsDto.class);
  }

  @Test
  @Order(6)
  @Description("should return empty response if group id does not found ")
  void returnEmptyResponseWhenGroupIdNotFound() {
    Mockito.when(groupService.getGroupById(2L)).thenReturn(Mono.empty());

    webTestClient
        .get()
        .uri("/group/{id}", 2L)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .value(res -> assertNull(res));
  }

  @Test
  @Order(7)
  @Description("should update group if it already exists ")
  void updateGroup() {
    Group groupdta = group;
    groupdta.setIndustryNote("Industry Note Updated");
    groupdta.setCreatedDate(zonedDateTimeOf);
    groupdta.setLastModifiedBy("test");
    groupdta.setLastModifiedDate(zonedDateTimeOf);
    groupdta.setCreatedBy("test1");
    Mockito.when(groupService.update(any(Group.class))).thenReturn(Mono.just(groupdta));
    webTestClient
        .put()
        .uri("/group/" + 1L)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(groupdta), Group.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Group.class)
        .consumeWith(
            response -> {
              assertEquals("Industry Note Updated", response.getResponseBody().getIndustryNote());
            });
  }

  @Test
  @Order(8)
  @Description("should return empty response if group is null ")
  void returnEmptyResponseWhenGroupIdNULL() {
    Mockito.when(groupService.update(any())).thenReturn(Mono.empty());
    webTestClient
        .put()
        .uri("/group/" + 1L)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(group), Group.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Group.class)
        .consumeWith(
            response -> {
              assertNull(response.getResponseBody());
            });
  }

  @Test
  @Order(9)
  @Description("should return matching group id for the given health plan id")
  void testMatchingGroupForGivenHealthPlan() {
    HealthPlanIdGroupSearchResultDTO GROUP_SEARCH_DTO =
        new HealthPlanIdGroupSearchResultDTO(1L, null, "Group Found");

    Mockito.when(groupService.getMachingGroupsByHealthPlanId("test1"))
        .thenReturn(Mono.just(GROUP_SEARCH_DTO));
    webTestClient
        .get()
        .uri("/group/healthPlan/" + "test1")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(HealthPlanIdGroupSearchResultDTO.class)
        .value(response -> assertEquals(response.getGroupId(), group.getId()));
  }

  @Test
  @Order(10)
  @Description("should return dummy group id if no match found ")
  void testNoMatchingGroupForGivenHealthPlan() {
    HealthPlanIdGroupSearchResultDTO GROUP_SEARCH_DTO =
        new HealthPlanIdGroupSearchResultDTO(0L, null, "Group Found");

    Mockito.when(groupService.getMachingGroupsByHealthPlanId("test3"))
        .thenReturn(Mono.just(GROUP_SEARCH_DTO));
    webTestClient
        .get()
        .uri("/group/healthPlan/" + "test3")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(HealthPlanIdGroupSearchResultDTO.class)
        .value(
            response -> {
              long groupId = response.getGroupId();
              assertEquals(0L, groupId);
            });
  }

  @Test
  @Order(11)
  @Description("should fail as multiple matching groups found ")
  void testReferralFailedGivenHealthPlan() {
    Group groupData = new Group();
    groupData.setId(3L);
    List<String> strlst = new ArrayList<String>();
    strlst.add("test1");
    strlst.add("test2");
    groupData.setHealthPlanIds(strlst);
    HealthPlanIdGroupSearchResultDTO GROUP_SEARCH_DTO =
        new HealthPlanIdGroupSearchResultDTO(null, "Referral Failed", "null");
    Mockito.when(groupService.save(groupData)).thenReturn(Mono.just(groupData));

    Mockito.when(groupService.getMachingGroupsByHealthPlanId("test1"))
        .thenReturn(Mono.just(GROUP_SEARCH_DTO));
    webTestClient
        .get()
        .uri("/group/healthPlan/" + "test1")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(HealthPlanIdGroupSearchResultDTO.class)
        .value(
            response -> {
              assertEquals("Referral Failed", response.getErrorMessage());
            });
  }

  @Test
  @Order(12)
  @Description("expects sub group parent id if a health plan id match is not found in Group.")
  void testGetSubGroupParentIdForHealthPlanMatch() {
    SubGroup subGroupData = new SubGroup();
    BeanUtils.copyProperties(SubGroupRouteTestUtil.subGroupMock(1L), subGroupData);
    HealthPlanIdGroupSearchResultDTO GROUP_SEARCH_DTO =
        new HealthPlanIdGroupSearchResultDTO(1L, null, "Group Found");
    Mockito.when(subGroupService.saveSubGroup(any(SubGroup.class)))
        .thenReturn(Mono.just(subGroupData));
    Mockito.when(groupService.getMachingGroupsByHealthPlanId("test1"))
        .thenReturn(Mono.just(GROUP_SEARCH_DTO));
    webTestClient
        .get()
        .uri("/group/healthPlan/" + "test1")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(HealthPlanIdGroupSearchResultDTO.class)
        .value(
            response -> {
              assertEquals(subGroupData.getGroupId(), response.getGroupId());
            });
  }
}
