package com.anthem.eap.group.model;

import com.anthem.eap.model.group.Group;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CountImportWithGroup {
  public CountImportWithGroup(GroupEmployeeCountImport groupEmployeeCountImport) {
    this.groupEmployeeCountImport = groupEmployeeCountImport;
  }

  private GroupEmployeeCountImport groupEmployeeCountImport;
  private Group group;
}
