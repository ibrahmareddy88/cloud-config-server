package com.anthem.eap.group.repository;

import com.anthem.eap.model.accountProfile.BrokerCommission;
import com.anthem.eap.repository.MongoAuditingRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BrokerCommissionRepository extends MongoAuditingRepository {

  Mono<BrokerCommission> findAndModifyBrokerCommission(
      Long id, Long accountDetailsId, BrokerCommission brokerCommission, String type);
}
