package com.anthem.eap.group.util;

import com.anthem.eap.group.dto.ContactTypeDto;
import com.anthem.eap.group.dto.ContactTypeResultDto;
import com.anthem.eap.model.group.GroupSubgroupContact;
import org.springframework.beans.BeanUtils;

/** @author AH33639 Elisha */
public class ContactTypeUtil {

  public static ContactTypeResultDto mappingToContactTypeResultDto(
      GroupSubgroupContact groupSubgroupContact) {
    ContactTypeResultDto contactTypeResultDto = new ContactTypeResultDto();
    BeanUtils.copyProperties(groupSubgroupContact, contactTypeResultDto);
    contactTypeResultDto.setContactTypeId(groupSubgroupContact.getId());
    return contactTypeResultDto;
  }

  public static GroupSubgroupContact mappingToGroupSubGroupContact(
      ContactTypeResultDto contactTypeResultDto) {
    GroupSubgroupContact groupSubgroupContact = new GroupSubgroupContact();
    BeanUtils.copyProperties(contactTypeResultDto, groupSubgroupContact);
    groupSubgroupContact.setLastModifiedDate(null);
    groupSubgroupContact.setId(contactTypeResultDto.getContactTypeId());
    return groupSubgroupContact;
  }

  public static ContactTypeResultDto mappingToContactTypeResultDtoFromContactTypeDto(
      ContactTypeDto contactTypeDto) {
    ContactTypeResultDto contactTypeResultDto = new ContactTypeResultDto();
    BeanUtils.copyProperties(contactTypeDto, contactTypeResultDto);
    contactTypeResultDto.setContactTypeId(contactTypeDto.getContactTypeId());
    return contactTypeResultDto;
  }
}
