package com.anthem.eap.group.dto;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.group.GroupSubgroupContact;
import java.util.List;
import lombok.Data;

@Data
public class BrokerContactsDTO {

  private List<GroupSubgroupContact> contacts;
  private AccountDetails accountDetails;
}
