package com.anthem.eap.group.util;

import java.util.Date;

public class FileUtil {

  private static final String ENGAGE_REPORT_FILE_PREFIX = "Anthem Engage Report_";
  public static final String FILE_EXTENSION = ".xlsx";

  private FileUtil() {}

  public static String getEngageReportFileName() {
    String currentDateTime = DateUtil.DATE_FORMATER.format(new Date());
    StringBuilder stringBuilder = new StringBuilder();
    return stringBuilder
        .append(ENGAGE_REPORT_FILE_PREFIX)
        .append(currentDateTime.replace(":", ""))
        .toString();
  }
}
