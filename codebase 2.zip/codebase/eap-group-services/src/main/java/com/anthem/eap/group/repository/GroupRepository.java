package com.anthem.eap.group.repository;

import com.anthem.eap.config.EAPBeanResolver;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.ActiveVendorDetailsDTO;
import com.anthem.eap.group.dto.ContactTypeDto;
import com.anthem.eap.group.dto.GroupAccountDetailDto;
import com.anthem.eap.group.dto.GroupSubGroupContactDto;
import com.anthem.eap.group.repository.custom.GroupCustomRepo;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.consultaton.dto.BankHoursDto;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.dto.GroupNameAddressDto;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** @author Dineel Bathina */
@Repository
public interface GroupRepository extends GroupMongoRepository<Group>, GroupCustomRepo {
  @org.springframework.data.mongodb.repository.Query("{ id: { $exists: true }}")
  Flux<Group> pagination(Sort sort);

  @Aggregation(
      pipeline = {
        "{$addFields: {tempId: {$toString: '$_id' }}}",
        "{$match: {$or : [{'name':{$regex:?1,$options:'i'}}, {'healthPlanIds':{$regex:?1,$options:'i'}}, {'tempId':{$regex:?1,$options:'i'}}]}}",
        "{$project: {'id': 1,'name': 1,'lastModifiedDate': 1,'nameType': 'Group', 'healthPlanId': {$reduce:{input: '$healthPlanIds',initialValue: '',"
            + "in:{$concat:['$$value',{$cond: {if: { $eq: [ '$$value', ''] }, then: '', else: ','}},'$$this']}}},"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'status' : { $switch: { "
            + "                    branches: [ "
            + "                          {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "               cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                     {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                     {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                              $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                  cond: {$and:[{$gte : ['$$accountDetails.expiryDate', new Date() ]},{$lte : ['$$accountDetails.effectiveDate', new Date()]}]}}}, []]}},0] "
            + "                              }]  }  ] }, "
            + "                          then: 'Active' }, "
            + "                          {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }},[]]}}, 0] }, "
            + "                              {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                              $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                  cond:{$and:[{$gte : ['$$accountDetails.expiryDate', new Date() ]}]}}}, []]}},0] "
            + "                              }]  } ]  },{ "
            + "                              $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$lte : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }}, []]}}, 0] },{ "
            + "                             $or: [{$ifNull:['$accountDetails',true]},{$eq:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                             $eq : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                 cond:{$gte : ['$$accountDetails.expiryDate', new Date() ]}}}, []]}},0] "
            + "                             }]  } ] }]}, "
            + "                          then: 'InActive'},] "
            + "                   ,default: 'Closed' } }}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findGroupsByKeyword(Date date, String searchVal);

  @Aggregation(
      pipeline = {
        "{$unwind: '$aliases'}",
        "{$addFields: {tempId: {$toString: '$_id' }, aliasName: '$aliases.alias'}}",
        "{$match: {'aliasName':{$regex:?1,$options:'i'}}}",
        "{$project: {'id': 1,'name': '$aliasName','lastModifiedDate': 1,'nameType': 'Alias','healthPlanId': { $arrayElemAt: [ '$healthPlanIds', 0 ] },'parentType': 'Group',"
            + "'parentGroupId': '$_id',"
            + "'parentGroupName': '$name',"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'status' : { $switch: { "
            + "                    branches: [ "
            + "                          {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "               cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                     {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                     {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                              $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                  cond: {$and:[{$gte : ['$$accountDetails.expiryDate', new Date() ]},{$lt : ['$$accountDetails.effectiveDate', new Date()]}]}}}, []]}},0] "
            + "                              }]  }  ] }, "
            + "                          then: 'Active' }, "
            + "                          {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }},[]]}}, 0] }, "
            + "                              {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                              $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                  cond:{$gte : ['$$accountDetails.expiryDate', new Date() ]}}}, []]}},0] "
            + "                              }]  } ]  },{ "
            + "                              $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$lte : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }}, []]}}, 0] },{ "
            + "                             $or: [{$ifNull:['$accountDetails',true]},{$eq:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                             $eq : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                 cond:{$gte : ['$$accountDetails.expiryDate', new Date() ]}}}, []]}},0] "
            + "                             }]  } ] }]}, "
            + "                          then: 'InActive'},] "
            + "                   ,default: 'Closed' } }}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findAliasForGroupsByKeyword(Date date, String searchVal);

  Flux<Group> findByNameIgnoreCase(String lowerCase);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'accountServices': '$accountDetails.employerServices.accountServices'}}",
        "{$unwind: '$accountServices'}",
        "{$replaceRoot: { newRoot: '$accountServices'}}"
      })
  Flux<AccountService> findAllAccountServicesByGroupIdAndAccountDetailsId(
      Long id, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{$project: {'_id':0,'accountServices': '$accountDetails.employerServices.accountServices'}}",
        "{$unwind: '$accountServices'}",
        "{$replaceRoot: { newRoot: '$accountServices'}}",
        "{$match:{serviceType:?2}}"
      })
  Flux<AccountService> findAccountServicesByServiceType(
      Long id, Long accountDetailsId, String serviceType);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'saBank': '$accountDetails.employerServices.saBank'}}",
        "{$unwind: '$saBank'}",
        "{$replaceRoot: { newRoot: '$saBank'}}"
      })
  Flux<SABank> findAllSABankByGroupIdAndAccountDetailsId(Long id, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'benefitNotes': '$accountDetails.employerServices.benefitNotes'}}",
      })
  Mono<EmployerService> findEmployerNoteByGroupIdAndAccountDetailsId(
      Long groupId, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'vendorDetails': '$accountDetails.vendorDetails'}}",
        "{$unwind: '$vendorDetails'}",
        "{$replaceRoot: { newRoot: '$vendorDetails'}}"
      })
  Flux<VendorDetails> findAllVendorDetails(Long groupId, Long accountDetailsId);

  Flux<Group> findByIdIn(List<Long> groupIds);

  default Mono<UtilizationReport> findAndModifyUtilizationReport(
      Long groupId, Long accountDetailsId, UtilizationReport utilizationReport) {
    if (ObjectUtils.anyNotNull(groupId, accountDetailsId, utilizationReport)) {
      org.springframework.data.mongodb.core.query.Query query =
          new org.springframework.data.mongodb.core.query.Query(
              Criteria.where(GroupConstants.ID_ATTRIBUTE).is(accountDetailsId));
      Update updateFields = new Update().set(GroupConstants.UTILIZATION_REPORT, utilizationReport);
      return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
          .upsert(query, updateFields, AccountDetails.class)
          .thenReturn(utilizationReport);
    }
    return Mono.empty();
  }

  @Aggregation(
      pipeline = {
        "{$addFields: {tempId: '$_id' }}",
        "{$match: {'tempId':?1}}",
        "{$project: {'id': 1,'name': 1,'lastModifiedDate': 1,'nameType': 'Group', 'healthPlanId': {$reduce:{input: '$healthPlanIds',initialValue: '',"
            + "in:{$concat:['$$value',{$cond: {if: { $eq: [ '$$value', ''] }, then: '', else: ','}},'$$this']}}},"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'status' : { $switch: { "
            + "                               branches: [ "
            + "                                     {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                          cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                                {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                                {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                                         $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                             cond: {$and:[{$gte : ['$$accountDetails.expiryDate', new Date() ]},{$lte : ['$$accountDetails.effectiveDate', new Date()]}]}}}, []]}},0] "
            + "                                         }]  }  ] }, "
            + "                                     then: 'Active' }, "
            + "                                     {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                                         cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                                         {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                                         }},[]]}}, 0] }, "
            + "                                         {$and: [{$ne:['$accountDetails',null]},{$gt:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                                         $gt : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                             cond:{$and:[{$gte : ['$$accountDetails.expiryDate', new Date() ]}]}}}, []]}},0] "
            + "                                         }]  } ]  },{ "
            + "                                         $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                                         cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                                         {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$lte : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                                         }}, []]}}, 0] },{ "
            + "                                        $or: [{$ifNull:['$accountDetails',true]},{$eq:[{$size:{$ifNull:['$accountDetails',[]]}},0]},{ "
            + "                                        $eq : [{$size : {$ifNull:[{$filter: {input: '$accountDetails', as: 'accountDetails', "
            + "                                            cond:{$gte : ['$$accountDetails.expiryDate', new Date() ]}}}, []]}},0] "
            + "                                        }]  } ] }]}, "
            + "                                     then: 'InActive'},] "
            + "                              ,default: 'Closed' } }}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findGroupStatus(Date date, Long id);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{$project: {'_id':0,'saBank': '$accountDetails.employerServices.saBank'}}",
        "{$unwind: '$saBank'}",
        "{$replaceRoot: { newRoot: '$saBank'}}",
        "{$match:{bankName:{$regex:'^?2$',$options:'i'}}}"
      })
  Flux<SABank> findSABankByBankName(Long id, Long accountDetailsId, String bankName);

  @Query(value = "{'_id': ?0}", fields = "{'_id': 1, 'contacts': 1, 'name': 1}")
  Flux<GroupSubGroupContactDto> findContactsById(Long groupId);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "  {$match: { _id: ?0 }}",
        "  {$unwind: '$contacts'}",
        "  {$unwind: '$contacts.contactInfo'}",
        "  {$match: {'contacts.contactInfo.contactId': {'$in': ?1}}}",
        "  {$project: {'contactTypeId':'$contacts._id','_id':0,'contactId': '$contacts.contactInfo.contactId','effectiveDate': '$contacts.effectiveDate','terminationDate': '$contacts.terminationDate','groupName': '$name','contactType': '$contacts.contactType', 'groupId':'$_id'}}"
      })
  Flux<ContactTypeDto> findContactTypes(Long id, List<Long> contactIds);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?1}}",
        "{$project: {'id': 1,'alerts': {$filter:{input:'$alerts', as:'alertsLists', cond:{$or: [{$and: [{$lte: ['$$alertsLists.effectiveDate._date', new Date()]},"
            + "{$gte: ['$$alertsLists.terminationDate._date',new Date()]}]},{$eq: [{$ifNull: ['$$alertsLists.effectiveDate._date',true]},true]},"
            + "{$eq: [{$ifNull: ['$$alertsLists.terminationDate._date',true]},true]}]}}},"
            + "'contacts':1,'callCenterCode':1,'name': 1,"
            + "'accountDetails':{ $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails', "
            + "cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] },"
            + "'terminationList': { $arrayElemAt: [{$filter:{input:'$terminationList', as:'termination', cond:{$or: [{$and: [{$lte: ['$$termination.effectiveDate._date', new Date()]},"
            + "{$gte: ['$$termination.terminationDate._date',new Date()]}]}, {$and: [{$lte: ['$$termination.effectiveDate._date', new Date()]},"
            + "{$eq: [{$ifNull: ['$$termination.terminationDate._date',true]},true]}]}"
            + "]}}},0]}, "
            + " 'status' : { $switch: { "
            + "                         branches: [ "
            + "   		          {case: {$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                          cond: {$and: [{$lt: ['$$termination.effectiveDate._date', new Date()]},"
            + "		{$ne:[{$ifNull : ['$$termination.terminationDate', true ]},true]},{$lt: ['$$termination.terminationDate._date',new Date()]}]}	}},[]]}}, 0] }, then: 'Termed'},"
            + "					{case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "  						  		 cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] } , then: 'N/A'}"
            + "						{case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "						  		 cond: {$and:[{$lt : ['$$acDetails.expiryDate', new Date() ]},{$lt : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] } , then: 'InActive'}, "
            + "						{case: {$eq: [{$ifNull: ['$accountDetails',true]},true]} , then: 'NoProfile'},"
            + "                   {case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "						 cond: {$and:[{$gt : ['$$acDetails.expiryDate', new Date() ]},{$gt : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] } , then: 'Future'}]"
            + "              ,default: 'N/A' } },  "
            + "  'termedList': { $arrayElemAt: [{$filter:{input:'$terminationList', as:'termination', "
            + "			cond:{$and: [{$lt: ['$$termination.effectiveDate._date', new Date()]},"
            + "			{$ne:[{$ifNull : ['$$termination.terminationDate', true ]},true]}	,{$lt: ['$$termination.terminationDate._date',new Date()]}]}	}},0]}"
            + "}}"
      })
  Flux<GroupAccountDetailDto> findActiveAccountDetailsByGroupId(Date date, Long id);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$project: {'_id': 1,'accountDetails':{$ifNull: [{ $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails', "
            + "cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] }, {}]}}}",
        "{$replaceRoot: { newRoot: '$accountDetails'}}",
        "{$project: {'accountId': '$_id','vendorDetails': {$filter: {input: '$vendorDetails', as: 'vendor', cond: {$or : [{$eq: ['$$vendor.active',true]}, {$and:[{$gte : ['$$vendor.endDate._date', new Date() ]},{$lte : ['$$vendor.startDate._date', new Date()]}]}]}}}}}",
        "{$unwind: '$vendorDetails'}",
        "{$lookup:"
            + "{"
            + "  from: 'codes',"
            + "   let: { vednor_type: '$vendorDetails.vendorType' },"
            + "  pipeline: ["
            + "     { $match: { '_id': 'vendorType' } },"
            + "     { $project: { _id: 0, 'codevals': { "
            + "         $arrayElemAt : ["
            + "         {$filter: { input: '$values', as: 'value', "
            + "         cond: {$eq: ['$$value.code', '$$vednor_type']} }}, 0]"
            + "         } } },"
            + "     { $replaceRoot: { newRoot: '$codevals' } },"
            + "  ],"
            + "  as: 'codevalues'"
            + "}}",
        "{$project: {'accountId' :'$accountId', 'id': '$vendorDetails._id','name':'$vendorDetails.name', 'phone':'$vendorDetails.phone', 'instruction' :'$vendorDetails.instruction',  'vendorType' : {$arrayElemAt:['$codevalues.label',0]}}}",
        "{ $sort : { vendorType : 1, name : 1 } }"
      })
  Flux<ActiveVendorDetailsDTO> findAllActiveVendorDetails(Long groupId);

  @Query(
      value = " { healthPlanIds: { $elemMatch: { $eq: '?0'} } }",
      fields = "{'_id': 1,  'name': 1}")
  Flux<Group> findMatchingGroupByHealthPlanId(String healhplanId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: { path: '$addresses', preserveNullAndEmptyArrays: false }}",
        "{$replaceRoot: { newRoot: '$addresses'}}",
      })
  Mono<Address> getAddressDetailsByGroupId(Long groupId);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match:{'_id':?0}}",
        "{$unwind: '$accountDetails'}",
        "{$sort: {'accountDetails.createdDate': -1}}",
        "{$limit: 1}",
        "{$lookup:{from:'employeeServiceDelivery', localField:'accountDetails._id', foreignField:'accountId', as: 'serviceDetails'}}",
        "{$project: {'groupName':'$name','parentNamePath':1,'groupId':'$_id','address':{ $arrayElemAt: [ '$addresses', 0 ] },'serviceDeliveries':'$serviceDetails', 'employerServices':{$cond: [{$and:[{$gte : ['$accountDetails.expiryDate', new Date()]}, {$lte : ['$accountDetails.effectiveDate', new Date()]}]}, '$accountDetails.employerServices', {}]}}}",
      })
  public Mono<BankHoursDto> findBankDetailsById(Long groupId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$project: {'name':'$name','id':'$_id','address':{ $arrayElemAt: [ '$addresses', 0 ] } }}",
      })
  public Mono<GroupNameAddressDto> findNameAndAddressById(Long groupId);
}
