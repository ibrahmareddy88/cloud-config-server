package com.anthem.eap.group.util;

import com.anthem.eap.group.model.SubGroupEmployeeCountImport;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

public class SubGroupUtil {

  public static final String INVALID_GROUP_NAME = "Invalid Group Name";
  public static final String INVALID_DATE_FORMAT = "Invalid As Of Date";
  public static final String INVALID_GROUP_ID = "Invalid Group ID";
  public static final String INVALID_SUBGROUP_NAME = "Invalid Subgroup Name";
  public static final String INVALID_SUBGROUP_ID = "Invalid Subgroup ID";
  public static final String DUPLICATE_RECORD = "Duplicate Record";
  public static final String DELIMITER = ", ";
  public static final String INVALID_COUNT = "Invalid Employee Count";

  public static void validateGroupAndSubGroup(
      Group group, SubGroupEmployeeCountImport subGroupEmployeeCount, SubGroup subGroup) {

    boolean isDateFormatInvalid = false;
    boolean isCountInvalid = false;
    boolean isGroupIdInvalid = false;
    boolean isSubGroupIdInvalid = false;

    if (subGroupEmployeeCount.getGroupId() == null
        || subGroupEmployeeCount.getGroupId().isEmpty()
        || !NumberUtils.isCreatable(subGroupEmployeeCount.getGroupId())
        || !NumberUtil.isValidPositiveNumber(subGroupEmployeeCount.getGroupId())
        || Long.parseLong(subGroupEmployeeCount.getGroupId()) != group.getId()) {
      isGroupIdInvalid = true;
    }
    if (subGroupEmployeeCount.getSubGroupId() == null
        || subGroupEmployeeCount.getSubGroupId().isEmpty()
        || !NumberUtils.isCreatable(subGroupEmployeeCount.getSubGroupId())
        || !NumberUtil.isValidPositiveNumber(subGroupEmployeeCount.getSubGroupId())
        || Long.parseLong(subGroupEmployeeCount.getSubGroupId()) != subGroup.getId())
      isSubGroupIdInvalid = true;

    if (subGroupEmployeeCount.getCount() == null
        || subGroupEmployeeCount.getCount().isEmpty()
        || !NumberUtil.isValidPositiveNumber(subGroupEmployeeCount.getCount())
        || !NumberUtils.isCreatable(subGroupEmployeeCount.getCount())) {
      isCountInvalid = true;
    }
    if (subGroupEmployeeCount.getAsOfDate() == null
        || subGroupEmployeeCount.getAsOfDate().isEmpty()) {
      isDateFormatInvalid = true;
    } else {
      try {
        DateUtil.convertToZonedDateTime(subGroupEmployeeCount.getAsOfDate());
      } catch (Exception exception) {
        isDateFormatInvalid = true;
      }
    }
    buildCombinedErrorMessage(
        isGroupIdInvalid,
        isSubGroupIdInvalid,
        isCountInvalid,
        isDateFormatInvalid,
        subGroupEmployeeCount);
  }

  public static SubGroupEmployeeCountImport subGroupEmployeeCountImportTestData(
      String groupId, String subGroupId, String count, String asOfDate) {
    SubGroupEmployeeCountImport subGroupEmployeeCountImport = new SubGroupEmployeeCountImport();
    subGroupEmployeeCountImport.setGroupId(groupId);
    subGroupEmployeeCountImport.setSubGroupId(subGroupId);
    subGroupEmployeeCountImport.setCount(count);
    subGroupEmployeeCountImport.setAsOfDate(asOfDate);
    return subGroupEmployeeCountImport;
  }

  public static List<SubGroupEmployeeCountImport> verifyForDuplicateRecords(
      List<SubGroupEmployeeCountImport> imports) {
    imports.stream()
        .filter(employeeCount -> StringUtils.isAllBlank(employeeCount.getError()))
        .forEach(
            employeeCount -> {
              boolean hasDuplicate =
                  imports.stream()
                      .anyMatch(
                          comparingEmployeeCount ->
                              employeeCount != comparingEmployeeCount
                                  && employeeCount
                                      .getGroupId()
                                      .equals(comparingEmployeeCount.getGroupId())
                                  && employeeCount
                                      .getSubGroupId()
                                      .equals(comparingEmployeeCount.getSubGroupId())
                                  && employeeCount
                                      .getAsOfDate()
                                      .equals(comparingEmployeeCount.getAsOfDate())
                                  && employeeCount
                                      .getCount()
                                      .equals(comparingEmployeeCount.getCount()));

              if (hasDuplicate) {
                employeeCount.setError(DUPLICATE_RECORD);
              }
            });

    return imports;
  }

  public static List<SubGroupEmployeeCountImport> employeeCountTestData(
      String grpName,
      String grpId,
      String subGroupId,
      String subGroupName,
      String count,
      String asOfDate) {
    List<SubGroupEmployeeCountImport> employeeCountsList = new ArrayList<>();
    SubGroupEmployeeCountImport empCountList = new SubGroupEmployeeCountImport();
    empCountList.setGroupName(grpName);
    empCountList.setGroupId(grpId);
    empCountList.setCount(count);
    empCountList.setAsOfDate(asOfDate);

    empCountList.setSubGroupId(subGroupId);
    empCountList.setSubgroupName(subGroupName);
    employeeCountsList.add(empCountList);
    return employeeCountsList;
  }

  static void buildCombinedErrorMessage(
      boolean isGroupIdInvalid,
      boolean isSubGroupIdInvalid,
      boolean isCountInvalid,
      boolean isDateFormatInvalid,
      SubGroupEmployeeCountImport subGroupEmployeeCount) {
    // Build Combined Error Message

    StringBuilder invalidDataFormat = new StringBuilder();
    if (isGroupIdInvalid) invalidDataFormat.append(", " + INVALID_GROUP_ID);
    if (isSubGroupIdInvalid) invalidDataFormat.append(", " + INVALID_SUBGROUP_ID);

    if (isCountInvalid) invalidDataFormat.append(", " + INVALID_COUNT);
    if (isDateFormatInvalid) invalidDataFormat.append(", " + INVALID_DATE_FORMAT);
    if (isGroupIdInvalid || isDateFormatInvalid || isCountInvalid || isSubGroupIdInvalid) {
      subGroupEmployeeCount.setError(
          invalidDataFormat.substring(1, invalidDataFormat.length()).trim());
    }
  }
}
