package com.anthem.eap.group.dto;

import com.anthem.eap.model.AbstractPersistableEntity;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.ContactInfo;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.group.GroupSubgroupContact;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class ContactTypeResultDto extends AbstractPersistableEntity.IdLong {
  private Long contactTypeId;

  private ZonedDateTime effectiveDate;

  private ZonedDateTime terminationDate;

  private Long subGroupId;

  private Long groupId;

  private String groupName;

  private String subGroupName;

  private String email;

  private String phoneNumber;

  private String accountName;

  private String title;

  private Long brokerNumber;

  private ContactInfo contactInfo;

  private GroupSubgroupContact.ContactType contactType;

  private ContactStatus status;

  public enum ContactStatus {
    ACTIVE,
    IN_ACTIVE
  }

  private ContactTypeResultDto(GroupSubgroupContact groupSubgroupContact) {
    this.effectiveDate = groupSubgroupContact.getEffectiveDate();
    this.terminationDate = groupSubgroupContact.getTerminationDate();
    this.contactInfo = groupSubgroupContact.getContactInfo();
    this.contactType = groupSubgroupContact.getContactType();
    this.setLastModifiedDate(groupSubgroupContact.getLastModifiedDate());
    this.setCreatedDate(groupSubgroupContact.getCreatedDate());
    this.setLastModifiedBy(groupSubgroupContact.getLastModifiedBy());
    this.setCreatedBy(groupSubgroupContact.getCreatedBy());
  }

  public ContactTypeResultDto(
      GroupSubgroupContact groupSubgroupContact, GroupSubGroupContactDto groupSubgroupContactDto) {
    this(groupSubgroupContact);
    this.contactTypeId = groupSubgroupContact.getId();
    if (groupSubgroupContactDto.isSubGroup()) {
      this.groupId = groupSubgroupContactDto.getGroupId();
      this.subGroupId = groupSubgroupContactDto.getId();
      this.subGroupName = groupSubgroupContactDto.getName();
    } else {
      this.groupId = groupSubgroupContactDto.getId();
      this.groupName = groupSubgroupContactDto.getName();
    }
  }

  public static List<ContactTypeResultDto> getGroupOrSubGroupContacts(
      GroupSubGroupContactDto groupSubGroupContactDto) {
    return Optional.ofNullable(groupSubGroupContactDto.getContacts())
        .orElse(Collections.emptyList()).stream()
        .map(contact -> new ContactTypeResultDto(contact, groupSubGroupContactDto))
        .collect(Collectors.toList());
  }

  public ContactTypeResultDto populateContact(Contact contact) {
    this.setEmail(contact.getEmail());
    this.setBrokerNumber(contact.getBrokerNumber());
    this.setAccountName(contact.getAccountName());
    this.setTitle(contact.getTitle());
    this.phoneNumber =
        Optional.ofNullable(contact.getAddress())
            .map(Address::getPhone)
            .map(Phone::getNumber)
            .orElse(null);

    return this;
  }

  public ContactStatus getStatus() {
    if (Objects.nonNull(this.terminationDate) && this.terminationDate.isBefore(ZonedDateTime.now()))
      return ContactTypeResultDto.ContactStatus.IN_ACTIVE;
    else if (Objects.nonNull(this.terminationDate)
        && (this.terminationDate.isAfter(ZonedDateTime.now())
            || this.terminationDate.isEqual(ZonedDateTime.now())))
      return ContactTypeResultDto.ContactStatus.ACTIVE;
    return ContactTypeResultDto.ContactStatus.ACTIVE;
  }

  public boolean isGroup() {
    return this.subGroupId == null;
  }
}
