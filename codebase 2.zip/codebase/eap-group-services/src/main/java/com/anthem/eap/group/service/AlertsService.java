package com.anthem.eap.group.service;

import com.anthem.eap.group.alert.AlertManager;
import com.anthem.eap.group.model.AlertModel;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Tag(name = "alertsRouter")
public class AlertsService {

  @Autowired private AlertManager alertManager;

  public Mono<AlertModel> save(AlertModel alertModel) {
    return alertManager.saveAlert(alertModel, alertModel.getCategory());
  }

  public Flux<AlertModel> getAlertsByCategory(
      @Parameter(in = ParameterIn.QUERY, name = "id") Long id,
      @Parameter(in = ParameterIn.QUERY, name = "category") String category) {
    return alertManager.getAlertsByCategory(id, category);
  }

  public Flux<AlertModel> getAllGroupAlerts(
      @Parameter(in = ParameterIn.QUERY, name = "id") Long id) {
    return alertManager.getAllGroupAlerts(id);
  }
}
