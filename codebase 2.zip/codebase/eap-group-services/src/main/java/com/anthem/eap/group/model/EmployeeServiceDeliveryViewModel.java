package com.anthem.eap.group.model;

import static com.anthem.eap.group.constants.GroupConstants.ID_ATTRIBUTE;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
public class EmployeeServiceDeliveryViewModel {

  @Field(ID_ATTRIBUTE)
  private Long serviceId;

  @Field("serviceDetails.dateOfService")
  private String dateOfService;

  @Field("serviceDetails.serviceType")
  private String serviceType;

  private Long providerId;

  @Field("_provider.name.fullName")
  private String providerName;

  private LocalDate completedDate;

  private String serviceLocation;

  @Field("serviceDetails.createdBy")
  private String createdBy;

  @Field("serviceDetails.createdDate")
  private String createdDate;

  private Long groupId;

  @Field("_group.name")
  private String groupName;

  private Long subGroupId;

  @Field("_subGroup.name")
  private String subGroupName;

  @Field("lastModifiedBy")
  private String lastModifiedBy;

  @Field("lastModifiedDate")
  private ZonedDateTime lastModifiedDate;
}
