package com.anthem.eap.group.repository;

import static com.anthem.eap.group.constants.GroupConstants.ACCOUNT_DETAILS;
import static com.anthem.eap.group.constants.GroupConstants.ACCOUNT_DETAILS_MONGO_ID;
import static com.anthem.eap.group.constants.GroupConstants.GROUP_TYPE;
import static com.anthem.eap.group.constants.GroupConstants.ID_ATTRIBUTE;
import static com.anthem.eap.group.constants.GroupConstants.PATH_TO_SPECIAL_INSTRUCTIONS;

import com.anthem.eap.audit.AuditorAwareImpl;
import com.anthem.eap.config.EAPBeanResolver;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.repository.custom.AccountProfileCustomRepo;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.accountProfile.SpecialInstruction;
import com.anthem.eap.model.group.AbstractGroup;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.repository.ReactiveMongoIdSequenceRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** @author Sravanti Cherukuri(AF69838) */
public class AccountProfileRepositoryImpl implements AccountProfileCustomRepo {

  private final ReactiveMongoIdSequenceRepository idSequenceRepository;
  private final ObjectMapper objectMapper;
  private final ReactiveMongoTemplate reactiveMongoTemplate;
  private final GroupRepository groupRepository;
  private final SubGroupRepository subGroupRepository;

  public AccountProfileRepositoryImpl(
      ReactiveMongoIdSequenceRepository idSequenceRepository,
      ObjectMapper objectMapper,
      ReactiveMongoTemplate reactiveMongoTemplate,
      GroupRepository groupRepository,
      SubGroupRepository subGroupRepository) {
    this.idSequenceRepository = idSequenceRepository;
    this.objectMapper = objectMapper;
    this.reactiveMongoTemplate = reactiveMongoTemplate;
    this.groupRepository = groupRepository;
    this.subGroupRepository = subGroupRepository;
  }

  @Override
  public Mono<AccountDetails> findAndModifyAccountDetails(
      Long id, AccountDetails accountDetails, String type) {
    Query query = new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id));
    if (ObjectUtils.anyNotNull(accountDetails.getId())) {
      query.addCriteria(new Criteria("accountDetails._id").is(accountDetails.getId()));
    }
    boolean isNewAccountDetails = accountDetails.getId() == null;
    return populateAuditDetails(accountDetails)
        .flatMap(this::populateMongoId)
        .flatMap(accDetails -> updateMono(accDetails, isNewAccountDetails))
        .flatMap(update -> upsert(update, query, type, accountDetails.getId()));
  }

  Mono<Update> updateMono(AccountDetails accountDetails, boolean newAccountDetail) {
    if (!newAccountDetail) {
      Map<String, Object> accountDetailsProperties =
          objectMapper.convertValue(accountDetails, Map.class);
      accountDetailsProperties.values().removeIf(Objects::isNull);
      Update update = new Update();
      accountDetailsProperties.forEach(
          (attrKey, attrValue) -> {
            if (StringUtils.equals(attrKey, GroupConstants.CREATED_DATE)) {
              SimpleDateFormat sdf = new SimpleDateFormat(GroupConstants.DATE_PATTERN);
              sdf.setTimeZone(TimeZone.getTimeZone(GroupConstants.ZONE_UTC));
              try {

                Date date = sdf.parse(attrValue.toString());
                update.set(GroupConstants.ACCOUNT_DETAILS_POSITIONAL + attrKey + "._date", date);

              } catch (ParseException e) {
                e.printStackTrace();
              }

            } else if (StringUtils.equals(attrKey, GroupConstants.LAST_MODIFIED_DATE))
              update.set(
                  GroupConstants.ACCOUNT_DETAILS_POSITIONAL + attrKey,
                  ZonedDateTime.now().withZoneSameInstant(ZoneId.of(GroupConstants.ZONE_UTC)));
            else if (StringUtils.equals(attrKey, "origEffDate")
                || StringUtils.equals(attrKey, "effectiveDate")
                || StringUtils.equals(attrKey, "expiryDate")
                || StringUtils.equals(attrKey, "renewalDate"))
              update.set(
                  GroupConstants.ACCOUNT_DETAILS_POSITIONAL + attrKey,
                  LocalDate.parse(attrValue.toString()));
            else update.set(GroupConstants.ACCOUNT_DETAILS_POSITIONAL + attrKey, attrValue);
          });
      return Mono.just(update);
    }
    return Mono.just(new Update().addToSet(GroupConstants.ACCOUNT_DETAILS, accountDetails));
  }

  Mono<AccountDetails> upsert(Update update, Query query, String type, Long accDetailsId) {
    Class<? extends AbstractGroup> clazz =
        GroupConstants.GROUP_TYPE.equals(type) ? Group.class : SubGroup.class;
    return upsertAccountDetailsInGroupOrSubGroup(update, query, accDetailsId, clazz);
  }

  public <T extends AbstractGroup> Mono<AccountDetails> upsertAccountDetailsInGroupOrSubGroup(
      Update update, Query query, Long accDetailsId, Class<T> t) {
    return this.reactiveMongoTemplate
        .findAndModify(query, update, new FindAndModifyOptions().upsert(true).returnNew(true), t)
        .map(AbstractGroup::getAccountDetails)
        .flatMapMany(Flux::fromIterable)
        .filter(a -> accDetailsId.equals(a.getId()))
        .next();
  }

  Mono<AccountDetails> populateMongoId(AccountDetails accountDetails) {
    if (ObjectUtils.anyNotNull(accountDetails.getId())) {
      return Mono.just(accountDetails);
    }
    return this.idSequenceRepository
        .getNextSequenceId(GroupConstants.ACCOUNT_DETAILS)
        .map(
            id -> {
              accountDetails.setId(id);
              return accountDetails;
            });
  }

  Mono<AccountDetails> populateAuditDetails(AccountDetails accountDetails) {

    Mono<String> currentAuditor =
        EAPBeanResolver.getBean(AuditorAwareImpl.class).getCurrentAuditor();

    if (accountDetails.getId() == null) {
      return currentAuditor.map(
          ca -> {
            accountDetails.setCreatedBy(ca);
            accountDetails.setLastModifiedBy(ca);
            accountDetails.setCreatedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of(GroupConstants.ZONE_UTC)));
            accountDetails.setLastModifiedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of(GroupConstants.ZONE_UTC)));
            return accountDetails;
          });
    }
    return currentAuditor.map(
        ca -> {
          accountDetails.setLastModifiedBy(ca);
          accountDetails.setLastModifiedDate(
              ZonedDateTime.now().withZoneSameInstant(ZoneId.of(GroupConstants.ZONE_UTC)));
          return accountDetails;
        });
  }

  @Override
  public Mono<AccountService> findAndModifyAccountService(
      Long id, Long accountProfileId, String type, AccountService accountService) {
    Query query = new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id));
    query.addCriteria(new Criteria("accountDetails._id").is(accountProfileId));
    boolean isNewAccountDetails = accountService.getId() == null;
    return populateAuditDetails(accountService)
        .flatMap(this::populateMongoId)
        .flatMap(accService -> updateMono(accService, isNewAccountDetails, accountProfileId))
        .flatMap(update -> upsert(update, query, type, accountProfileId))
        .then(Mono.just(accountService));
  }

  Mono<Update> updateMono(
      AccountService accountService, boolean isNewAccountDetails, Long accountProfileId) {
    if (!isNewAccountDetails) {
      return Mono.just(
          new Update()
              .set(GroupConstants.UPDATE_ACCOUNT_SERVICE, accountService)
              .filterArray(Criteria.where("accDetail._id").in(Arrays.asList(accountProfileId)))
              .filterArray(
                  Criteria.where("accService._id").in(Arrays.asList(accountService.getId()))));
    }
    return Mono.just(new Update().addToSet(GroupConstants.INSERT_ACCOUNT_SERVICE, accountService));
  }

  Mono<AccountService> populateMongoId(AccountService accountService) {
    if (ObjectUtils.anyNotNull(accountService.getId())) {
      return Mono.just(accountService);
    }
    return this.idSequenceRepository
        .getNextSequenceId(GroupConstants.ACCOUNT_SERVICE)
        .map(
            id -> {
              accountService.setId(id);
              return accountService;
            });
  }

  Mono<AccountService> populateAuditDetails(AccountService accountService) {
    Mono<String> currentAuditor =
        EAPBeanResolver.getBean(AuditorAwareImpl.class).getCurrentAuditor();
    if (accountService.getId() == null) {
      return currentAuditor.map(
          ca -> {
            accountService.setCreatedBy(ca);
            accountService.setLastModifiedBy(ca);
            accountService.setCreatedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
            accountService.setLastModifiedDate(
                ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
            return accountService;
          });
    }
    return currentAuditor.map(
        ca -> {
          accountService.setLastModifiedBy(ca);
          accountService.setLastModifiedDate(
              ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
          return accountService;
        });
  }

  @Override
  public Mono<EmployerService> findAndModifyEmployerServiceNote(
      Long id, Long accountProfileId, String type, EmployerService employerService) {
    if (ObjectUtils.anyNotNull(id, accountProfileId, employerService.getBenefitNotes(), type)) {
      Query query =
          new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id))
              .addCriteria(Criteria.where("accountDetails._id").is(accountProfileId));
      Update updateFields =
          new Update()
              .set(
                  GroupConstants.INSERT_OR_UPDATE_ACCOUNT_SERVICE_NOTE,
                  employerService.getBenefitNotes());
      return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
          .upsert(
              query,
              updateFields,
              type.equals(GroupConstants.GROUP_TYPE) ? Group.class : SubGroup.class)
          .thenReturn(employerService);
    }
    return Mono.empty();
  }

  @Override
  public Mono<SABank> findAndModifySABankDetails(
      Long id, Long accountProfileId, String type, SABank saBank) {
    Query query = new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id));
    query.addCriteria(new Criteria("accountDetails._id").is(accountProfileId));
    boolean isNewAccountDetails = saBank.getId() == null;
    return populateSABankAuditDetails(saBank)
        .flatMap(this::populateSABankMongoId)
        .flatMap(bank -> updateSABankMono(bank, isNewAccountDetails, accountProfileId))
        .flatMap(update -> upsert(update, query, type, accountProfileId))
        .then(Mono.just(saBank));
  }

  /**
   * @param saBank
   * @return
   */
  private Mono<SABank> populateSABankAuditDetails(SABank saBank) {
    Mono<String> currentAuditor =
        EAPBeanResolver.getBean(AuditorAwareImpl.class).getCurrentAuditor();
    if (saBank.getId() == null) {
      return currentAuditor.map(
          ca -> {
            saBank.setCreatedBy(ca);
            saBank.setLastModifiedBy(ca);
            saBank.setCreatedDate(ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
            saBank.setLastModifiedDate(ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
            return saBank;
          });
    }
    return currentAuditor.map(
        ca -> {
          saBank.setLastModifiedBy(ca);
          saBank.setLastModifiedDate(ZonedDateTime.now().withZoneSameInstant(ZoneId.of("UTC")));
          return saBank;
        });
  }

  /**
   * @param saBank
   * @return
   */
  private Mono<SABank> populateSABankMongoId(SABank saBank) {
    if (ObjectUtils.anyNotNull(saBank.getId())) {
      return Mono.just(saBank);
    }
    return this.idSequenceRepository
        .getNextSequenceId(GroupConstants.SABANK_SERVICE)
        .map(
            id -> {
              saBank.setId(id);
              return saBank;
            });
  }

  /**
   * @param saBank
   * @param isNewAccountDetails
   * @param accountProfileId
   * @return
   */
  private Mono<Update> updateSABankMono(
      SABank saBank, boolean isNewAccountDetails, Long accountProfileId) {
    if (!isNewAccountDetails) {
      return Mono.just(
          new Update()
              .set(GroupConstants.UPDATE_SABANK_SERVICE, saBank)
              .filterArray(Criteria.where("accDetail._id").in(Arrays.asList(accountProfileId)))
              .filterArray(Criteria.where("bank._id").in(Arrays.asList(saBank.getId()))));
    }
    return Mono.just(new Update().addToSet(GroupConstants.INSERT_SABANK_SERVICE, saBank));
  }

  /**
   * @param id
   * @param accountProfileId
   * @param type
   * @param specialInstructions
   * @return
   */
  public Flux<SpecialInstruction> updateSpecialInstructions(
      Long id, Long accountProfileId, String type, List<SpecialInstruction> specialInstructions) {
    if (ObjectUtils.allNotNull(id, accountProfileId, specialInstructions, type)) {
      Query query = getAccountDetailsQuery(id, accountProfileId);
      FindAndModifyOptions options = new FindAndModifyOptions().upsert(true).returnNew(true);
      return getSpecialInstructionsUpdateQuery(specialInstructions)
          .flatMap(
              update ->
                  reactiveMongoTemplate.findAndModify(query, update, options, getClassType(type)))
          .mapNotNull(AbstractGroup::getAccountDetails)
          .flatMapMany(Flux::fromIterable)
          .filter(account -> Objects.equals(account.getId(), accountProfileId))
          .mapNotNull(AccountDetails::getSpecialInstructions)
          .flatMap(Flux::fromIterable);
    }
    return Flux.empty();
  }

  private Query getAccountDetailsQuery(Long id, Long accountProfileId) {
    return new Query(Criteria.where(ID_ATTRIBUTE).is(id))
        .addCriteria(Criteria.where(ACCOUNT_DETAILS_MONGO_ID).is(accountProfileId));
  }

  private Class<? extends AbstractGroup> getClassType(String type) {
    return type.equals(GROUP_TYPE) ? Group.class : SubGroup.class;
  }

  private Mono<Update> getSpecialInstructionsUpdateQuery(
      List<SpecialInstruction> specialInstructions) {
    return prepareAuditUpdateQuery(ACCOUNT_DETAILS)
        .map(u -> u.set(PATH_TO_SPECIAL_INSTRUCTIONS, specialInstructions));
  }

  @Override
  public Mono<AccountDetails> findAndRenewAccountDetails(
      Long id, AccountDetails accountDetails, String type) {
    accountDetails.setId(null);

    // when renew date is not null.
    if (accountDetails.getRenewalDate() != null) {
      accountDetails.setEffectiveDate(accountDetails.getRenewalDate());
    } else {
      // when renew date is null
      accountDetails.setEffectiveDate(accountDetails.getExpiryDate().plusDays(1));
    }
    accountDetails.setExpiryDate(accountDetails.getEffectiveDate().minusDays(1).plusYears(1));
    accountDetails.setRenewalDate(accountDetails.getEffectiveDate().plusYears(1));

    return findAndModifyAccountDetails(id, accountDetails, type);
  }

  @Override
  public Mono<AccountDetails> findAccountDetailsByID(Long id, Long accountId, String type) {

    Optional<AccountDetails> selectedAccountList = null;

    if (type.equals(GroupConstants.GROUP_TYPE)) {
      Group group = this.groupRepository.findById(id).share().block();
      selectedAccountList =
          group.getAccountDetails().stream()
              .filter(account -> account.getId().equals(accountId))
              .findFirst();
    } else {
      SubGroup subGroup = this.subGroupRepository.findById(id).share().block();
      selectedAccountList =
          subGroup.getAccountDetails().stream()
              .filter(account -> account.getId().equals(accountId))
              .findFirst();
    }

    if (selectedAccountList.isPresent() && ObjectUtils.isNotEmpty(selectedAccountList.get())) {
      return findAndRenewAccountDetails(id, selectedAccountList.get(), type);
    }
    return Mono.empty();
  }
}
