package com.anthem.eap.group.handler;

import com.anthem.eap.group.model.AlertModel;
import com.anthem.eap.group.service.AlertsService;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
public class AlertsHandler {

  @Autowired AlertsService alertService;

  public Mono<ServerResponse> saveAlert(ServerRequest request) {
    Mono<AlertModel> responseMono =
        request.bodyToMono(AlertModel.class).flatMap(alertService::save);
    return responseMono.flatMap(
        alert ->
            ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(alert)));
  }

  public Mono<ServerResponse> getAlertsByCategory(ServerRequest request) {
    Optional<String> idOpt = request.queryParam("id");
    Optional<String> categoryOpt = request.queryParam("category");
    Long id = null;
    String category = "";
    if (idOpt.isPresent()) {
      id = Long.valueOf(idOpt.get());
    }
    if (categoryOpt.isPresent()) {
      category = String.valueOf(categoryOpt.get());
    }
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(alertService.getAlertsByCategory(id, category), AlertModel.class);
  }

  public Mono<ServerResponse> getAllGroupAlerts(ServerRequest request) {
    Optional<String> idOpt = request.queryParam("id");
    Long id = null;
    if (idOpt.isPresent()) {
      id = Long.valueOf(idOpt.get());
    }
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(alertService.getAllGroupAlerts(id), AlertModel.class);
  }
}
