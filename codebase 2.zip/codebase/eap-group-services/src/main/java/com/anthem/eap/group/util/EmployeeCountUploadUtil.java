package com.anthem.eap.group.util;

import com.anthem.eap.group.model.GroupEmployeeCountImport;
import com.anthem.eap.group.model.SubGroupEmployeeCountImport;
import com.anthem.eap.model.group.AbstractGroup;
import com.anthem.eap.model.group.EmployeeCount;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.CollectionUtils;

@Log4j2
public class EmployeeCountUploadUtil {

  static final String INVALID_DATA_TEMPLATE = "Invalid data template";
  public static final String INVALID_GROUP_NAME = "Invalid group name";
  public static final String INVALID_DATE_FORMAT = "Invalid as of date";
  public static final String INVALID_GROUP_ID = "Invalid EAP group id";
  public static final String INVALID_SUBGROUP_NAME = "Invalid sub group name";
  public static final String INVALID_SUBGROUP_ID = "Invalid sub group id";
  public static final String DUPLICATE_RECORD = "Duplicate Record";
  public static final String INVALID_COUNT = "Invalid count";
  public static final String DELIMITER = ",";
  static final String INVALID_EMPLOYEE_COUNT_FORMAT = "Invalid employee count";

  public static <T extends AbstractGroup> T getGroupOrSubGroup(
      Map<Long, T> map, T groupOrSubGroupObj) {
    T existing = map.get(groupOrSubGroupObj.getId());
    return Objects.nonNull(existing) ? existing : groupOrSubGroupObj;
  }

  public static EmployeeCount getEmployeeCountFromImportObject(
      GroupEmployeeCountImport importObject, SubGroupEmployeeCountImport importsubGroupObject) {
    EmployeeCount employeeCount = new EmployeeCount();
    if (null != importObject.getCount()
        && NumberUtil.isValidPositiveNumberWithComma(importObject.getCount()))
      employeeCount.setCount(importObject.getCount().toString());
    if (importObject.getAsOfDate() != null
        && DateUtil.convertDateToZonedDateTime(importObject.getAsOfDate()) != null) {
      if (importsubGroupObject == null)
        employeeCount.setAsOfDate(DateUtil.convertDateToZonedDateTime(importObject.getAsOfDate()));
      else employeeCount.setAsOfDate(DateUtil.convertToZonedDateTime(importObject.getAsOfDate()));
    }
    return employeeCount;
  }

  public static void validateGroupAndSubGroup(
      GroupEmployeeCountImport employeeCount,
      Group group,
      SubGroupEmployeeCountImport subGroupEmployeeCount,
      SubGroup subGroup) {
    boolean isDateFormatInvalid = false,
        isCountInvalid = false,
        isGroupIdInvalid = false,
        isGroupNameInvalid = false;
    String groupId = employeeCount.getGroupId();
    String empCount = employeeCount.getCount();
    if (ObjectUtils.allNull(subGroupEmployeeCount, subGroup)) {
      if (StringUtils.isBlank(groupId)
          || Long.parseLong(employeeCount.getGroupId()) != group.getId()
          || !NumberUtils.isCreatable(groupId)
          || !NumberUtil.isValidPositiveNumber(groupId)) isGroupIdInvalid = true;
      if (StringUtils.isBlank(employeeCount.getGroupName())
          || !employeeCount.getGroupName().equalsIgnoreCase(group.getName()))
        isGroupNameInvalid = true;
      if (StringUtils.isBlank(employeeCount.getAsOfDate())
          || DateUtil.convertDateToZonedDateTime(employeeCount.getAsOfDate()) == null)
        isDateFormatInvalid = true;
      if ((Objects.nonNull(empCount) && !NumberUtil.isValidPositiveNumberWithComma(empCount))
          || Objects.isNull(empCount)
          || empCount.equals("0")
          || StringUtils.isBlank(empCount)) isCountInvalid = true;
      // Build Combined Error Message
      StringBuilder invalidDataFormat = new StringBuilder();
      if (isGroupNameInvalid) invalidDataFormat.append(", " + INVALID_GROUP_NAME);
      if (isGroupIdInvalid) invalidDataFormat.append(", " + INVALID_GROUP_ID);
      if (isDateFormatInvalid) invalidDataFormat.append(", " + INVALID_DATE_FORMAT);
      if (isCountInvalid) invalidDataFormat.append(", " + INVALID_EMPLOYEE_COUNT_FORMAT);
      if (isGroupNameInvalid || isGroupIdInvalid || isDateFormatInvalid || isCountInvalid) {
        employeeCount.setError(invalidDataFormat.substring(1, invalidDataFormat.length()).trim());
      }
    }
  }

  public static List<EmployeeCount> addUpdateEmployeeCount(
      List<EmployeeCount> existingEmployeeCounts,
      GroupEmployeeCountImport groupEmpCount,
      SubGroupEmployeeCountImport subgroupEmpCount) {
    if (CollectionUtils.isEmpty(existingEmployeeCounts)) {
      existingEmployeeCounts = new ArrayList<>();
      if (subgroupEmpCount == null)
        existingEmployeeCounts.add(
            EmployeeCountUploadUtil.getEmployeeCountFromImportObject(groupEmpCount, null));
      else
        existingEmployeeCounts.add(
            EmployeeCountUploadUtil.getEmployeeCountFromImportObject(null, subgroupEmpCount));
    } else {
      EmployeeCount newEmployeeCount;
      if (subgroupEmpCount == null)
        newEmployeeCount =
            EmployeeCountUploadUtil.getEmployeeCountFromImportObject(groupEmpCount, null);
      else
        newEmployeeCount =
            EmployeeCountUploadUtil.getEmployeeCountFromImportObject(null, subgroupEmpCount);

      Optional<EmployeeCount> existingEmployeeCountOptional =
          getExistingEmployeeCountObj(existingEmployeeCounts, newEmployeeCount);
      if (existingEmployeeCountOptional.isPresent()) {

        existingEmployeeCountOptional.get().setCount(newEmployeeCount.getCount());
      } else {
        Optional<EmployeeCount> duplicateEmployeeCount =
            existingEmployeeCounts.stream()
                .filter(
                    existingEC ->
                        existingEC.getCount().equals(newEmployeeCount.getCount())
                            && existingEC.getAsOfDate().equals(newEmployeeCount.getAsOfDate()))
                .findAny();

        if (!duplicateEmployeeCount.isPresent()) {
          existingEmployeeCounts.add(newEmployeeCount);
        }
      }
    }
    return existingEmployeeCounts;
  }

  private static Optional<EmployeeCount> getExistingEmployeeCountObj(
      List<EmployeeCount> existingEmployeeCounts, EmployeeCount newEmployeeCount) {
    return existingEmployeeCounts.stream()
        .filter(
            existingEC ->
                !existingEC.getCount().equals(newEmployeeCount.getCount())
                    && existingEC.getAsOfDate().equals(newEmployeeCount.getAsOfDate()))
        .findAny();
  }
}
