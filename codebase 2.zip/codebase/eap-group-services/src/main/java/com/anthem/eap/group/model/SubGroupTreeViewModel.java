package com.anthem.eap.group.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;
import org.springframework.data.annotation.Transient;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubGroupTreeViewModel {

  private String subGroupName;

  private Long subGroupId;

  private String parentIdPath;

  private String parentNamePath;

  private Long hierarchyLevel;

  @JsonIgnore @Transient private List<Long> parentIdList;

  @JsonIgnore @Transient private List<String> parentNameList;

  private List<SubGroupTreeViewModel> subGroupList;

  // Properties for Move Subgroup
  private Long groupId;
  private Long parentSubGroupId;
}
