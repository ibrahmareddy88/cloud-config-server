package com.anthem.eap.group.repository;

import com.anthem.eap.model.group.HealthPlan;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface HealthPlanRepository
    extends ReactiveMongoRepository<HealthPlan, Long>, CustomHealthPlanRepository {

  Flux<HealthPlan> findAllBySourceSystemOrderByHealthPlanNameAsc(String sourceSystem);
}
