package com.anthem.eap.group.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;
import lombok.extern.log4j.Log4j2;

/** @author AH33689 ANIL KUMAR */
@Log4j2
public class DateUtil {

  public static final String DATE_FORMAT_REGEX =
      "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";

  public static final String ZONED_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";
  public static final String DATE_FORMAT_TIME = "yyyy:MM:dd:HH:mm:ss";

  public static final String DATE_FORMAT = "MM/d/yyyy";

  public static final ZoneId ZONE_ID = ZoneId.systemDefault();

  public static final DateFormat DATE_FORMATER = new SimpleDateFormat(DATE_FORMAT_TIME);
  public static final DateTimeFormatter DATE_TIME_FORMATTER =
      DateTimeFormatter.ofPattern(ZONED_DATE_FORMAT);

  public static boolean isValidDateFormat(String date) {
    return Pattern.matches(DATE_FORMAT_REGEX, date);
  }

  public static ZonedDateTime convertToZonedDateTime(String date) {
    return ZonedDateTime.parse(date, DATE_TIME_FORMATTER.withZone(ZoneId.systemDefault()));
  }

  public static ZonedDateTime convertDateToZonedDateTime(String date) {
    ZonedDateTime asOfDate = null;
    try {
      // converting String to LocalDate as input from excel format
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/d/yyyy");
      LocalDate localDate = LocalDate.parse(date, formatter);
      // convert LocalDate to ZonedDateTime to save in ZDT format
      asOfDate = localDate.atStartOfDay(ZoneId.systemDefault());
    } catch (DateTimeParseException e) {
      log.info("Invalid Date Format : " + e.getMessage());
      asOfDate = null; // setting null for invalid date validation
    }
    return asOfDate;
  }
}
