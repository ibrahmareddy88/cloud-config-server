package com.anthem.eap.group.alert;

import com.anthem.eap.group.model.AlertModel;
import com.anthem.eap.group.model.AlertModel.Category;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.model.group.Alert;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class AlertManager {

  @Autowired private ReactiveMongoTemplate reactiveMongoTemplate;

  @Autowired private SubGroupRepository subgroupRepo;

  @Autowired private GroupRepository groupRepo;

  public Mono<AlertModel> saveAlert(AlertModel alertModel, Category type) {
    Alert alert = alertVOMapper(alertModel);
    if (type.equals(Category.SUBGROUP)) {
      return this.saveSubGroupAlert(alert, alertModel.getSubGroupId())
          .flatMap(a -> Mono.just(this.alertModelMapper(a, type, alertModel.getSubGroupId())));
    } else if (type.equals(Category.GROUP)) {
      return this.saveGroupAlert(alert, alertModel.getGroupId())
          .flatMap(a -> Mono.just(this.alertModelMapper(a, type, alertModel.getGroupId())));
    }
    return Mono.just(alertModel);
  }

  public Flux<AlertModel> getAlertsByCategory(Long id, String category) {
    if (category.equals(Category.GROUP.getValue().toUpperCase())) {
      return this.groupRepo
          .findById(id)
          .map(
              a ->
                  Optional.ofNullable(a.getAlerts()).orElseGet(Collections::emptyList).stream()
                      .map(b -> this.alertModelMapper(b, Category.GROUP, id))
                      .filter(Objects::nonNull)
                      .filter(this::isActive)
                      .collect(Collectors.toList()))
          .flatMapMany(Flux::fromIterable);
    } else if (category.equals(Category.SUBGROUP.getValue().toUpperCase())) {
      return this.subgroupRepo
          .findById(id)
          .map(
              a ->
                  Optional.ofNullable(a.getAlertsLists()).orElseGet(Collections::emptyList).stream()
                      .map(b -> this.alertModelMapper(b, Category.SUBGROUP, id))
                      .filter(Objects::nonNull)
                      .filter(this::isActive)
                      .collect(Collectors.toList()))
          .flatMapMany(Flux::fromIterable);
    }
    return Flux.empty();
  }

  public Mono<Alert> saveSubGroupAlert(Alert alert, Long subgroupId) {
    if (Objects.nonNull(alert.getId())) {
      return updateSubGroupAlert(subgroupId, alert)
          .flatMap(updateSubGroup -> subgroupRepo.save(updateSubGroup).map(a -> alert));
    } else if (Objects.isNull(alert.getId())) {
      return subgroupRepo
          .findById(subgroupId)
          .flatMap(
              subgroup -> {
                List<Alert> alerts = addSubGroupAlert(alert, subgroup);
                subgroup.setLastModifiedBy(alert.getCreateOrEditBy());
                subgroup.setLastModifiedDate(ZonedDateTime.now());
                subgroup.setAlertsLists(alerts);
                return subgroupRepo.save(subgroup).map(a -> alert);
              });
    }
    return Mono.empty();
  }

  private List<Alert> addSubGroupAlert(Alert alert, SubGroup subgroup) {
    List<Alert> alerts = null;
    if (CollectionUtils.isNotEmpty(subgroup.getAlertsLists())) {
      alerts = subgroup.getAlertsLists();
    } else {
      alerts = new ArrayList<>();
    }
    alert.setId(Long.valueOf(alerts.size()));
    alert.setCreatedBy(alert.getCreateOrEditBy());
    alert.setCreatedDate(ZonedDateTime.now());
    alert.setLastModifiedBy(alert.getCreateOrEditBy());
    alert.setLastModifiedDate(ZonedDateTime.now());
    alerts.add(alert);
    return alerts;
  }

  private List<Alert> addGroupAlert(Alert alert, Group group) {
    List<Alert> alerts = null;
    if (CollectionUtils.isNotEmpty(group.getAlerts())) {
      alerts = group.getAlerts();
    } else {
      alerts = new ArrayList<>();
    }
    alert.setId(Long.valueOf(alerts.size()));
    alert.setCreatedBy(alert.getCreateOrEditBy());
    alert.setCreatedDate(ZonedDateTime.now());
    alert.setLastModifiedBy(alert.getCreateOrEditBy());
    alert.setLastModifiedDate(ZonedDateTime.now());
    alerts.add(alert);
    return alerts;
  }

  public Mono<Alert> saveGroupAlert(Alert alert, Long groupId) {

    if (Objects.nonNull(alert.getId())) {
      return updateGroupAlert(groupId, alert)
          .flatMap(updateGroup -> groupRepo.save(updateGroup).map(a -> alert));
    } else if (Objects.isNull(alert.getId())) {
      return groupRepo
          .findById(groupId)
          .flatMap(
              group -> {
                List<Alert> alerts = addGroupAlert(alert, group);
                group.setLastModifiedBy(alert.getCreateOrEditBy());
                group.setLastModifiedDate(ZonedDateTime.now());
                group.setAlerts(alerts);
                return groupRepo.save(group).map(a -> alert);
              });
    }
    return Mono.empty();
  }

  private Mono<Group> updateGroupAlert(Long groupId, Alert alert) {
    Query groupQuery =
        new Query(
            new Criteria()
                .andOperator(
                    Criteria.where("_id").is(groupId),
                    Criteria.where("alerts").elemMatch(Criteria.where("_id").is(alert.getId()))));
    FindAndModifyOptions options = new FindAndModifyOptions();
    options.returnNew(true);
    alert.setLastModifiedBy(alert.getCreateOrEditBy());
    alert.setLastModifiedDate(ZonedDateTime.now());
    final Update alertUpdate = new Update().set("alerts.$", alert);
    return reactiveMongoTemplate
        .findAndModify(groupQuery, alertUpdate, options, Group.class)
        .map(
            group -> {
              group.setLastModifiedBy(alert.getCreateOrEditBy());
              group.setLastModifiedDate(ZonedDateTime.now());
              return group;
            });
  }

  private Mono<SubGroup> updateSubGroupAlert(Long subgroupId, Alert alert) {
    Query groupQuery =
        new Query(
            new Criteria()
                .andOperator(
                    Criteria.where("_id").is(subgroupId),
                    Criteria.where("alertsLists")
                        .elemMatch(Criteria.where("_id").is(alert.getId()))));
    FindAndModifyOptions options = new FindAndModifyOptions();
    options.returnNew(true);
    alert.setLastModifiedBy(alert.getCreateOrEditBy());
    alert.setLastModifiedDate(ZonedDateTime.now());
    final Update alertUpdate = new Update().set("alertsLists.$", alert);
    return reactiveMongoTemplate
        .findAndModify(groupQuery, alertUpdate, options, SubGroup.class)
        .map(
            subGroup -> {
              subGroup.setLastModifiedBy(alert.getCreateOrEditBy());
              subGroup.setLastModifiedDate(ZonedDateTime.now());
              return subGroup;
            });
  }

  public Flux<AlertModel> getAllGroupAlerts(Long groupId) {
    MatchOperation matchStage = Aggregation.match(new Criteria("_id").is(groupId));
    LookupOperation lookupStage = Aggregation.lookup("subGroup", "_id", "groupId", "subGroupList");
    ProjectionOperation projectStage = Aggregation.project(GroupAlertsModel.class);
    Aggregation aggregation = Aggregation.newAggregation(matchStage, lookupStage, projectStage);
    return reactiveMongoTemplate
        .aggregate(aggregation, "group", GroupAlertsModel.class)
        .map(
            a -> {
              List<AlertModel> alerts = new ArrayList<>();
              List<AlertModel> groupAlerts =
                  extractAlertModels(a.getAlerts(), Category.GROUP, a.getId());
              alerts.addAll(groupAlerts);
              List<AlertModel> subGroupsAlerts = extractSubgroupAlerts(a);
              alerts.addAll(subGroupsAlerts);
              return sortAlerts(alerts);
            })
        .flatMapIterable(a -> a);
  }

  private List<AlertModel> sortAlerts(List<AlertModel> alerts) {
    if (CollectionUtils.isNotEmpty(alerts)) {
      List<AlertModel> sortedAlerts = new ArrayList<AlertModel>();
      List<AlertModel> infiniteAlerts =
          alerts.stream()
              .filter(a -> ObjectUtils.allNull(a.getEffectiveDate(), a.getTerminationDate()))
              .collect(Collectors.toList());
      List<AlertModel> nonInfinite =
          alerts.stream()
              .filter(a -> ObjectUtils.allNotNull(a.getEffectiveDate(), a.getTerminationDate()))
              .collect(Collectors.toList());
      List<AlertModel> termedAlerts =
          Optional.ofNullable(nonInfinite).orElseGet(Collections::emptyList).stream()
              .filter(this::isTermed)
              .sorted(Comparator.comparing(AlertModel::getTerminationDate).reversed())
              .collect(Collectors.toList());
      List<AlertModel> activeAlerts =
          Optional.ofNullable(nonInfinite).orElseGet(Collections::emptyList).stream()
              .filter(this::isActive)
              .sorted(Comparator.comparing(AlertModel::getEffectiveDate))
              .collect(Collectors.toList());
      List<AlertModel> futureActiveAlerts =
          Optional.ofNullable(nonInfinite).orElseGet(Collections::emptyList).stream()
              .filter(a -> a.getEffectiveDate().isAfter(ZonedDateTime.now()))
              .sorted(Comparator.comparing(AlertModel::getEffectiveDate))
              .collect(Collectors.toList());
      sortedAlerts.addAll(infiniteAlerts);
      sortedAlerts.addAll(activeAlerts);
      sortedAlerts.addAll(futureActiveAlerts);
      sortedAlerts.addAll(termedAlerts);
      return sortedAlerts;
    }
    return alerts;
  }

  private List<AlertModel> extractSubgroupAlerts(GroupAlertsModel a) {
    return Optional.ofNullable(a.getSubGroupList()).orElseGet(Collections::emptyList).stream()
        .map(b -> this.extractAlertModels(b.getAlertsLists(), Category.SUBGROUP, b.getId()))
        .flatMap(List::stream)
        .collect(Collectors.toList());
  }

  private List<AlertModel> extractAlertModels(List<Alert> alerts, Category category, Long id) {
    return Optional.ofNullable(alerts).orElseGet(Collections::emptyList).stream()
        .map(a -> this.alertModelMapper(a, category, id))
        .collect(Collectors.toList());
  }

  private Alert alertVOMapper(AlertModel viewModel) {
    Alert alert = new Alert();
    BeanUtils.copyProperties(viewModel, alert);
    return alert;
  }

  private AlertModel alertModelMapper(Alert alert, Category category, Long categoryId) {
    AlertModel viewModel = new AlertModel();
    BeanUtils.copyProperties(alert, viewModel);
    if (category.equals(Category.GROUP)) {
      viewModel.setCategory(Category.GROUP);
      viewModel.setGroupId(categoryId);
    } else {
      viewModel.setCategory(Category.SUBGROUP);
      viewModel.setSubGroupId(categoryId);
    }
    return viewModel;
  }

  private boolean isTermed(AlertModel alert) {
    if (Objects.nonNull(alert.getTerminationDate())) {
      return alert.getTerminationDate().toLocalDate().isBefore(LocalDate.now());
    }
    return false;
  }

  private boolean isActive(AlertModel alert) {
    ZonedDateTime today = ZonedDateTime.now();
    if (Objects.nonNull(alert.getEffectiveDate()) && Objects.nonNull(alert.getTerminationDate())) {
      return (alert.getEffectiveDate().isEqual(today) || alert.getEffectiveDate().isBefore(today))
          && !isTermed(alert);
    }
    return true;
  }

  @Data
  class GroupAlertsModel {

    @Id private Long id;

    private List<Alert> alerts;

    private List<SubGroup> subGroupList;
  }
}
