package com.anthem.eap.group.repository;

import static com.anthem.eap.constants.DBConstants.SOURCE_SYSTEM;

import com.anthem.eap.model.group.HealthPlan;
import com.anthem.eap.model.group.dto.PageRequestDto;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class CustomHealthPlanRepositoryImpl implements CustomHealthPlanRepository {

  private final ReactiveMongoTemplate reactiveMongoTemplate;

  @Value("${healthplan.batchsize}")
  private Integer healthPlanBatchSize;

  public CustomHealthPlanRepositoryImpl(ReactiveMongoTemplate reactiveMongoTemplate) {
    this.reactiveMongoTemplate = reactiveMongoTemplate;
  }

  @Override
  public Mono<PageImpl<HealthPlan>> getHealthPlansByCriteria(
      PageRequestDto pageRequest, String sourceSystem) {

    Query query = prepareCriteria(pageRequest, sourceSystem).with(pageRequest.getPagable());
    return reactiveMongoTemplate
        .find(query, HealthPlan.class)
        .collectList()
        .flatMap(healthPlan -> getCount(pageRequest.getPagable(), query, healthPlan));
  }

  private Mono<PageImpl<HealthPlan>> getCount(
      Pageable pageable, Query query, List<HealthPlan> healthPlan) {
    return reactiveMongoTemplate
        .count(query.skip(-1).limit(-1), HealthPlan.class)
        .map(count -> new PageImpl<>(healthPlan, pageable, count));
  }

  private Query prepareCriteria(PageRequestDto pageRequest, String sourceSystem) {

    List<Criteria> criteriaList = new ArrayList<>();
    for (String key : pageRequest.getFields()) {
      if (key.equalsIgnoreCase("memCount") && StringUtils.isNumeric(pageRequest.getQuery())) {
        criteriaList.add(Criteria.where(key).is(Integer.valueOf(pageRequest.getQuery())));
      } else {
        criteriaList.add(
            Criteria.where(key)
                .regex("(?i).*" + Pattern.quote(pageRequest.getQuery().toLowerCase()) + ".*"));
      }
    }

    Criteria criteria = new Criteria();
    if (!criteriaList.isEmpty()) {
      criteria.orOperator(criteriaList);
    }

    Criteria sourceSystemMatcher = Criteria.where(SOURCE_SYSTEM).is(sourceSystem.toLowerCase());
    criteria.andOperator(sourceSystemMatcher);
    return new Query(criteria);
  }

  @Override
  public Flux<HealthPlan> fetchHealthPlans(PageRequestDto pageRequest, String sourceSystem) {
    Query query =
        prepareCriteria(pageRequest, sourceSystem)
            .with(Sort.by(pageRequest.getSortOrder(), pageRequest.getSortBy()))
            .cursorBatchSize(healthPlanBatchSize);
    return reactiveMongoTemplate.find(query, HealthPlan.class);
  }
}
