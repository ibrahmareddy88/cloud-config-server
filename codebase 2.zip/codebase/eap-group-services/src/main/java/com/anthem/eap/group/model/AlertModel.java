package com.anthem.eap.group.model;

import com.anthem.eap.model.group.Alert.AlertType;
import java.time.ZonedDateTime;
import lombok.Data;

@Data
public class AlertModel {

  private Long id;

  private Category category;

  private Long groupId;

  private Long subGroupId;

  private String alert;

  private AlertType alertType;

  private String createOrEditBy;

  private ZonedDateTime effectiveDate;

  private ZonedDateTime terminationDate;

  private ZonedDateTime createdDate;

  private ZonedDateTime lastModifiedDate;

  private String createdBy;

  private String lastModifiedBy;

  public enum Category {
    GROUP("Group"),
    SUBGROUP("Subgroup");
    private String value;

    Category(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }
  }
}
