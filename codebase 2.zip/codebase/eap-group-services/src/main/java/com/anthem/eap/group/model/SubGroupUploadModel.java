package com.anthem.eap.group.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubGroupUploadModel {

  private String eapGroupID;
  private String eapGroupName;
  private String eapSubgroupName;
  private String groupIdentifier;
  private String address1;
  private String address2;
  private String city;
  private String state;
  private String zip;
  private String contactPhone;
  private String ext;
  private String contactEmail;
  private String contactFirstName;
  private String contactLastName;
  private String other;
}
