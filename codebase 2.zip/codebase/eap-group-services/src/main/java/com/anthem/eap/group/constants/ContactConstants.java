package com.anthem.eap.group.constants;

public interface ContactConstants {
  int SEARCH_KEYWORD_MIN_LENGTH = 3;
  String SEARCH_QUERY_REQUEST_PARAM = "query";
}
