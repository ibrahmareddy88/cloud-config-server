package com.anthem.eap.group.repository;

import com.anthem.eap.config.EAPBeanResolver;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.repository.custom.AccountProfileCustomRepo;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.FinanceTerms;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.subgroup.SubGroup;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** @author Sravanti Cherukuri(AF69838) */
@Repository
public interface AccountProfileRepository
    extends ReactiveMongoRepository<AccountDetails, Long>, AccountProfileCustomRepo {

  @org.springframework.data.mongodb.repository.Query(
      value = "{ $or: [ { 'groupId' : ?0 }, { 'subGroupId' : ?1 } ] }",
      fields = "{ 'id':1,'effectiveDate' : 1, 'expiryDate' : 1}",
      sort = "{'createdDate': -1}")
  Flux<AccountDetails> findAllByGroupIdOrSubGroupId(Long groupId, Long subGroupId);

  default Mono<UtilizationReport> findAndModifyUtilizationReport(
      Long id, Long accountDetailsId, UtilizationReport utilizationReport, String type) {
    if (ObjectUtils.anyNotNull(id, accountDetailsId, utilizationReport, type)) {
      Query query =
          new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id))
              .addCriteria(Criteria.where("accountDetails._id").is(accountDetailsId));
      Update updateFields =
          new Update().set("accountDetails.$.utilizationReport", utilizationReport);
      return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
          .upsert(
              query,
              updateFields,
              type.equals(GroupConstants.GROUP_TYPE) ? Group.class : SubGroup.class)
          .thenReturn(utilizationReport);
    }
    return Mono.empty();
  }

  default Mono<FinanceTerms> findAndModifyFinanceTerms(
      Long id, Long accountDetailsId, FinanceTerms financeTerms, String type) {
    if (ObjectUtils.anyNotNull(id, accountDetailsId, financeTerms, type)) {
      Query query =
          new Query(Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id))
              .addCriteria(Criteria.where("accountDetails._id").is(accountDetailsId));
      Update updateFields = new Update().set("accountDetails.$.financeTerms", financeTerms);
      return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
          .upsert(
              query,
              updateFields,
              type.equals(GroupConstants.GROUP_TYPE) ? Group.class : SubGroup.class)
          .thenReturn(financeTerms);
    }
    return Mono.empty();
  }
}
