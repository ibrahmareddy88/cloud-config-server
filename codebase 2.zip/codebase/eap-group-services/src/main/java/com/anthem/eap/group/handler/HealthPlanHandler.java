package com.anthem.eap.group.handler;

import static com.anthem.eap.constants.EAPConstants.FILE_PATH;
import static com.anthem.eap.constants.EAPConstants.SOURCE_SYSTEM;
import static com.anthem.eap.model.group.HealthPlan.SourceSystem.EDW;

import com.anthem.eap.group.service.HealthPlanService;
import com.anthem.eap.helper.PageRequestHelper;
import com.anthem.eap.model.group.HealthPlan;
import com.anthem.eap.model.group.dto.PageRequestDto;
import java.io.File;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
public class HealthPlanHandler {

  private final HealthPlanService healthPlanService;

  public HealthPlanHandler(HealthPlanService healthPlanService) {
    this.healthPlanService = healthPlanService;
  }

  public Mono<ServerResponse> getHealthPlansByCriteria(ServerRequest request) {

    PageRequestDto pageRequest = PageRequestHelper.getPageRequest(request.queryParams());
    String sourceSystem = request.queryParam(SOURCE_SYSTEM.code).orElse(EDW.getValue());

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(healthPlanService.getHealthPlansByCriteria(pageRequest, sourceSystem), Page.class);
  }

  public Mono<ServerResponse> fetchHealthPlanStream(ServerRequest request) {
    PageRequestDto pageRequest = PageRequestHelper.getPageRequest(request.queryParams());
    String sourceSystem = request.queryParam(SOURCE_SYSTEM.code).orElse(EDW.getValue());
    return ServerResponse.ok()
        .contentType(MediaType.TEXT_EVENT_STREAM)
        .body(healthPlanService.fetchHealthPlans(pageRequest, sourceSystem), HealthPlan.class);
  }

  /**
   * Create workbook for HealthPlans
   *
   * @param request
   * @return
   */
  public Mono<ServerResponse> createWorkbook(ServerRequest request) {
    PageRequestDto pageRequest = PageRequestHelper.getPageRequest(request.queryParams());
    String sourceSystem = request.queryParam(SOURCE_SYSTEM.code).orElse(EDW.getValue());
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(healthPlanService.createWorkbook(pageRequest, sourceSystem), String.class);
  }

  /**
   * Export file from given path
   *
   * @param request
   * @return
   */
  public Mono<ServerResponse> export(ServerRequest request) {
    String fileName = request.queryParam(FILE_PATH.code).orElse(StringUtils.EMPTY);
    File file = new File(fileName);
    return ServerResponse.ok()
        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE)
        .contentLength(file.length())
        .body(healthPlanService.export(file), Resource.class);
  }
}
