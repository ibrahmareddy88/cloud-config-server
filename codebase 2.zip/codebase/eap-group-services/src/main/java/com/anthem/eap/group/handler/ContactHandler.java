package com.anthem.eap.group.handler;

import com.anthem.eap.group.constants.ContactConstants;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.ContactTypeResultDto;
import com.anthem.eap.group.dto.TerminateRoleResponseDto;
import com.anthem.eap.group.service.ContactService;
import com.anthem.eap.group.util.DateUtil;
import com.anthem.eap.model.contacts.Contact;
import com.anthem.eap.model.group.GroupSubgroupContact;
import java.net.URI;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Optional;
import javax.validation.Valid;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class ContactHandler {
  @Autowired private ContactService contactService;

  public Mono<ServerResponse> getContactById(ServerRequest request) {
    final Long id = Long.valueOf(request.pathVariable("id"));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(contactService.getContactById(id), Contact.class);
  }

  public Mono<ServerResponse> getContacts(ServerRequest request) {
    String emailId = request.headers().firstHeader("email");
    return Optional.ofNullable(emailId)
        .map(this::getContactByEmail)
        .orElseGet(this::getAllContacts);
  }

  public Mono<ServerResponse> updateContact(ServerRequest request) {
    return request
        .bodyToMono(Contact.class)
        .flatMap(contactService::saveOrUpdateContact)
        .flatMap(
            updatedContact ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(updatedContact)));
  }

  public Mono<ServerResponse> createContact(@Valid ServerRequest request) {
    return request
        .bodyToMono(Contact.class)
        .flatMap(contactService::saveOrUpdateContact)
        .flatMap(
            newContact ->
                ServerResponse.created(URI.create("/contact/" + newContact.getId()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .build());
  }

  public Mono<ServerResponse> getContactByEmail(String emailId) {
    Flux<Contact> contact = contactService.getContactByEmail(emailId);
    return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(contact, Contact.class);
  }

  private Mono<ServerResponse> getAllContacts() {
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(contactService.getAllContacts(), Contact.class);
  }

  public Mono<ServerResponse> getContactsBySearch(ServerRequest request) {
    if (request.queryParams().containsKey(ContactConstants.SEARCH_QUERY_REQUEST_PARAM)) {
      Optional<String> queryRequestParam =
          request.queryParam(ContactConstants.SEARCH_QUERY_REQUEST_PARAM);
      if (queryRequestParam.isPresent()
          && queryRequestParam.get().length() >= ContactConstants.SEARCH_KEYWORD_MIN_LENGTH)
        return contactService
            .findContactsByKeyword(queryRequestParam.get())
            .hasElements()
            .flatMap(
                hasElement ->
                    hasElement
                        ? ServerResponse.ok()
                            .body(
                                contactService.findContactsByKeyword(queryRequestParam.get()),
                                Contact.class)
                        : ServerResponse.noContent().build())
            .onErrorResume(
                error ->
                    ServerResponse.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(error.getMessage(), String.class));
      else
        return ServerResponse.badRequest()
            .contentType(MediaType.APPLICATION_JSON)
            .body(
                Flux.just(
                    "Search parameter is empty or length of Search parameter is < 3 characters"),
                String.class);
    } else
      return ServerResponse.badRequest()
          .contentType(MediaType.APPLICATION_JSON)
          .body(Flux.just("Query parameter (query) is missing in url"), String.class);
  }

  public Mono<ServerResponse> getContactTypes(ServerRequest request) {
    Long groupId = Long.valueOf(request.pathVariable(GroupConstants.GROUP_ID));
    if (ObjectUtils.isNotEmpty(groupId)) {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(contactService.getContactTypes(groupId), ContactTypeResultDto.class);
    } else return ServerResponse.badRequest().build();
  }

  public Mono<ServerResponse> saveContactTypes(ServerRequest request) {
    Long groupId = Long.valueOf(request.pathVariable(GroupConstants.GROUP_ID));
    Flux<ContactTypeResultDto> contactTypesFlux = request.bodyToFlux(ContactTypeResultDto.class);
    return contactTypesFlux
        .collectList()
        .flatMap(
            contactTypesList ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(
                        contactService.saveContactTypes(groupId, contactTypesList),
                        GroupSubgroupContact.class))
        .onErrorResume(
            error ->
                ServerResponse.status(HttpStatus.BAD_REQUEST)
                    .body(error.getMessage(), String.class));
  }

  public Mono<ServerResponse> findExistingContactTypes(ServerRequest request) {
    final Long groupId = Long.valueOf(request.pathVariable(GroupConstants.GROUP_ID));
    final Long contactId = Long.valueOf(request.pathVariable(GroupConstants.CONTACT_ID));
    if (ObjectUtils.isNotEmpty(groupId) && ObjectUtils.isNotEmpty(contactId)) {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(contactService.findExistingContactTypes(groupId, contactId), Boolean.class);
    }
    return ServerResponse.badRequest().build();
  }

  public Mono<ServerResponse> terminateContactRoles(ServerRequest request) {
    final Long contactId = Long.valueOf(request.pathVariable("contactId"));
    final Long groupId = Long.valueOf(request.pathVariable("groupId"));
    String terminationDate =
        Optional.ofNullable(request.headers().firstHeader("terminationDate")).orElse("");
    if (StringUtils.isNotBlank(terminationDate)) {
      ZonedDateTime inputTerminationDate = DateUtil.convertDateToZonedDateTime(terminationDate);
      if (ObjectUtils.allNotNull(inputTerminationDate)) {
        Flux<TerminateRoleResponseDto> response =
            this.contactService.terminateContactRoles(
                groupId,
                contactId,
                inputTerminationDate.withZoneSameLocal(ZoneId.of(GroupConstants.ZONE_UTC)));

        return ServerResponse.ok()
            .contentType(MediaType.APPLICATION_JSON)
            .body(response, TerminateRoleResponseDto.class);
      } else
        return ServerResponse.badRequest()
            .contentType(MediaType.APPLICATION_JSON)
            .body(Flux.just("Invalid Termination Date..."), String.class);
    } else
      return ServerResponse.badRequest()
          .contentType(MediaType.APPLICATION_JSON)
          .body(Flux.just("Termination Date is missing..."), String.class);
  }
}
