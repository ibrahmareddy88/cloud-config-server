package com.anthem.eap.group.dto;

import com.anthem.eap.model.group.GroupSubgroupContact;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GroupSubGroupContactDto {

  private Long id; // Group or SubGroup mongo id(_id)
  private Long groupId;
  private String name;
  private List<GroupSubgroupContact> contacts;

  public boolean isSubGroup() {
    return this.groupId != null;
  }
}
