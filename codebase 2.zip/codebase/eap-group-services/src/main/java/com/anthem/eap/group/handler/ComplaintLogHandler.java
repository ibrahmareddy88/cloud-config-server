package com.anthem.eap.group.handler;

import com.anthem.eap.group.service.ComplaintLogService;
import com.anthem.eap.model.complaints.ComplaintLog;
import java.net.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
public class ComplaintLogHandler {

  @Autowired private ComplaintLogService complaintService;

  public Mono<ServerResponse> getComplaintById(ServerRequest request) {
    final Long id = Long.valueOf(request.pathVariable("id"));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(complaintService.getComplaintById(id), ComplaintLog.class);
  }

  public Mono<ServerResponse> getAllComplaints(ServerRequest request) {
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(complaintService.getAllComplaints(), ComplaintLog.class);
  }

  public Mono<ServerResponse> updateComplaint(ServerRequest request) {
    return request
        .bodyToMono(ComplaintLog.class)
        .flatMap(complaintService::saveOrUpdateComplaint)
        .flatMap(
            updatedComplaint ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(updatedComplaint)));
  }

  public Mono<ServerResponse> createComplaint(ServerRequest request) {
    return request
        .bodyToMono(ComplaintLog.class)
        .flatMap(complaintService::saveOrUpdateComplaint)
        .flatMap(
            newComplaint ->
                ServerResponse.created(URI.create("/complaint/" + newComplaint.getId()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(newComplaint)));
  }
}
