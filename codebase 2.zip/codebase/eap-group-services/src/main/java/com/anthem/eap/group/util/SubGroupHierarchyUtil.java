package com.anthem.eap.group.util;

import com.anthem.eap.group.model.SubGroupTreeViewModel;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

@Component
public class SubGroupHierarchyUtil {

  private List<SubGroup> getSubGroupsByParentId(
      final List<SubGroup> subGrpList, Long id, Long recursionLevel) {
    if (recursionLevel == 0) {
      return subGrpList.stream()
          .filter(a -> Objects.isNull(a.getParentSubgroupId()) && a.getGroupId().equals(id))
          .collect(Collectors.toList());
    } else {
      return subGrpList.stream()
          .filter(a -> Objects.nonNull(a.getParentSubgroupId()))
          .filter(a -> a.getParentSubgroupId().equals(id))
          .collect(Collectors.toList());
    }
  }

  private List<SubGroupTreeViewModel> getSubGroupTreeViewModels(
      final List<SubGroup> subGrpList, Long id, Long recursionLevel) {
    List<SubGroup> subGrpsList = this.getSubGroupsByParentId(subGrpList, id, recursionLevel);
    return subGrpsList.stream().map(this::subGroupViewMapper).collect(Collectors.toList());
  }

  private SubGroupTreeViewModel subGroupViewMapper(SubGroup a) {
    SubGroupTreeViewModel viewModel = new SubGroupTreeViewModel();
    viewModel.setSubGroupId(a.getId());
    viewModel.setSubGroupName(a.getName());
    viewModel.setGroupId(a.getGroupId());
    viewModel.setParentSubGroupId(a.getParentSubgroupId());
    viewModel.setParentIdPath(a.getParentIdPath());
    viewModel.setParentNamePath(a.getParentNamePath());
    return viewModel;
  }

  public void buildHierarchyTree(
      SubGroupTreeViewModel root,
      final List<SubGroup> subGrpList,
      List<Long> parentIdList,
      List<String> parentNameList,
      Long recursionLevel) {
    SubGroupTreeViewModel groupView = root;
    List<SubGroupTreeViewModel> subs =
        getSubGroupTreeViewModels(subGrpList, root.getSubGroupId(), recursionLevel);
    subs.sort(
        Comparator.comparing(
            SubGroupTreeViewModel::getSubGroupName, String.CASE_INSENSITIVE_ORDER));
    groupView.setHierarchyLevel(recursionLevel);
    groupView.setSubGroupList(subs);
    if (CollectionUtils.isNotEmpty(subs)) {
      for (SubGroupTreeViewModel subGroup : subs) {
        recursionLevel = recursionLevel + 1;
        buildHierarchyTree(subGroup, subGrpList, parentIdList, parentNameList, recursionLevel);
        recursionLevel = recursionLevel - 1;
      }
    }
  }

  public SubGroupTreeViewModel getViewModel(
      SubGroupTreeViewModel parentRoot, final List<SubGroup> subGrpList) {
    buildHierarchyTree(parentRoot, subGrpList, new ArrayList<>(), new ArrayList<>(), 0L);
    return parentRoot;
  }
}
