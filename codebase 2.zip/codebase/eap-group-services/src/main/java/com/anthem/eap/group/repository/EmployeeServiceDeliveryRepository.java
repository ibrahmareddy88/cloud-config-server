package com.anthem.eap.group.repository;

import com.anthem.eap.model.employeeService.EmployeeServiceDelivery;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeServiceDeliveryRepository
    extends ReactiveMongoRepository<EmployeeServiceDelivery, Long> {}
