package com.anthem.eap.group.service;

import com.anthem.eap.group.dto.AccountProfileHistoryDto;
import com.anthem.eap.group.repository.AccountProfileRepository;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.repository.SubGroupRepository;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** @author Sravanti Cherukuri(AF69838) */
@Service
public class AccountProfileService {
  @Autowired ReactiveMongoTemplate reactiveMongoTemplate;
  @Autowired private AccountProfileRepository accountProfileRepository;
  @Autowired private GroupRepository groupRepository;
  @Autowired private SubGroupRepository subGroupRepository;

  public Flux<AccountDetails> getAllAccountProfiles() {
    return this.accountProfileRepository.findAll();
  }

  public Mono<AccountDetails> getAccountProfileById(@Parameter(in = ParameterIn.PATH) Long id) {
    return this.accountProfileRepository.findById(id);
  }

  public Mono<AccountDetails> saveOrUpdateAccountProfile(AccountDetails accountDetails) {
    return this.accountProfileRepository.save(accountDetails);
  }

  public Flux<AccountProfileHistoryDto> findByGroupIdOrSubgroupId(Long groupId, Long subgroupId) {
    if (ObjectUtils.anyNotNull(groupId, subgroupId)) {
      Flux<AccountDetails> accountDetails =
          this.accountProfileRepository.findAllByGroupIdOrSubGroupId(groupId, subgroupId);
      return accountDetails
          .flatMap(
              accDetail -> {
                AccountProfileHistoryDto accountDetailsObject = new AccountProfileHistoryDto();
                if (ObjectUtils.isNotEmpty(accDetail.getEffectiveDate()))
                  accountDetailsObject.setEffectiveDate(accDetail.getEffectiveDate().toString());
                accountDetailsObject.setId(accDetail.getId());
                if (ObjectUtils.isNotEmpty(accDetail.getExpiryDate()))
                  accountDetailsObject.setTerminationDate(accDetail.getExpiryDate().toString());
                return Flux.just(accountDetailsObject);
              })
          .switchIfEmpty(Flux.empty());
    }
    return Flux.empty();
  }

  public Mono<UtilizationReport> saveOrUpdateUtilizationReport(
      @Parameter(in = ParameterIn.PATH, name = "groupId") Long id,
      @Parameter(in = ParameterIn.PATH, name = "groupId") Long accountDetailsId,
      UtilizationReport utilizationReport,
      String type) {
    return this.accountProfileRepository.findAndModifyUtilizationReport(
        id, accountDetailsId, utilizationReport, type);
  }

  public Mono<AccountDetails> saveOrUpdateAccountDetails(
      Long id, AccountDetails accountDetails, String type) {
    return this.accountProfileRepository.findAndModifyAccountDetails(id, accountDetails, type);
  }
}
