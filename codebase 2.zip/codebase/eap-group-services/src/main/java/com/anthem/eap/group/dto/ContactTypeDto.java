package com.anthem.eap.group.dto;

import com.anthem.eap.model.group.GroupSubgroupContact;
import java.time.ZonedDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContactTypeDto {
  private Long contactId;
  private ZonedDateTime effectiveDate;
  private ZonedDateTime terminationDate;
  private Long subGroupId;
  private Long groupId;
  private String groupName;
  private String subGroupName;
  private ZonedDateTime lastModifiedDate;
  private GroupSubgroupContact.ContactType contactType;
  private Long contactTypeId;

  public ContactTypeDto(ContactTypeResultDto contactTypeResultDto) {
    this.groupId = contactTypeResultDto.getGroupId();
    this.contactId = contactTypeResultDto.getContactInfo().getContactId();
    this.contactTypeId = contactTypeResultDto.getContactTypeId();
    this.contactType = contactTypeResultDto.getContactType();
    this.effectiveDate = contactTypeResultDto.getEffectiveDate();
    this.terminationDate = contactTypeResultDto.getTerminationDate();
    this.subGroupId = contactTypeResultDto.getSubGroupId();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder()
        .append(this.getContactId())
        .append(this.getContactType())
        .append(this.getGroupType())
        .append(this.getEffectiveDate())
        .append(this.getTerminationDate())
        .toHashCode();
  }

  //  contactId, Contact Type, groupType(Group/Subgroup),	Effective date,	Expiration date
  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof ContactTypeDto)) {
      return false;
    }
    if (this == obj) {
      return true;
    }
    final ContactTypeDto otherObject = (ContactTypeDto) obj;
    return new EqualsBuilder()
            .append(this.getContactId(), otherObject.getContactId())
            .append(this.getContactType(), otherObject.getContactType())
            .append(this.getGroupType(), otherObject.getGroupType())
            .append(this.getSubGroupId(), otherObject.getSubGroupId())
            .isEquals()
        && isOverlapped(otherObject);
  }

  public boolean isOverlapped(ContactTypeDto contact) {
    if (ObjectUtils.allNotNull(contact.getContactTypeId(), this.contactTypeId)
        && Objects.equals(this.contactTypeId, contact.getContactTypeId())) {
      return false;
    }
    if (ObjectUtils.anyNull(terminationDate)
        && ObjectUtils.anyNotNull(contact.getTerminationDate())) {
      return !effectiveDate.isAfter(contact.getTerminationDate());
    }
    if (ObjectUtils.allNotNull(contact.getTerminationDate(), terminationDate)) {
      return !effectiveDate.isAfter(contact.getTerminationDate());
    }
    return true;
  }

  public GroupType getGroupType() {
    return this.isGroup() ? GroupType.GROUP : GroupType.SUB_GROUP;
  }

  public enum GroupType {
    GROUP,
    SUB_GROUP
  }

  public boolean isGroup() {
    return this.subGroupId == null;
  }
}
