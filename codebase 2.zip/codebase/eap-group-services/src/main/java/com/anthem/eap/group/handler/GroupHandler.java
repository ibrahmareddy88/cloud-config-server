package com.anthem.eap.group.handler;

import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.GroupSearchResultsHierarchyDto;
import com.anthem.eap.group.dto.HealthPlanIdGroupSearchResultDTO;
import com.anthem.eap.group.model.GroupBanner;
import com.anthem.eap.group.model.GroupEmployeeCountImport;
import com.anthem.eap.group.service.GroupService;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.BrokerCommission;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.FinanceTerms;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.accountProfile.SpecialInstruction;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.consultaton.dto.BankHoursDto;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.dto.GroupNameAddressDto;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

@Log4j2
@Component
public class GroupHandler {
  @Autowired private GroupService groupService;
  @Autowired private SubGroupService subGroupService;

  /**
   * @param request
   * @return
   */
  public Mono<ServerResponse> getGroups(ServerRequest request) {
    String filterBy = request.queryParam("filterBy").orElse("");
    log.info("filterBy>>>GroupServiceClient" + filterBy);
    String decodedFilterBy = "";
    try {
      decodedFilterBy = URLDecoder.decode(filterBy, "UTF-8");
    } catch (UnsupportedEncodingException e) {
      decodedFilterBy = filterBy;
    }
    log.info(" Decoded filterBy>>>GroupServiceClient" + decodedFilterBy);
    boolean sortBy = Boolean.parseBoolean(request.queryParam("_sort").orElse("false"));
    String name = request.queryParam("name").orElse(null);
    /* redirecting to findByName validation check if name exists in queryParam */
    if (StringUtils.isNotBlank(name)) {
      return findByName(name);
    }

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.findGroupsByKeyword(decodedFilterBy, sortBy), GroupSearchResultsDto.class);
  }

  public Mono<ServerResponse> getGroupById(ServerRequest request) {
    final Long id = Long.parseLong(request.pathVariable("id"));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.getGroupById(id), Group.class);
  }

  public Mono<ServerResponse> findByName(String groupName) {
    Flux<Group> group = groupService.findByName(groupName);
    return group
        .collectList()
        .flatMap(
            grp ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(group, Group.class));
  }

  public Mono<ServerResponse> getAllGroup(ServerRequest request) {
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.getAllGroup(), Group.class);
  }

  public Mono<ServerResponse> createGroup(ServerRequest request) {
    return request
        .bodyToMono(Group.class)
        .flatMap(groupService::save)
        .flatMap(
            newGroup ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(newGroup)));
  }

  public Mono<ServerResponse> updateGroup(ServerRequest request) {
    return request
        .bodyToMono(Group.class)
        .flatMap(groupService::update)
        .flatMap(
            updatedGroup ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(updatedGroup)));
  }

  public Mono<ServerResponse> updateGroupAccountDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));

    Mono<AccountDetails> response =
        request
            .bodyToMono(AccountDetails.class)
            .flatMap(
                accountDetails ->
                    this.groupService.saveOrUpdateAccountDetails(
                        groupId, accountDetails, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, AccountDetails.class);
  }

  public Mono<ServerResponse> updateGroupAccountUtilizationReport(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<UtilizationReport> response =
        request
            .bodyToMono(UtilizationReport.class)
            .flatMap(
                utilizationReport ->
                    this.groupService.saveOrUpdateUtilizationReport(
                        groupId, accountDetailsId, utilizationReport, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, UtilizationReport.class);
  }

  public Mono<ServerResponse> updateGroupAccountServiceDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<AccountService> response =
        request
            .bodyToMono(AccountService.class)
            .flatMap(
                accountService ->
                    this.groupService.saveOrUpdateAccountService(
                        groupId, accountDetailsId, accountService, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, AccountService.class);
  }

  public Mono<ServerResponse> findAllAccountServices(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findAllAccountServices(groupId, accountDetailsId), AccountService.class);
  }

  public Mono<ServerResponse> findAllAccountServicesByServiceType(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String serviceType = request.pathVariable(GroupConstants.ACCOUNT_SERVICE_TYPE);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.findAllAccountServicesByServiceType(
                subGroupId, accountDetailsId, serviceType),
            AccountService.class);
  }

  public Mono<ServerResponse> findAllSABanks(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findAllSABanks(subGroupId, accountDetailsId), SABank.class);
  }

  public Mono<ServerResponse> saveOrUpdateGroupAccountBrokerCommission(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<BrokerCommission> response =
        request
            .bodyToMono(BrokerCommission.class)
            .flatMap(
                brokerCommission ->
                    this.groupService.saveOrUpdateBrokerCommission(
                        groupId, accountDetailsId, brokerCommission, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, BrokerCommission.class);
  }

  public Mono<ServerResponse> updateGroupAccountFinanceTerms(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<FinanceTerms> response =
        request
            .bodyToMono(FinanceTerms.class)
            .flatMap(
                financeTerms ->
                    this.groupService.saveOrUpdateFinanceTerms(
                        groupId, accountDetailsId, financeTerms, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, FinanceTerms.class);
  }

  public Mono<ServerResponse> saveOrUpdateEmployerServiceNote(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<EmployerService> response =
        request
            .bodyToMono(EmployerService.class)
            .flatMap(
                employerService ->
                    this.groupService.saveOrUpdateEmployerServiceNote(
                        groupId, accountDetailsId, employerService, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, EmployerService.class);
  }

  public Mono<ServerResponse> findEmployerServiceNote(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<EmployerService> response =
        this.groupService.findEmployerServiceNote(groupId, accountDetailsId);

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, EmployerService.class);
  }

  public Mono<ServerResponse> updateGroupSpecialInstructions(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Flux<SpecialInstruction> response =
        request
            .bodyToFlux(SpecialInstruction.class)
            .collectList()
            .flatMapMany(
                instructions ->
                    groupService.updateSpecialInstructions(
                        groupId, accountDetailsId, instructions, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, SpecialInstruction.class);
  }

  public Mono<ServerResponse> updateGroupEmployerServiceSABankDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<SABank> response =
        request
            .bodyToMono(SABank.class)
            .flatMap(
                saBank ->
                    this.groupService.saveOrUpdateSABank(
                        groupId, accountDetailsId, saBank, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(response, SABank.class);
  }

  public Mono<ServerResponse> saveOrUpdateVendorDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<VendorDetails> response =
        request
            .bodyToMono(VendorDetails.class)
            .flatMap(
                employerService ->
                    this.groupService.saveOrUpdateVendorDetails(
                        groupId, accountDetailsId, employerService, GroupConstants.GROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, VendorDetails.class);
  }

  public Mono<ServerResponse> findAllVendorDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Flux<VendorDetails> response =
        this.groupService.findAllVendorDetails(groupId, accountDetailsId);

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, VendorDetails.class);
  }

  public Mono<ServerResponse> findAllSABankByBankName(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String bankName = request.pathVariable(GroupConstants.SABANK_NAME);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.findAllSABankByBankName(subGroupId, accountDetailsId, bankName),
            SABank.class);
  }

  public Mono<ServerResponse> uploadGroupEmployeeCounts(ServerRequest request) {
    Flux<GroupEmployeeCountImport> employeeCountsData =
        request.bodyToFlux(GroupEmployeeCountImport.class);
    return employeeCountsData
        .collectList()
        .flatMap(
            groupEmpCountsList ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(
                        groupService.uploadGroupEmployeeCounts(groupEmpCountsList),
                        GroupEmployeeCountImport.class));
  }

  public Mono<ServerResponse> renewGroupAccountDetails(ServerRequest request) {

    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.renewGroupAccountDetails(
                groupId, accountDetailsId, GroupConstants.GROUP_TYPE),
            AccountDetails.class);
  }

  public Mono<ServerResponse> getAccountDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String accountDetailsTile =
        request.queryParam(GroupConstants.ACCOUNT_DETAILS_FIELDS).orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.getAccountDetails(groupId, accountDetailId, accountDetailsTile),
            AccountDetails.class);
  }

  public Mono<ServerResponse> getAccountDetailsList(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.getAccountDetailsList(groupId), AccountDetails.class);
  }

  public Mono<ServerResponse> getActiveAccountDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return this.groupService
        .getActiveAccountDetails(groupId)
        .flatMap(
            acc ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(acc)))
        .switchIfEmpty(
            ServerResponse.badRequest()
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue("Active account details not found")));
  }

  public Mono<ServerResponse> getGroupBannerDetails(ServerRequest request) {
    final Long groupId = Long.parseLong(request.pathVariable(GroupConstants.GROUP_ID));
    Optional<String> subGroupId = request.queryParam(GroupConstants.SUBGROUP_ID);
    Mono<GroupBanner> groupBanner = null;
    if (subGroupId.isPresent()) {
      groupBanner =
          Mono.zip(
                  groupService.getGroupById(groupId),
                  subGroupService.getSubGroupById(Long.parseLong(subGroupId.get())))
              .map(this::bannerInfoMapper);
    } else {
      groupBanner =
          Mono.zip(groupService.getGroupById(groupId), Mono.just(new SubGroup()))
              .map(this::bannerInfoMapper);
    }

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupBanner, GroupBanner.class);
  }

  private GroupBanner bannerInfoMapper(Tuple2<Group, SubGroup> tpl) {
    GroupBanner groupBanner = new GroupBanner();

    Group group = tpl.getT1();
    SubGroup subgroup = tpl.getT2();

    groupBanner.setName(group.getName());
    groupBanner.setHealthPlanId(group.getHealthPlanIds());

    Stream<Address> addresses =
        Optional.ofNullable(group.getAddresses()).orElseGet(Collections::emptyList).stream();
    Stream<AccountDetails> accountDetails =
        Optional.ofNullable(group.getAccountDetails()).orElseGet(Collections::emptyList).stream();

    addresses
        .findFirst()
        .ifPresent(
            address -> {
              groupBanner.setPhoneNo(address.getPhone().getNumber());
            });

    accountDetails
        .findFirst()
        .ifPresent(
            account -> {
              groupBanner.setEapAccountId(account.getId());
              groupBanner.setProgramName(account.getProgramName());
              groupBanner.setPrimaryWebLogin(account.getPrimaryWebLogin());
              groupBanner.setProduct(account.getProduct());
              if (!Objects.isNull(account.getFinanceTerms())) {
                groupBanner.setGroupCode(account.getFinanceTerms().getGroupCode());
              }
            });

    if (Objects.isNull(subgroup.getParentNamePath())) {
      groupBanner.setPath(group.getName());
    } else {
      groupBanner.setPath(
          StringUtils.joinWith(" > ", subgroup.getParentNamePath(), subgroup.getName()));
    }

    return groupBanner;
  }

  public Mono<ServerResponse> deleteSABank(ServerRequest request) {
    final Long groupSubGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long bankId = NumberUtils.toLong(request.pathVariable(GroupConstants.BANK_ID));

    Mono<Group> response = this.groupService.removeBank(groupSubGroupId, bankId);
    return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(response, Group.class);
  }

  public Mono<ServerResponse> findActiveAccountDetailsByGroupId(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findActiveAccountDetailsByGroupId(groupId), GroupSearchResultsDto.class);
  }

  public Mono<ServerResponse> getBrokerAndContactDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    final Long accountDetailId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return this.groupService
        .findBrokerAndContactDetails(groupId, accountDetailId)
        .flatMap(
            brokerContacts ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(brokerContacts)));
  }

  public Mono<ServerResponse> findAllActiveVendorDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findAllActiveVendorDetails(groupId), VendorDetails.class);
  }

  public Mono<ServerResponse> findGroupSearchResultsAndHierarchy(ServerRequest request) {
    String filterBy = request.queryParam("filterBy").orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.findGroupsByKeywordWithHierarchy(filterBy),
            GroupSearchResultsHierarchyDto.class);
  }

  public Mono<ServerResponse> findGroupSubGroupAliasDetailById(ServerRequest request) {
    String nameType = request.queryParam("nameType").orElse("");
    Long id = NumberUtils.toLong(request.queryParam(GroupConstants.ID).orElse(null));
    if (ObjectUtils.anyNotNull(id, nameType)) {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(
              groupService.findGroupSubGroupAliasDetailById(id, nameType),
              GroupSearchResultsDto.class);
    } else
      return ServerResponse.badRequest()
          .contentType(MediaType.APPLICATION_JSON)
          .body(
              Flux.just("Invalid request for fetching group/subgroup/alias detail"), String.class);
  }

  public Mono<ServerResponse> findMatchingGroupByHealthPlanId(ServerRequest request) {
    String filterBy = request.pathVariable("healthPlanId");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            groupService.getMachingGroupsByHealthPlanId(filterBy),
            HealthPlanIdGroupSearchResultDTO.class);
  }

  public Mono<ServerResponse> findBankDetailsById(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findBankDetailsById(groupId), BankHoursDto.class);
  }

  public Mono<ServerResponse> findNameAndAddressById(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(groupService.findNameAndAddressById(groupId), GroupNameAddressDto.class);
  }
}
