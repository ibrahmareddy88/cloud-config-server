package com.anthem.eap.group;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

/** @author Dineel Bathina */
@SpringBootApplication
@ComponentScan({"com.anthem.eap"})
@EnableReactiveMongoRepositories({"com.anthem.eap.repository", "com.anthem.eap.group.repository"})
public class EapGroupsServicesApplication extends SpringBootServletInitializer {

  public static void main(String[] args) {
    SpringApplication.run(EapGroupsServicesApplication.class, args);
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(EapGroupsServicesApplication.class);
  }
}
