package com.anthem.eap.group.dto;

import com.anthem.eap.model.accountProfile.AccountDetails;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Sravanti Cherukuri(AF69838) */
@Data
@NoArgsConstructor
public class AccountProfileListDto {
  public List<AccountDetails> getAccountDetails() {
    return Optional.ofNullable(this.accountDetails).orElse(Collections.emptyList()).stream()
        .map(this::getPartialAccountDetails)
        .collect(Collectors.toList());
  }

  private List<AccountDetails> accountDetails;
  private AccountDetails activeProfile;

  private AccountDetails getPartialAccountDetails(AccountDetails accountDetails) {
    AccountDetails partialAccountDetails = new AccountDetails();
    partialAccountDetails.setEffectiveDate(accountDetails.getEffectiveDate());
    partialAccountDetails.setExpiryDate(accountDetails.getExpiryDate());
    partialAccountDetails.setId(accountDetails.getId());
    return partialAccountDetails;
  }
}
