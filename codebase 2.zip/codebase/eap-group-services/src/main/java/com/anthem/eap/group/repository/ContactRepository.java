package com.anthem.eap.group.repository;

import com.anthem.eap.model.contacts.Contact;
import java.util.List;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ContactRepository extends ReactiveMongoRepository<Contact, Long> {
  Flux<Contact> findByEmailIgnoreCase(String emailId);

  Flux<Contact> findByIdIn(List<Long> contactIds);
}
