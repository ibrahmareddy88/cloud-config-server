package com.anthem.eap.group.repository;

import static com.anthem.eap.group.constants.GroupConstants.GROUP_TYPE;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import com.anthem.eap.config.EAPBeanResolver;
import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.AccountProfileListDto;
import com.anthem.eap.group.dto.BrokerContactsDTO;
import com.anthem.eap.group.dto.ContactTypeResultDto;
import com.anthem.eap.group.util.ContactTypeUtil;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.group.AbstractGroup;
import com.anthem.eap.model.group.Group;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.dto.ActiveAccountDetailsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.repository.MongoAuditingRepository;
import java.lang.reflect.Field;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface GroupMongoRepository<T extends AbstractGroup>
    extends ReactiveMongoRepository<T, Long>, MongoAuditingRepository {

  List<String> ALL_ACCOUNT_PROFILE_PROPERTIES =
      Arrays.stream(AccountDetails.class.getDeclaredFields())
          .map(Field::getName)
          .collect(collectingAndThen(toList(), Collections::unmodifiableList));

  String[] BASIC_ACCOUNT_PROFILE_PROPERTIES =
      ALL_ACCOUNT_PROFILE_PROPERTIES.stream()
          .filter(field -> !GroupConstants.EXCLUDED_ACCOUNT_PROFILE_FIELDS.contains(field))
          .toArray(String[]::new);

  default Mono<AccountDetails> findAccountDetails(
      Long groupId, Long accountDetailId, String[] fields, String type) {
    ProjectionOperation projectionOperation =
        Aggregation.project()
            .andExpression(GroupConstants.ACCOUNT_DETAILS_MONGO_ID)
            .as(GroupConstants.ID_ATTRIBUTE)
            .andInclude(
                getProjectionFields(
                    ArrayUtils.addAll(fields, GroupConstants.AUDIT_FIELDS_WITH_MONGO_ID)));
    if (accountDetailId > 0) {
      List<AggregationOperation> projectionOperationList = new ArrayList<>();
      projectionOperationList.add(
          Aggregation.match(new Criteria(GroupConstants.ID_ATTRIBUTE).is(groupId)));
      projectionOperationList.add(Aggregation.unwind(GroupConstants.ACCOUNT_DETAILS));
      projectionOperationList.add(
          Aggregation.match(
              new Criteria(GroupConstants.ACCOUNT_DETAILS_MONGO_ID).is(accountDetailId)));

      if (Arrays.asList(fields).contains(GroupConstants.ACCOUNT_PROFILE)) {
        projectionOperation =
            projectionOperation.andInclude(getProjectionFields(BASIC_ACCOUNT_PROFILE_PROPERTIES));
      }
      projectionOperationList.add(projectionOperation);

      Aggregation aggregation = Aggregation.newAggregation(projectionOperationList);
      return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
          .aggregate(
              aggregation,
              type.equals(GROUP_TYPE) ? Group.class : SubGroup.class,
              AccountDetails.class)
          .next();
    }
    return Mono.empty();
  }

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match: {'accountDetails._id': ?1 }}",
        "{$project: {'contacts': 1, 'accountDetails._id':1,'accountDetails.brokerCommissions':1, 'accountDetails.effectiveDate':1,'accountDetails.expiryDate':1}}"
      })
  Mono<BrokerContactsDTO> findBrokerAndContactDetails(Long groupId, Long accountDetailId);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$sort: {'accountDetails.createdDate._date': -1}}",
        "{$group: {_id: '$_id', 'accountDetails': {$push: '$accountDetails'}}}",
        "{$project: {'accountDetails': '$accountDetails','activeProfile':{ $arrayElemAt: [ '$accountDetails', 0 ] }}}"
      })
  Mono<AccountProfileListDto> findAccountDetailsList(Long groupId);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match:{'_id':?0}}",
        "{$project: {'name':1,'groupId':1,'accountDetails':{$filter:{input: '$accountDetails',as: 'accountDetails',cond:{$and:[ {$gte : ['$$accountDetails.expiryDate', new Date()]},{$lte : ['$$accountDetails.effectiveDate', new Date() ]}]}}}}}",
        "{$project: {'name':1,'groupId':1,'activeProfile':{ $arrayElemAt: [ '$accountDetails', 0 ] }}}",
        "{$project: {'orgGroupName':'$name','groupId':'$groupId','organizationBrand': '$activeProfile.brand', 'organizationEapWebSite': '$activeProfile.eapWebSite', 'organizationNumberOfSessions': '$activeProfile.numberOfSessions', 'organizationAccountId': '$activeProfile._id'}}"
      })
  Mono<ActiveAccountDetailsDto> fetchActiveAccountDetails(Long id);

  static String[] getProjectionFields(String[] fields) {
    return Stream.of(fields)
        .map(field -> GroupConstants.ACCOUNT_DETAILS + "." + field)
        .toArray(String[]::new);
  }

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {"{$match:{_id:?0}}", "{$project: {'contacts': 1}}"})
  Mono<Group> findContacts(Long id);

  default Mono<GroupSubgroupContact> deleteContactType(
      GroupSubgroupContact groupSubgroupContact, Class<T> clazz) {
    Query query =
        new Query(
            Criteria.where(GroupConstants.CONTACTS)
                .elemMatch(
                    Criteria.where(GroupConstants.ID_ATTRIBUTE).is(groupSubgroupContact.getId())));

    return populateAuditDetails(groupSubgroupContact)
        .flatMap(this::prepareUpdate)
        .flatMap(update -> saveContactType(groupSubgroupContact, query, update, clazz));
  }

  default Mono<Update> prepareUpdate(GroupSubgroupContact groupSubgroupContact) {
    Query query =
        new Query()
            .addCriteria(
                Criteria.where(GroupConstants.ID_ATTRIBUTE).is(groupSubgroupContact.getId()));
    return prepareAuditUpdateQuery(StringUtils.EMPTY)
        .map(update -> update.pull(GroupConstants.CONTACTS, query));
  }

  default Mono<GroupSubgroupContact> saveContactType(
      GroupSubgroupContact groupSubgroupContact,
      Query query,
      Update update,
      Class<? extends AbstractGroup> clazz) {

    return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
        .findAndModify(query, update, new FindAndModifyOptions().returnNew(true), clazz)
        .mapNotNull(AbstractGroup::getContacts)
        .flatMapMany(Flux::fromIterable)
        .filter(contactType -> Objects.equals(groupSubgroupContact.getId(), contactType.getId()))
        .next();
  }

  default Mono<ContactTypeResultDto> upsertContactType(
      GroupSubgroupContact groupSubgroupContact, Long id, Class<? extends AbstractGroup> clazz) {

    Criteria criteria = Criteria.where(GroupConstants.ID_ATTRIBUTE).is(id);
    Query query = new Query(criteria);

    return findContacts(id)
        .mapNotNull(AbstractGroup::getContacts)
        .flatMapMany(Flux::fromIterable)
        .collectList()
        .flatMap(contacts -> addOrUpdateContact(contacts, groupSubgroupContact))
        .flatMap(this::getUpdateObjectToUpsertContactType)
        .flatMap(update -> saveContactType(groupSubgroupContact, query, update, clazz))
        .map(ContactTypeUtil::mappingToContactTypeResultDto);
  }

  default Mono<Update> getUpdateObjectToUpsertContactType(List<GroupSubgroupContact> contacts) {
    Update update = new Update();
    update.set(GroupConstants.CONTACTS, contacts);
    return Mono.just(update);
  }

  default Mono<List<GroupSubgroupContact>> addOrUpdateContact(
      List<GroupSubgroupContact> contacts, GroupSubgroupContact contact) {
    return this.populateAuditDetails(contact)
        .map(
            updatedContact -> {
              contacts.removeIf(a -> Objects.equals(a.getId(), contact.getId()));
              contacts.add(contact);
              return contacts;
            });
  }

  default Flux<ContactTypeResultDto> updateContactTypeTerminationDate(
      Long groupId,
      Long contactId,
      ZonedDateTime terminationDate,
      List<ContactTypeResultDto> toBeUpdatedContactTypes,
      Class<? extends AbstractGroup> clazz) {
    Update update = new Update();
    update.set(GroupConstants.CONTACT_TERMINATION_DATE, terminationDate);

    Criteria criteria;
    if (StringUtils.equals(clazz.getSimpleName(), GroupConstants.SUBGROUP_CLASS_NAME))
      criteria = Criteria.where(GroupConstants.GROUP_ID).is(groupId);
    else criteria = Criteria.where(GroupConstants.ID_ATTRIBUTE).is(groupId);
    Query fetchQuery = new Query(criteria);
    fetchQuery.addCriteria(
        Criteria.where(GroupConstants.CONTACTS)
            .elemMatch(Criteria.where(GroupConstants.CONTACT_INFO_ID).is(contactId)));

    return Flux.fromIterable(toBeUpdatedContactTypes)
        .flatMap(
            contactType -> {
              Query updateQuery = new Query(criteria);
              updateQuery.addCriteria(
                  Criteria.where(GroupConstants.CONTACTS)
                      .elemMatch(
                          new Criteria()
                              .andOperator(
                                  Criteria.where(GroupConstants.CONTACT_INFO_ID).is(contactId),
                                  Criteria.where(GroupConstants.ID_ATTRIBUTE)
                                      .is(contactType.getContactTypeId()))));
              return EAPBeanResolver.getBean(ReactiveMongoTemplate.class)
                  .findAndModify(updateQuery, update, clazz)
                  .thenReturn(contactType);
            });
  }
}
