package com.anthem.eap.group.handler;

import static com.anthem.eap.group.constants.GroupConstants.ACCOUNT_ID;
import static com.anthem.eap.group.constants.GroupConstants.ID;

import com.anthem.eap.group.model.EmployeeServiceDeliveryViewModel;
import com.anthem.eap.group.service.EmployeeServiceDeliveryService;
import com.anthem.eap.group.util.NumberUtil;
import com.anthem.eap.model.employeeService.EmployeeServiceDelivery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
public class EmployeeServiceDeliveryHandler {

  @Autowired private EmployeeServiceDeliveryService employeeServiceDeliveryService;

  public Mono<ServerResponse> getAll(ServerRequest request) {
    String accountId = request.queryParam(ACCOUNT_ID).orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            employeeServiceDeliveryService.getAll(accountId),
            EmployeeServiceDeliveryViewModel.class);
  }

  public Mono<ServerResponse> getAllServiceDetails(ServerRequest request) {
    String accountId = request.queryParam(ACCOUNT_ID).orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            employeeServiceDeliveryService.getAllServiceDetails(accountId),
            EmployeeServiceDelivery.class);
  }

  public Mono<ServerResponse> getEmployeeServiceDeliveryById(ServerRequest request) {
    if (NumberUtil.isValidPositiveNumber(request.pathVariable(ID))) {
      Long id = Long.parseLong(request.pathVariable(ID));
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(
              employeeServiceDeliveryService.getEmployeeServiceDeliveryById(id),
              EmployeeServiceDelivery.class);

    } else {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(Mono.empty(), EmployeeServiceDelivery.class);
    }
  }

  public Mono<ServerResponse> saveEmployeeServiceDelivery(ServerRequest request) {
    Mono<EmployeeServiceDelivery> esd = request.bodyToMono(EmployeeServiceDelivery.class);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            employeeServiceDeliveryService.saveEmployeeServiceDelivery(esd),
            EmployeeServiceDelivery.class);
  }

  public Mono<ServerResponse> updateEmployeeServiceDelivery(ServerRequest request) {
    Mono<EmployeeServiceDelivery> esd = request.bodyToMono(EmployeeServiceDelivery.class);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            employeeServiceDeliveryService.updateEmployeeServiceDelivery(esd),
            EmployeeServiceDelivery.class);
  }

  public Mono<ServerResponse> deleteEmployeeServiceDelivery(ServerRequest request) {
    if (NumberUtil.isValidPositiveNumber(request.pathVariable(ID))) {
      Long id = Long.parseLong(request.pathVariable(ID));
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(employeeServiceDeliveryService.deleteEmployeeServiceDelivery(id), Void.class);
    } else {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(Mono.empty(), Void.class);
    }
  }
}
