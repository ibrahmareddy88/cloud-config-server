package com.anthem.eap.group.constants;

import static com.anthem.eap.constants.DBConstants.BROKER_COMMISSION_SEQUENCE;
import static com.anthem.eap.constants.DBConstants.SPECIAL_INSTRUCTIONS_SEQUENCE;

import java.util.Arrays;
import java.util.List;

/** @author Sravanti Cherukuri(AF69838) */
public interface GroupConstants {
  String GROUP_ID = "groupId";
  String SUBGROUP_ID = "subgroupId";
  String ACCOUNT_DETAILS = "accountDetails";
  String ACCOUNT_DETAILS_ID = "accountdetailsId";
  String ACCOUNT_DETAILS_FIELDS = "fields";
  String BANK_ID = "bankId";
  String GROUP_TYPE = "GROUP";
  String SUBGROUP_TYPE = "SUBGROUP";
  String ACCOUNT_PROFILE = "profile";
  String UTILIZATION_REPORT = "utilizationReport";
  String ID_ATTRIBUTE = "_id";
  String ACCOUNT_SERVICE = "accountServices";
  String ACCOUNT_SERVICE_TYPE = "serviceType";
  String INSERT_ACCOUNT_SERVICE = "accountDetails.$.employerServices.$.accountServices.$";
  String UPDATE_ACCOUNT_SERVICE =
      "accountDetails.$[accDetail].employerServices.accountServices.$[accService]";
  String INSERT_OR_UPDATE_ACCOUNT_SERVICE_NOTE = "accountDetails.$.employerServices.$.benefitNotes";
  String ZONE_UTC = "UTC";
  String CREATED_DATE = "createdDate";
  String LAST_MODIFIED_DATE = "lastModifiedDate";
  String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  String ACCOUNT_DETAILS_POSITIONAL = "accountDetails.$.";
  String ACCOUNT_DETAILS_MONGO_ID = "accountDetails._id";
  String BROKER_COMMISSIONS_MONGO_ID = "accountDetails.brokerCommissions._id";
  String PATH_TO_BROKER_COMMISSIONS = ACCOUNT_DETAILS_POSITIONAL + BROKER_COMMISSION_SEQUENCE;
  String PATH_TO_SPECIAL_INSTRUCTIONS = ACCOUNT_DETAILS_POSITIONAL + SPECIAL_INSTRUCTIONS_SEQUENCE;
  String SABANK_SERVICE = "saBank";
  String INSERT_SABANK_SERVICE = "accountDetails.$.employerServices.$.saBank.$";
  String UPDATE_SABANK_SERVICE = "accountDetails.$[accDetail].employerServices.saBank.$[bank]";
  String VENDOR_DETAILS = "vendorDetails";
  String INSERT_VENDOR_DETAILS_PATH = ACCOUNT_DETAILS_POSITIONAL + VENDOR_DETAILS;
  String UPDATE_VENDOR_DETAILS_PATH = "accountDetails.$[accDetail].vendorDetails.$[vendor]";
  String VENDOR_DETAILS_MONGO_ID = "accountDetails." + VENDOR_DETAILS + "._id";
  String STATUS_ACTIVE = "Active";
  String STATUS_INACTIVE = "InActive";
  String STATUS_CLOSED = "Closed";
  String[] DEFAULT_SABANK = {"Combined Hours", "CIR Hours", "Training Hours"};
  String SABANK_NAME = "bankName";
  String _GROUP = "_group";
  String _SUBGROUP = "_subGroup";
  String EMPLOYEE_SERVICE_DELIVERY = "employeeServiceDelivery";
  String COMPLETED_DATE = "completedDate";
  String SERVICE_ID = "serviceId";
  String ID = "id";
  String PROVIDER = "provider";
  String _PROVIDER = "_provider";
  String PROVIDER_ID = "providerId";
  String BRANCH_NUMBER = "branchNumber";
  String PROVIDERLOCATIONS = "providerLocations";
  String _PROVIDER_PL = "_provider.providerLocations";
  String ACCOUNT_ID = "accountId";
  String CONTACTS = "contacts";
  String CONTACT_ID = "contactId";
  String CONTACT_INFO_ID = "contactInfo.contactId";
  String CONTACT_TERMINATION_DATE = "contacts.$.terminationDate";
  String SUBGROUP_CLASS_NAME = "SubGroup";
  String ALIAS = "Alias";
  String GROUP = "Group";
  String SUB_GROUP = "Sub Group";
  String SUB_GROUP_ALIAS = "Subgroup";
  List<String> EXCLUDED_ACCOUNT_PROFILE_FIELDS =
      Arrays.asList(
          "effectiveDate",
          "expiryDate",
          "utilizationReport",
          "financeTerms",
          "employerServices",
          "vendorDetails",
          "brokerCommissions",
          "specialInstructions");
  String[] AUDIT_FIELDS_WITH_MONGO_ID = {
    "_id",
    "effectiveDate",
    "product",
    "expiryDate",
    "createdDate",
    "lastModifiedDate",
    "lastModifiedBy",
    "createdBy"
  };
}
