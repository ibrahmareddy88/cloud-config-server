package com.anthem.eap.group.model;

import com.anthem.eap.model.group.subgroup.SubGroup;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CountImportWithSubGroup {
  private SubGroupEmployeeCountImport subGroupEmployeeCountImport;
  private SubGroup subGroup;
}
