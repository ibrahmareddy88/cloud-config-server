package com.anthem.eap.group.model;

import com.anthem.eap.model.common.Address;
import lombok.Data;

@Data
public class ProviderLocationViewModel {
  private Long branchNumber;
  private Address practiceAddress;
  private Address mailingAddress;
  private Address billingAddress;
}
