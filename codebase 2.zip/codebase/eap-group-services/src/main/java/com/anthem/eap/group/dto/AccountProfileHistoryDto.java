package com.anthem.eap.group.dto;

import lombok.Data;

/** @author Sravanti Cherukuri(AF69838) */
@Data
public class AccountProfileHistoryDto {
  private Long id;
  private String effectiveDate;
  private String terminationDate;
}
