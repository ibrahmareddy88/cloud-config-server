package com.anthem.eap.group.handler;

import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.service.AccountProfileService;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import java.net.URI;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/** @author Sravanti Cherukuri(AF69838) */
@Component
public class AccountProfileHandler {

  private final AccountProfileService accountProfileService;

  public AccountProfileHandler(AccountProfileService accountProfileService) {
    this.accountProfileService = accountProfileService;
  }

  public Mono<ServerResponse> createAccountProfile(ServerRequest request) {
    return request
        .bodyToMono(AccountDetails.class)
        .flatMap(accountProfileService::saveOrUpdateAccountProfile)
        .flatMap(
            newAccountProfile ->
                ServerResponse.created(URI.create("/accountProfile/" + newAccountProfile.getId()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .build());
  }

  public Mono<ServerResponse> getAccountProfileById(ServerRequest request) {
    final Long id = Long.valueOf(request.pathVariable("id"));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(accountProfileService.getAccountProfileById(id), AccountDetails.class);
  }

  public Mono<ServerResponse> getAllAccountProfiles(ServerRequest request) {
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(accountProfileService.getAllAccountProfiles(), AccountDetails.class);
  }

  public Mono<ServerResponse> updateAccountProfile(ServerRequest request) {
    return request
        .bodyToMono(AccountDetails.class)
        .flatMap(accountProfileService::saveOrUpdateAccountProfile)
        .flatMap(
            updatedAccountProfile ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(updatedAccountProfile)));
  }



  public Mono<ServerResponse> getAccountProfilesOfGroupOrSubGroup(ServerRequest request) {
    Long groupId = NumberUtils.toLong(request.queryParam(GroupConstants.GROUP_ID).orElse(""));
    Long subGroupId = NumberUtils.toLong(request.queryParam(GroupConstants.SUBGROUP_ID).orElse(""));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            accountProfileService.findByGroupIdOrSubgroupId(groupId, subGroupId),
            AccountDetails.class);
  }

  public Mono<ServerResponse> updateUtilizationReport(ServerRequest request) {
    final Long accountProfileId = Long.valueOf(request.pathVariable("id"));
    Mono<UtilizationReport> response =
        request
            .bodyToMono(UtilizationReport.class)
            .flatMap(
                utilizationReport ->
                    this.accountProfileService.saveOrUpdateUtilizationReport(
                        accountProfileId, accountProfileId, utilizationReport, ""));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, UtilizationReport.class);
  }
}
