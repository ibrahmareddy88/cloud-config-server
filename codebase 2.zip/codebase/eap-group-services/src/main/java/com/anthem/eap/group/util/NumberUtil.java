package com.anthem.eap.group.util;

import java.util.regex.Pattern;

public class NumberUtil {

  private static final String NUMBER_PATTERN = "^[0-9]*$";

  private static final String NUMBER_PATTERN_WITH_COMMA = "(?:\\d+(?:,|$))+";

  public static boolean isValidPositiveNumber(String value) {
    return Pattern.matches(NUMBER_PATTERN, value);
  }

  public static boolean isValidPositiveNumberWithComma(String value) {
    value = value.replaceAll(",$", "");
    return Pattern.matches(NUMBER_PATTERN_WITH_COMMA, value);
  }
}
