package com.anthem.eap.group.repository;

import com.anthem.eap.model.complaints.ComplaintLog;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ComplaintLogRepository extends ReactiveMongoRepository<ComplaintLog, Long> {}
