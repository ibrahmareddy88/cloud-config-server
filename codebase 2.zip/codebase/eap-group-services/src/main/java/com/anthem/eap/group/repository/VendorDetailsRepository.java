package com.anthem.eap.group.repository;

import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.repository.MongoAuditingRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface VendorDetailsRepository extends MongoAuditingRepository {

  Mono<VendorDetails> findAndModifyVendorDetails(
      Long id, Long accountDetailsId, VendorDetails vendorDetails, String type);
}
