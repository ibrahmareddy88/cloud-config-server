package com.anthem.eap.group.handler;

import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.dto.GroupAccountDetailDto;
import com.anthem.eap.group.model.SubGroupEmployeeCountImport;
import com.anthem.eap.group.model.SubGroupTreeViewModel;
import com.anthem.eap.group.model.SubGroupUploadModel;
import com.anthem.eap.group.model.SubGroupViewModel;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.group.service.SubGroupService;
import com.anthem.eap.group.util.SubGroupHelper;
import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.BrokerCommission;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.FinanceTerms;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.accountProfile.SpecialInstruction;
import com.anthem.eap.model.accountProfile.UtilizationReport;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.consultaton.dto.BankHoursDto;
import com.anthem.eap.model.group.dto.ActiveAccountDetailsDto;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.model.group.subgroup.dto.SubGroupNameDto;
import java.util.Optional;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class SubGroupHandler {

  @Autowired SubGroupService subGroupService;
  @Autowired private GroupRepository groupRepository;

  public Mono<ServerResponse> getSubGroupById(ServerRequest request) {
    final Long id = Long.valueOf(request.pathVariable("id"));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.getSubGroupById(id), SubGroup.class);
  }

  public Mono<ServerResponse> getAllSubGroupByGroupId(ServerRequest request) {
    Optional<String> groupIdOpt = request.queryParam("groupId");
    Long id = null;
    if (groupIdOpt.isPresent()) {
      id = Long.valueOf(groupIdOpt.get());
    }
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.getSubGroupsByGroupId(id), SubGroup.class);
  }

  public Mono<ServerResponse> getTreeView(ServerRequest request) {
    Optional<String> groupIdOpt = request.queryParam("groupId");
    Optional<String> groupNameOpt = request.queryParam("groupName");
    Long groupId = null;
    String groupName = null;
    if (groupIdOpt.isPresent()) {
      groupId = Long.valueOf(groupIdOpt.get());
    }
    if (groupNameOpt.isPresent()) {
      groupName = String.valueOf(groupNameOpt.get());
    }
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.getGroupTree(groupId, groupName), SubGroupTreeViewModel.class);
  }

  public Mono<ServerResponse> createSubGroup(ServerRequest request) {
    return request
        .bodyToMono(SubGroupViewModel.class)
        .map(this::subGroupMapper)
        .flatMap(subGroupService::saveSubGroup)
        .map(this::subGroupVOMapper)
        .flatMap(
            newSubGroup ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(newSubGroup)));
  }

  public Mono<ServerResponse> uploadSubGroups(ServerRequest request) {
    Flux<SubGroupUploadModel> flatMap = request.bodyToFlux(SubGroupUploadModel.class);
    Flux<SubGroup> subGroups = flatMap.map(this::subGroupMapper);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.uploadSubGroups(subGroups), SubGroup.class);
  }

  public Mono<ServerResponse> moveSubGroups(ServerRequest request) {
    Flux<SubGroupTreeViewModel> moveGroups = request.bodyToFlux(SubGroupTreeViewModel.class);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.moveSubGroups(moveGroups), SubGroup.class);
  }

  public Mono<ServerResponse> updateSubGroup(ServerRequest request) {
    final Long id = Long.valueOf(request.pathVariable("id"));

    // get subGrp data from request object
    Mono<SubGroupViewModel> responseMono =
        request
            .bodyToMono(SubGroupViewModel.class)
            .map(this::subGroupMapper)
            .flatMap(a -> subGroupService.update(id, a))
            .map(this::subGroupVOMapper);

    return responseMono.flatMap(
        updatedSubGroup ->
            ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(updatedSubGroup)));
  }

  private SubGroup subGroupMapper(SubGroupUploadModel uploadModel) {
    SubGroup subGroup = SubGroupHelper.pepareSubgroup(uploadModel);
    return subGroup;
  }

  private SubGroup subGroupMapper(SubGroupViewModel viewModel) {
    SubGroup subGroup = new SubGroup();
    BeanUtils.copyProperties(viewModel, subGroup);
    return subGroup;
  }

  private SubGroupViewModel subGroupVOMapper(SubGroup subGroup) {
    SubGroupViewModel viewModel = new SubGroupViewModel();
    BeanUtils.copyProperties(subGroup, viewModel);
    return viewModel;
  }

  public Mono<ServerResponse> updateSubGroupAccountDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));

    Mono<AccountDetails> response =
        request
            .bodyToMono(AccountDetails.class)
            .flatMap(
                accountDetails ->
                    this.subGroupService.saveOrUpdateAccountDetails(
                        groupId, accountDetails, GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, AccountDetails.class);
  }

  public Mono<ServerResponse> updateSubGroupAccountUtilizationReport(ServerRequest request) {
    final Long subgroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<UtilizationReport> response =
        request
            .bodyToMono(UtilizationReport.class)
            .flatMap(
                utilizationReport ->
                    this.subGroupService.saveOrUpdateUtilizationReport(
                        subgroupId,
                        accountDetailsId,
                        utilizationReport,
                        GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, UtilizationReport.class);
  }

  public Mono<ServerResponse> saveOrUpdateSubGroupAccountBrokerCommission(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<BrokerCommission> response =
        request
            .bodyToMono(BrokerCommission.class)
            .flatMap(
                brokerCommission ->
                    this.subGroupService.saveOrUpdateBrokerCommission(
                        groupId, accountDetailsId, brokerCommission, GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, BrokerCommission.class);
  }

  public Mono<ServerResponse> updateSubGroupAccountServiceDetails(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<AccountService> response =
        request
            .bodyToMono(AccountService.class)
            .flatMap(
                accountService ->
                    this.subGroupService.saveOrUpdateAccountService(
                        subGroupId,
                        accountDetailsId,
                        accountService,
                        GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, AccountService.class);
  }

  public Mono<ServerResponse> findAllSubGroupAccountServices(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.findAllSubGroupAccountServices(subGroupId, accountDetailsId),
            AccountService.class);
  }

  public Mono<ServerResponse> findAllSubGroupAccountServicesByServiceType(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String serviceType = request.pathVariable(GroupConstants.ACCOUNT_SERVICE_TYPE);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.findAllSubGroupAccountServicesByServiceType(
                subGroupId, accountDetailsId, serviceType),
            AccountService.class);
  }

  public Mono<ServerResponse> findAllSubGroupSABanks(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.findAllSubGroupSABanks(subGroupId, accountDetailsId), SABank.class);
  }

  public Mono<ServerResponse> updateSubGroupAccountFinanceTerms(ServerRequest request) {
    final Long subgroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<FinanceTerms> response =
        request
            .bodyToMono(FinanceTerms.class)
            .flatMap(
                financeTerms ->
                    this.subGroupService.saveOrUpdateFinanceTerms(
                        subgroupId, accountDetailsId, financeTerms, GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, FinanceTerms.class);
  }

  public Mono<ServerResponse> saveOrUpdateSubGroupEmployerServiceNote(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<EmployerService> response =
        request
            .bodyToMono(EmployerService.class)
            .flatMap(
                employerService ->
                    this.subGroupService.saveOrUpdateSubGroupEmployerServiceNote(
                        subGroupId,
                        accountDetailsId,
                        employerService,
                        GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, EmployerService.class);
  }

  public Mono<ServerResponse> findSubGroupEmployerServiceNote(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<EmployerService> response =
        this.subGroupService.findSubGroupEmployerServiceNote(groupId, accountDetailsId);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, EmployerService.class);
  }

  public Mono<ServerResponse> saveOrUpdateSubGroupVendorDetails(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Mono<VendorDetails> response =
        request
            .bodyToMono(VendorDetails.class)
            .flatMap(
                employerService ->
                    this.subGroupService.saveOrUpdateSubGroupVendorDetails(
                        subGroupId,
                        accountDetailsId,
                        employerService,
                        GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, VendorDetails.class);
  }

  public Mono<ServerResponse> findAllSubGroupVendorDetails(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    Flux<VendorDetails> response =
        this.subGroupService.findAllSubGroupVendorDetails(subGroupId, accountDetailsId);

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, VendorDetails.class);
  }

  public Mono<ServerResponse> updateSpecialInstructions(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Flux<SpecialInstruction> response =
        request
            .bodyToFlux(SpecialInstruction.class)
            .collectList()
            .flatMapMany(
                instructions ->
                    this.subGroupService.updateSpecialInstructions(
                        subGroupId, accountDetailsId, instructions, GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, SpecialInstruction.class);
  }

  public Mono<ServerResponse> updateSubGroupEmployerServiceSABankDetails(ServerRequest request) {
    final Long subgroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    Mono<SABank> response =
        request
            .bodyToMono(SABank.class)
            .flatMap(
                saBank ->
                    this.subGroupService.saveOrUpdateSABank(
                        subgroupId, accountDetailsId, saBank, GroupConstants.SUBGROUP_TYPE));
    return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(response, SABank.class);
  }

  public Mono<ServerResponse> uploadSubGroupEmployeeCounts(ServerRequest request) {
    Flux<SubGroupEmployeeCountImport> reqData =
        request.bodyToFlux(SubGroupEmployeeCountImport.class);
    return reqData
        .collectList()
        .flatMap(
            mapper ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(
                        subGroupService.uploadSubGroupEmployeeCounts(mapper),
                        SubGroupEmployeeCountImport.class));
  }

  public Flux<GroupSearchResultsDto> findSubGroupStatusById(
      Flux<GroupSearchResultsDto> subGroupQueryResult,
      Flux<GroupSearchResultsDto> subGroupAliasQueryResult) {

    subGroupQueryResult = SubGroupHelper.getSubGroupStatus(subGroupQueryResult, groupRepository);

    subGroupAliasQueryResult =
        SubGroupHelper.getSubGroupStatus(subGroupAliasQueryResult, groupRepository);

    return Flux.concat(subGroupQueryResult, subGroupAliasQueryResult).distinct();
  }

  public Mono<ServerResponse> findAllSubGroupSABankByBankName(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String bankName = request.pathVariable(GroupConstants.SABANK_NAME);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.findAllSubGroupSABankByBankName(subGroupId, accountDetailsId, bankName),
            SABank.class);
  }

  public Mono<ServerResponse> renewSubGroupAccountDetails(ServerRequest request) {

    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailsId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));

    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.renewSubGroupAccountDetails(
                subGroupId, accountDetailsId, GroupConstants.SUBGROUP_TYPE),
            AccountDetails.class);
  }

  public Mono<ServerResponse> getAccountDetails(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    final String accountDetailsTile =
        request.queryParam(GroupConstants.ACCOUNT_DETAILS_FIELDS).orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.getAccountDetails(subGroupId, accountDetailId, accountDetailsTile),
            AccountDetails.class);
  }

  public Mono<ServerResponse> getAccountDetailsList(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.getAccountDetailsList(subGroupId), AccountDetails.class);
  }

  public Mono<ServerResponse> getActiveAccountDetailsByGroupId(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.GROUP_ID));
    Flux<ActiveAccountDetailsDto> activeAccountDetails =
        this.subGroupService.getActiveAccountDetailsByGroupId(groupId);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(activeAccountDetails, ActiveAccountDetailsDto.class);
  }

  public Mono<ServerResponse> deleteSubGroupSABank(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long bankId = NumberUtils.toLong(request.pathVariable(GroupConstants.BANK_ID));

    Mono<SubGroup> response = this.subGroupService.removeBank(subGroupId, bankId);
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(response, SubGroup.class);
  }

  public Mono<ServerResponse> findActiveAccountDetailsBySubGroupId(ServerRequest request) {
    final Long subGroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.findActiveAccountDetailsBySubGroupId(subGroupId),
            GroupAccountDetailDto.class);
  }

  public Mono<ServerResponse> findBySubGroupName(ServerRequest request) {
    String subGroupName = request.queryParam("subGroupName").orElse("");
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.getSubGroupIds(subGroupName), SubGroupNameDto.class);
  }

  public Mono<ServerResponse> getBrokerAndContactDetails(ServerRequest request) {
    final Long groupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    final Long accountDetailId =
        NumberUtils.toLong(request.pathVariable(GroupConstants.ACCOUNT_DETAILS_ID));
    return this.subGroupService
        .findBrokerAndContactDetails(groupId, accountDetailId)
        .flatMap(
            brokerContacts ->
                ServerResponse.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(brokerContacts)));
  }

  public Mono<ServerResponse> findAllActiveVendorDetails(ServerRequest request) {
    final Long subgroupId = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            subGroupService.findAllActiveVendorDetailsBySubGroupId(subgroupId),
            VendorDetails.class);
  }

  public Mono<ServerResponse> getAddressDetailsByParentPathIds(ServerRequest request) {
    String parentPaths = request.queryParam("parentPathIds").orElse("");
    if (ObjectUtils.anyNotNull(parentPaths)) {
      return ServerResponse.ok()
          .contentType(MediaType.APPLICATION_JSON)
          .body(subGroupService.getAddressDetailsByParentPathIds(parentPaths), Address.class);
    }
    return ServerResponse.badRequest()
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            Flux.just(
                "Invalid request for fetching group/subgroup address details by parent path ids"),
            String.class);
  }

  public Mono<ServerResponse> findBankDetailsById(ServerRequest request) {
    final Long id = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.findBankDetailsById(id), BankHoursDto.class);
  }

  public Mono<ServerResponse> findSubGroupNameById(ServerRequest request) {
    final Long id = NumberUtils.toLong(request.pathVariable(GroupConstants.SUBGROUP_ID));
    return ServerResponse.ok()
        .contentType(MediaType.APPLICATION_JSON)
        .body(subGroupService.findSubGroupNameById(id), SubGroupNameDto.class);
  }
}
