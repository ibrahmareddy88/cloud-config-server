package com.anthem.eap.group.model;

import com.anthem.eap.model.employeeService.EmployeeServiceDelivery;
import java.util.List;
import lombok.Data;

@Data
public class EmployeeServiceDeliveryProviderViewModel extends EmployeeServiceDelivery {
  private List<ProviderLocationViewModel> providerLocations;
}
