package com.anthem.eap.group.dto;

import com.anthem.eap.model.accountProfile.AccountDetails;
import com.anthem.eap.model.group.Alert;
import com.anthem.eap.model.group.GroupSubgroupContact;
import com.anthem.eap.model.group.TerminationInfo;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupAccountDetailDto {

  private String name;
  private String id;
  private String groupId;
  private AccountDetails accountDetails;
  private List<Alert> alerts;
  private List<GroupSubgroupContact> contacts;
  private String callCenterCode;
  private TerminationInfo terminationList;
  private String status;
  private TerminationInfo termedList;
}
