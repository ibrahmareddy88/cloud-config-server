package com.anthem.eap.group.dto;

import com.anthem.eap.group.model.SubGroupTreeViewModel;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupSearchResultsHierarchyDto {
  private List<GroupSearchResultsDto> groupSearchResultsDtoList;
  private List<SubGroupTreeViewModel> subGroupTreeViewModelList;
}
