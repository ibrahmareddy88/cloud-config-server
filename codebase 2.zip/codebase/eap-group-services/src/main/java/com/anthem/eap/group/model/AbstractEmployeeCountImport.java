package com.anthem.eap.group.model;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsExclude;

@Getter
@Setter
public abstract class AbstractEmployeeCountImport {
  private String groupName;
  private String groupId;
  private String asOfDate;
  private String count;
  @EqualsExclude private String error;
}
