package com.anthem.eap.group.util;

import com.anthem.eap.group.constants.GroupConstants;
import com.anthem.eap.group.model.SubGroupTreeViewModel;
import com.anthem.eap.group.model.SubGroupUploadModel;
import com.anthem.eap.group.repository.GroupRepository;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.common.Address.Type;
import com.anthem.eap.model.common.Phone;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

public class SubGroupHelper {

  public static SubGroup pepareSubgroup(SubGroupUploadModel uploadModel) {
    String note =
        uploadModel.getContactLastName() != null
            ? uploadModel.getContactLastName()
            : "" + uploadModel.getContactLastName() != null
                ? uploadModel.getContactLastName()
                : "" + uploadModel.getOther() != null ? uploadModel.getOther() : "";
    SubGroup subgroup = new SubGroup();
    Address address = new Address();
    if (Objects.nonNull(uploadModel.getEapGroupID())) {
      subgroup.setGroupId(Long.valueOf(uploadModel.getEapGroupID()));
    }
    subgroup.setName(uploadModel.getEapSubgroupName());
    subgroup.setParentIdPath(uploadModel.getEapGroupID());
    subgroup.setParentNamePath(uploadModel.getEapGroupName());
    address.setCity(uploadModel.getCity());
    address.setStateCd(uploadModel.getState());
    address.setZip(uploadModel.getZip());
    if (StringUtils.isNoneEmpty(uploadModel.getContactPhone())) {
      Phone phone = new Phone();
      phone.setNumber(uploadModel.getContactPhone());
      phone.setExtension(uploadModel.getExt());
      address.setPhone(phone);
    }
    address.setStreet1(uploadModel.getAddress1());
    address.setStreet2(uploadModel.getAddress2());
    subgroup.setNote(note);
    address.setType(Type.HOME);
    subgroup.setAddresses(Arrays.asList(address));
    return subgroup;
  }

  public static void moveSubGroupMapper(SubGroupTreeViewModel moveSubGroup, SubGroup subgroup) {
    subgroup.setParentSubgroupId(moveSubGroup.getParentSubGroupId());
    subgroup.setParentNamePath(moveSubGroup.getParentNamePath());
    subgroup.setParentIdPath(moveSubGroup.getParentIdPath());
    subgroup.setLastModifiedBy("System");
    subgroup.setLastModifiedDate(ZonedDateTime.now());
  }

  public static List<SubGroup> setSequenceIds(List<SubGroup> subGroups, AtomicLong ids) {
    ZonedDateTime todayDate = ZonedDateTime.now();
    return subGroups.stream()
        .map(
            a -> {
              a.setId(Long.valueOf(ids.incrementAndGet()));
              a.setCreatedBy("System");
              a.setCreatedDate(todayDate);
              return a;
            })
        .collect(Collectors.toList());
  }

  public static Flux<GroupSearchResultsDto> getSubGroupStatus(
      Flux<GroupSearchResultsDto> subGroupAndAliasResult, GroupRepository groupRepository) {

    // subGroupAndAliasResult -> contains subGroup query and also sub group alias
    // results
    // accordingly send from input
    List<GroupSearchResultsDto> subGroupAndAliasResultList =
        subGroupAndAliasResult.collectList().share().block().stream()
            .filter(subGroups -> StringUtils.isNotEmpty(subGroups.getParentGroupId()))
            .collect(Collectors.toList());

    subGroupAndAliasResultList.stream()
        .forEach(
            subGroupsAndAlias -> {
              // hitting group status query with the help of subgroup's parentGroupId and
              // getting group status.
              Flux<GroupSearchResultsDto> groupStatusResult =
                  groupRepository
                      .findGroupStatus(
                          new Date(), Long.valueOf(subGroupsAndAlias.getParentGroupId()))
                      .subscribeOn(Schedulers.boundedElastic());

              Optional<GroupSearchResultsDto> groupDetails =
                  groupStatusResult.collectList().share().block().stream().findFirst();

              if (groupDetails.isPresent()) {
                String groupStatus = groupDetails.get().getStatus();
                subGroupsAndAlias.setParentGroupName(groupDetails.get().getName());

                // comparing with group status setting sub group status.
                switch (groupStatus) {
                  case GroupConstants.STATUS_INACTIVE:
                    {
                      subGroupsAndAlias.setStatus(GroupConstants.STATUS_INACTIVE);
                      break;
                    }
                  case GroupConstants.STATUS_CLOSED:
                    {
                      subGroupsAndAlias.setStatus(GroupConstants.STATUS_CLOSED);
                      break;
                    }
                }
              }
            });
    return Flux.fromIterable(subGroupAndAliasResultList);
  }
}
