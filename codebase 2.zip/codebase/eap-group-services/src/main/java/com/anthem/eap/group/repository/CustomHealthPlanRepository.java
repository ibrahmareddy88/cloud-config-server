package com.anthem.eap.group.repository;

import com.anthem.eap.model.group.HealthPlan;
import com.anthem.eap.model.group.dto.PageRequestDto;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface CustomHealthPlanRepository {

  public Mono<PageImpl<HealthPlan>> getHealthPlansByCriteria(
      PageRequestDto pageRequest, String sourceSystem);

  Flux<HealthPlan> fetchHealthPlans(PageRequestDto pageRequest, String sourceSystem);
}
