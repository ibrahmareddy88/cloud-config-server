package com.anthem.eap.group.model;

import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.group.Alias;
import com.anthem.eap.model.group.EmployeeCount;
import com.anthem.eap.model.group.TerminationInfo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubGroupViewModel {

  private Long id;

  private Long groupId;

  private String name;

  private String note;

  private String tin;

  private List<String> healthPlanIds;

  private Long parentSubgroupId;

  private String parentIdPath;

  private String parentNamePath;

  private List<Address> addresses;

  private List<Alias> aliasList;

  private List<EmployeeCount> employeeCountList;

  private List<TerminationInfo> terminationList;
}
