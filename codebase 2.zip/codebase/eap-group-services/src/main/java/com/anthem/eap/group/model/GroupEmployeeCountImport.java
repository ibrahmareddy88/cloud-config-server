package com.anthem.eap.group.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupEmployeeCountImport extends AbstractEmployeeCountImport {
  @Override
  public int hashCode() {
    return new HashCodeBuilder()
        .append(this.getGroupId())
        .append(this.getGroupName())
        .append(this.getAsOfDate())
        .append(this.getCount())
        .toHashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof GroupEmployeeCountImport)) {
      return false;
    }
    if (this == obj) {
      return true;
    }
    final GroupEmployeeCountImport otherObject = (GroupEmployeeCountImport) obj;
    return new EqualsBuilder()
        .append(this.getGroupId(), otherObject.getGroupId())
        .append(this.getGroupName(), otherObject.getGroupName())
        .append(this.getAsOfDate(), otherObject.getAsOfDate())
        .append(this.getCount(), otherObject.getCount())
        .isEquals();
  }
}
