package com.anthem.eap.group.model;

import java.util.List;
import lombok.Data;

@Data
public class GroupBanner {

  private String name;
  private String phoneNo;
  private Long eapAccountId;
  private String primaryAccountManagerName;
  private String product;
  private String sessionNumber;
  private List<String> healthPlanId;
  private String groupCode;
  private String programName;
  private String primaryWebLogin;
  private String path;
}
