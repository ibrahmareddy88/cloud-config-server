package com.anthem.eap.group.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubGroupEmployeeCountImport extends AbstractEmployeeCountImport {
  private String subgroupName;
  private String subGroupId;
}
