package com.anthem.eap.group.repository;

import com.anthem.eap.group.dto.ActiveVendorDetailsDTO;
import com.anthem.eap.group.dto.ContactTypeDto;
import com.anthem.eap.group.dto.GroupAccountDetailDto;
import com.anthem.eap.group.dto.GroupSubGroupContactDto;
import com.anthem.eap.group.repository.custom.SubGroupCustomRepo;
import com.anthem.eap.model.accountProfile.AccountService;
import com.anthem.eap.model.accountProfile.EmployerService;
import com.anthem.eap.model.accountProfile.SABank;
import com.anthem.eap.model.accountProfile.VendorDetails;
import com.anthem.eap.model.common.Address;
import com.anthem.eap.model.consultaton.dto.BankHoursDto;
import com.anthem.eap.model.group.dto.ActiveAccountDetailsDto;
import com.anthem.eap.model.group.dto.GroupSearchResultsDto;
import com.anthem.eap.model.group.subgroup.SubGroup;
import com.anthem.eap.model.group.subgroup.dto.SubGroupNameDto;
import java.util.Date;
import java.util.List;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface SubGroupRepository extends GroupMongoRepository<SubGroup>, SubGroupCustomRepo {

  @Aggregation(
      pipeline = {
        "{$addFields: {tempId: {$toString: '$_id' }}}",
        "{$match: {$or : [{'name':{$regex:?1,$options:'i'}}, {'healthPlanIds':{$regex:?1,$options:'i'}}, {'tempId':{$regex:?1,$options:'i'}}]}}",
        "{$project: {'id': 1,'name': 1, 'nameType': 'Sub Group','healthPlanId': {$reduce:{input: '$healthPlanIds',initialValue: '',"
            + "in:{$concat:['$$value',{$cond: {if: { $eq: [ '$$value', ''] }, then: '', else: ','}},'$$this']}}},"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'parentIdPath':'$parentIdPath',"
            + "'parentOrganisation':'$parentNamePath',"
            + "'parentGroupId': '$groupId',"
            + "'status' : { $switch: { "
            + "                    branches: [ "
            + "                          {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "               cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                     {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                       ] }, "
            + "                          then: 'Active' }, "
            + "                          {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }},[]]}}, 0] }, "
            + "                               ]  },{ "
            + "                              $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]}]} "
            + "                              }}, []]}}, 0] }] }]}, "
            + "                          then: 'InActive'},] "
            + "                   ,default: 'Closed' } }"
            + "}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findSubGroupsByKeyword(Date date, String searchVal);

  @Aggregation(
      pipeline = {
        "{$unwind: '$aliasList'}",
        "{$addFields: {tempId: {$toString: '$_id' }, aliasName: '$aliasList.alias'}}",
        "{$match: {'aliasName':{$regex:?1,$options:'i'}}}",
        "{$project: {'id': 1,'name': '$aliasName','lastModifiedDate': 1,'nameType': 'Alias','healthPlanId': { $arrayElemAt: [ '$healthPlanIds', 0 ] },'parentType': 'Subgroup',"
            + "'parentIdPath':'$parentIdPath',"
            + "'parentOrganisation':{ $concat: [ '$parentNamePath', ' > ', '$name' ] },"
            + "'parentGroupId': '$groupId',"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'status' : { $switch: { "
            + "                    branches: [ "
            + "                          {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "               cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                     {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                       ] }, "
            + "                          then: 'Active' }, "
            + "                          {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }},[]]}}, 0] }, "
            + "                               ]  },{ "
            + "                              $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]}]} "
            + "                              }}, []]}}, 0] }] }]}, "
            + "                          then: 'InActive'},] "
            + "                   ,default: 'Closed' } }"
            + "}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findAliasForSubGroupsByKeyword(Date date, String searchVal);

  public Flux<SubGroup> findByGroupId(Long id);

  Flux<SubGroup> findByGroupIdIn(List<Long> groupIds);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'accountServices': '$accountDetails.employerServices.accountServices'}}",
        "{$unwind: '$accountServices'}",
        "{$replaceRoot: { newRoot: '$accountServices'}}"
      })
  Flux<AccountService> findAllAccountServicesBySubGroupIdAndAccountDetailsId(
      Long id, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{$project: {'_id':0,'accountServices': '$accountDetails.employerServices.accountServices'}}",
        "{$unwind: '$accountServices'}",
        "{$replaceRoot: { newRoot: '$accountServices'}}",
        "{$match:{serviceType:?2}}"
      })
  Flux<AccountService> findAccountServicesByServiceType(
      Long id, Long accountDetailsId, String serviceType);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'saBank': '$accountDetails.employerServices.saBank'}}",
        "{$unwind: '$saBank'}",
        "{$replaceRoot: { newRoot: '$saBank'}}"
      })
  Flux<SABank> findAllSABankBySubGroupIdAndAccountDetailsId(Long id, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'benefitNotes': '$accountDetails.employerServices.benefitNotes'}}",
      })
  Mono<EmployerService> findEmployerNoteBySubGroupIdAndAccountDetailsId(
      Long subGroupId, Long accountDetailsId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{ $project: {'_id':0,'vendorDetails': '$accountDetails.vendorDetails'}}",
        "{$unwind: '$vendorDetails'}",
        "{$replaceRoot: { newRoot: '$vendorDetails'}}"
      })
  Flux<VendorDetails> findAllVendorDetails(Long groupId, Long accountDetailsId);

  Flux<SubGroup> findByIdIn(List<Long> id);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$unwind: '$accountDetails'}",
        "{$match:{'accountDetails._id':?1}}",
        "{$project: {'_id':0,'saBank': '$accountDetails.employerServices.saBank'}}",
        "{$unwind: '$saBank'}",
        "{$replaceRoot: { newRoot: '$saBank'}}",
        "{$match:{bankName:{$regex:'^?2$',$options:'i'}}}"
      })
  Flux<SABank> findSABankByBankName(Long id, Long accountDetailsId, String bankName);

  @Query(value = "{'groupId': ?0}", fields = "{'_id': 1, 'groupId':1,'contacts': 1, 'name': 1}")
  Flux<GroupSubGroupContactDto> findContactsByGroupId(Long groupId);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "  {$match: { groupId: ?0 }}",
        "  {$unwind: '$contacts'}",
        "  {$unwind: '$contacts.contactInfo'}",
        "  {$match: {'contacts.contactInfo.contactId': {'$in': ?1}}}",
        "  {$project: {'contactTypeId':'$contacts._id','_id':0,'contactId': '$contacts.contactInfo.contactId','effectiveDate': '$contacts.effectiveDate','terminationDate': '$contacts.terminationDate','groupName': '$name','contactType': '$contacts.contactType', 'subGroupId':'$_id', 'groupId' : '$groupId' }}"
      })
  Flux<ContactTypeDto> findContactTypes(Long groupId, List<Long> contactIds);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match: { groupId: ?0 }}",
        "{$lookup:{from : 'group',localField:'groupId',foreignField: '_id',as: 'groups'}}",
        "{$unwind: '$groups'}",
        "{$project: {'_id':1,'name':1,'groupId':1,'parentSubgroupId':1,'orgGroupName':'$groups.name','accountDetails':{$filter:{input: '$accountDetails',as: 'accountDetails',cond:{$and:[ {$gte : ['$$accountDetails.expiryDate', new Date()]},{$lte :['$$accountDetails.effectiveDate', new Date() ]}]}}},'orgaccountDetails':{$filter:{input: '$groups.accountDetails',as: 'orgccountDetails',cond:{$and:[ {$gte :['$$orgccountDetails.expiryDate', new Date()]},{$lte : ['$$orgccountDetails.effectiveDate', new Date() ]}]}}}}}",
        "{$project: {'_id':1,'name':1,'groupId':1,'parentSubgroupId':1,'orgGroupName':1,'activeProfile':{ $arrayElemAt: [ '$accountDetails', 0 ] },'orgactiveProfile':{ $arrayElemAt: [ '$orgaccountDetails', 0 ] }}}",
        "{$project: {'subGroupId':'$_id','subGroupName':'$name','groupId':1,'parentSubgroupId':1,'orgGroupName':1,'subGroupBrand':'$activeProfile.brand','subGroupEapWebSite': '$activeProfile.eapWebSite', 'subGroupNumberOfSessions':'$activeProfile.numberOfSessions','subGroupAccountId': '$activeProfile._id','organizationBrand':'$orgactiveProfile.brand','organizationEapWebSite': '$orgactiveProfile.eapWebSite', 'organizationNumberOfSessions':'$orgactiveProfile.numberOfSessions', 'organizationAccountId': '$orgactiveProfile._id'}}"
      })
  Flux<ActiveAccountDetailsDto> findActiveAccountDetailsByGroupId(Long groupId);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?1}}",
        "{$project: {'id': 1,'groupId': 1,'alerts': {$filter:{input:'$alertsLists', as:'alertsLists', cond:{$or: [{$and: [{$lte: ['$$alertsLists.effectiveDate._date', new Date()]},"
            + "{$gte: ['$$alertsLists.terminationDate._date',new Date()]}]},{$eq: [{$ifNull: ['$$alertsLists.effectiveDate._date',true]},true]},"
            + "{$eq: [{$ifNull: ['$$alertsLists.terminationDate._date',true]},true]}]}}},"
            + "'terminationList': { $arrayElemAt: [{$filter:{input:'$terminationList', as:'termination', cond:{$or: [{$and: [{$lte: ['$$termination.effectiveDate._date', new Date()]},"
            + "{$gte: ['$$termination.terminationDate._date',new Date()]}]}, {$and: [{$lte: ['$$termination.effectiveDate._date', new Date()]},"
            + "{$eq: [{$ifNull: ['$$termination.terminationDate._date',true]},true]}]} "
            + "]}}},0]}, 'contacts':1,'name': 1,"
            + "'accountDetails':{ $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails', "
            + "cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] },"
            + " 'status' : { $switch: { "
            + "                         branches: [ "
            + "   		          {case: {$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                          cond: {$and: [{$lt: ['$$termination.effectiveDate._date', new Date()]},"
            + "		{$ne:[{$ifNull : ['$$termination.terminationDate', true ]},true]},{$lt: ['$$termination.terminationDate._date',new Date()]}]}	}},[]]}}, 0] }, then: 'Termed'},"
            + "				{case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "            	  		 cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] } , then: 'N/A'}"
            + "						{case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "						  		 cond: {$and:[{$lt : ['$$acDetails.expiryDate', new Date() ]},{$lt : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] } , then: 'InActive'}, "
            + "						{case: {$eq: [{$ifNull: ['$accountDetails',true]},true]} , then: 'NoProfile'},"
            + "                   {case: { $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails',"
            + "						 cond: {$and:[{$gt : ['$$acDetails.expiryDate', new Date() ]},{$gt : ['$$acDetails.effectiveDate', new Date()]}]} }}, 0 ] } , then: 'Future'}]"
            + "              ,default: 'N/A' } }, "
            + "   'termedList': { $arrayElemAt: [{$filter:{input:'$terminationList', as:'termination', cond:{$and: [{$lt: ['$$termination.effectiveDate._date', new Date()]},"
            + "					{$ne:[{$ifNull : ['$$termination.terminationDate', true ]},true]}, {$lt: ['$$termination.terminationDate._date',new Date()]}]}"
            + "			}},0]}"
            + "  }}"
      })
  Flux<GroupAccountDetailDto> findActiveAccountDetailsBySubGroupId(Date date, Long id);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$project: {'_id': 1,'accountDetails':{$ifNull: [{ $arrayElemAt: [ {$filter: {input: '$accountDetails', as: 'acDetails', "
            + "cond: {$and:[{$gte : ['$$acDetails.expiryDate', new Date() ]},{$lte : ['$$acDetails.effectiveDate', new Date()]}]}}}, 0 ] }, {}]}}}",
        "{$replaceRoot: { newRoot: '$accountDetails'}}",
        "{$project: {'accountId': '$_id','vendorDetails': {$ifNull: [{$filter: {input: '$vendorDetails', as: 'vendor', "
            + "cond: {$or : [{$eq: ['$$vendor.active',true]}, "
            + "{$and:[{$gte : ['$$vendor.endDate._date', new Date() ]},{$lte : ['$$vendor.startDate._date', new Date()]}]}]}}}, []]}}}",
        "{$unwind: '$vendorDetails'}",
        "{$lookup:"
            + "{"
            + "  from: 'codes',"
            + "   let: { vednor_type: '$vendorDetails.vendorType' },"
            + "  pipeline: ["
            + "     { $match: { '_id': 'vendorType' } },"
            + "     { $project: { _id: 0, 'codevals': { "
            + "         $arrayElemAt : ["
            + "         {$filter: { input: '$values', as: 'value', "
            + "         cond: {$eq: ['$$value.code', '$$vednor_type']} }}, 0]"
            + "         } } },"
            + "     { $replaceRoot: { newRoot: '$codevals' } },"
            + "  ],"
            + "  as: 'codevalues'"
            + "}}",
        "{$project: {'accountId' :'$accountId', 'id': '$vendorDetails._id','name':'$vendorDetails.name', 'phone':'$vendorDetails.phone', 'instruction' :'$vendorDetails.instruction',  'vendorType' : {$arrayElemAt:['$codevalues.label',0]}}}",
        "{ $sort : { vendorType : 1, name : 1 } }"
      })
  Flux<ActiveVendorDetailsDTO> findAllActiveVendorDetails(Long groupId);

  @Aggregation(pipeline = {"{$match:{_id:?0}}", "{$project: {'groupId': 1}}"})
  Flux<Long> findGroupIdById(Long id);

  @Aggregation(
      pipeline = {
        "{$addFields: {tempId: {$toString: '$_id' }}}",
        "{$match: {$or : [{'tempId':?0}]}}",
        "{$project: {'id': 1,'name': 1, 'nameType': 'Sub Group','healthPlanId': {$reduce:{input: '$healthPlanIds',initialValue: '',"
            + "in:{$concat:['$$value',{$cond: {if: { $eq: [ '$$value', ''] }, then: '', else: ','}},'$$this']}}},"
            + "'addressName': { $arrayElemAt: [ '$addresses.name', 0 ] }, 'address': { $arrayElemAt: [ '$addresses', 0 ] },"
            + "'parentIdPath':'$parentIdPath',"
            + "'parentOrganisation':'$parentNamePath',"
            + "'parentGroupId': '$groupId',"
            + "'status' : { $switch: { "
            + "                    branches: [ "
            + "                          {case: {$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "               cond: {$and:[{$lte : ['$$termination.effectiveDate._date', new Date() ]},{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                     {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]} ]}}},[]]}}, 0] }, "
            + "                       ] }, "
            + "                          then: 'Active' }, "
            + "                          {case: {$or:[{$and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]},{$gt : ['$$termination.effectiveDate._date', new Date() ]} ]} "
            + "                              }},[]]}}, 0] }, "
            + "                               ]  },{ "
            + "                              $and: [{$gt : [{$size : {$ifNull:[{$filter: {input: '$terminationList', as: 'termination', "
            + "                              cond: {$and:[{$or : [{$gte : ['$$termination.terminationDate._date', new Date() ]}, "
            + "                              {$eq:[{$ifNull : ['$$termination.terminationDate', true ]},true]}]}]} "
            + "                              }}, []]}}, 0] }] }]}, "
            + "                          then: 'InActive'},] "
            + "                   ,default: 'Closed' } }"
            + "}}",
        "{$sort: {'lastModifiedDate': -1}}"
      })
  Flux<GroupSearchResultsDto> findSubGroupStatus(String id);

  @Query(value = " { healthPlanIds: { $elemMatch: { $eq: '?0'} } }", fields = "{'groupId': 1}")
  Flux<SubGroup> findMatchingGroupByHealthPlanId(String healhplanId);

  Flux<SubGroupNameDto> findByName(String name);

  @Aggregation(
      pipeline = {
        "{$match: { '_id': {'$in': ?0}}}",
        "{$unwind: { path: '$addresses', preserveNullAndEmptyArrays: false }}",
        "{$match: {$or: [{ 'addresses.city': {'$nin': [null, '']}}, { 'addresses.zip': {'$nin': [null, '']}}, { 'addresses.stateCd': {'$nin': [null, '']}}]}}", // address -> city or state or zip not empty
        "{$sort: {'_id':-1}}", // sort by id
        "{$limit : 1 }", // limit 1
        "{$replaceRoot: { newRoot: '$addresses'}}",
      })
  Mono<Address> getAddressDetailsByParentIds(List<Long> ids);

  @org.springframework.data.mongodb.repository.Aggregation(
      pipeline = {
        "{$match:{'_id':?0}}",
        "{$lookup:{from:'group', localField:'groupId', foreignField:'_id', as: 'groups'}}",
        "{$unwind: '$accountDetails'}",
        "{$sort: {'accountDetails.createdDate': -1}}",
        "{$limit: 1}",
        "{$lookup:{from:'employeeServiceDelivery', localField:'accountDetails._id', foreignField:'accountId', as: 'serviceDetails'}}",
        "{$unwind: '$groups'}",
        "{$project: {'groupName':'$groups.name','parentNamePath':{ $concat: [ '$parentNamePath', ' > ', '$name'] },'groupId':1,'address':{ $arrayElemAt: [ '$addresses', 0 ] },'serviceDeliveries':'$serviceDetails', 'employerServices':{$cond: [{$and:[{$gte : ['$accountDetails.expiryDate', new Date()]},{$lte : ['$accountDetails.effectiveDate', new Date()]}]}, '$accountDetails.employerServices', {}]}}}",
      })
  public Mono<BankHoursDto> findBankDetailsById(Long id);

  @Aggregation(
      pipeline = {
        "{$match:{_id:?0}}",
        "{$project: {'name':'$name','id':'$_id'}}",
      })
  public Mono<SubGroupNameDto> findSubGroupNameById(Long id);
}
