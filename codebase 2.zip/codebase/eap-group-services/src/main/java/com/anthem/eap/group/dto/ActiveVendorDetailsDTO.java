package com.anthem.eap.group.dto;

import com.anthem.eap.model.common.Phone;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ActiveVendorDetailsDTO {
  private String vendorType;
  private String name;
  private Phone phone;
  private String instruction;
  private Long id;
  private Long accountId;
}
