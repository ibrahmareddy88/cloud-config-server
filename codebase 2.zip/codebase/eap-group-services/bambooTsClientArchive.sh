#!/bin/bash
# Copyright Anthem 2021
# Author: Jeffrey Blayney
#
# Script should be run after generate step.
# requires arg: -p <client-folder-name>
#
# from https://confluence.anthem.com/pages/viewpage.action?spaceKey=CLMTools&title=NPM+package+deployment+using+bamboo

set -euo pipefail

echo "NOTE: This script can only be run from Bamboo."

while getopts p: flag
do
    case "${flag}" in
        p) clientpath=${OPTARG};;
    esac
done
echo "Typescript Path: $clientpath";

if test -z "$clientpath" 
then
      echo "\$clientpath is empty, you must specify the folder name of the generated ts client with the -p flag"
      exit 1
fi

cd $clientpath
pwd

# config setup
git config --global url."https://".insteadOf git://
git config --global http.sslverify false
npm config set strict-ssl false
echo "BUILD STAGE 1 Complete, (npm vars setup)"
echo "FINAL BUILD STAGE - UPLOAD ANGULAR CLIENT TO JFROG"

echo "BUILD STEP NPMRC RUNNING:"

curl -o .npmrc -u$bamboo_artifactory_override_resolver_username:$bamboo_artifactory_override_resolver_password -k "https://artifactory.anthem.com/artifactory/api/npm/npm-release/auth/anthem"

echo "NPMRC CLONED SUCCESSFULLY:"
cat .npmrc

echo "RUNNING NPM INSTALL AND BUILD"

npm install
npm install typescript@4.3.5
npm run build
cd dist
npm pack
cd ..

# https://artifactory.anthem.com:443/artifactory/npm-snapshot/

# from: https://confluence.anthem.com/pages/viewpage.action?spaceKey=CLMTools&title=NPM+package+deployment+using+bamboo

curl -o .npmrc -u$bamboo_artifactory_override_resolver_username:$bamboo_artifactory_override_resolver_password -k "https://artifactory.anthem.com/artifactory/api/npm/npm-snapshot/auth/anthem"

echo "npmrc output from Anthem's JFrog Artifactory:"
cat .npmrc

#command below will fail if the version already exists. Fail gracefully.
#developers will have to know to increment the version to generate a new client in npm.
npm publish || true
