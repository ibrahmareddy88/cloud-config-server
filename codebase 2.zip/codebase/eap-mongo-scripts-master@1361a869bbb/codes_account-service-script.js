
db.codes.remove({
    "_id": {
        $in: [ "serviceType", "ffsType"]
    }
})
db.codes.insert([{
    "_id": "serviceType",
    "label": "Service Type",
    "description": "Service Type",
    "module": "accounts",
    "values": [
        {
            "code": "CIR_FACILITATION",
            "label": "CIR Facilitation",
            "description": null,
            "isActive": true
        },
        {
            "code": "EAP_OTHER",
            "label": "EAP - Other",
            "description": null,
            "isActive": true
        },
        {
            "code": "EMPLOYEE_ORIENTATION",
            "label": "Employee Orientation",
            "description": null,
            "isActive": true
        },
        {
            "code": "HEALTH_FAIR",
            "label": "Health Fair",
            "description": null,
            "isActive": true
        },
        {
            "code": "SUPERVISOR_TRAINING_ONSITE",
            "label": "Supervisor Training - Onsite",
            "description": null,
            "isActive": true
        },
        {
            "code": "SUPERVISOR_TRAINING_WEBINAR",
            "label": "Supervisor Training - Webinar",
            "description": null,
            "isActive": true
        },
        {
            "code": "TRAINING_ONSITE",
            "label": "Training - Onsite",
            "description": null,
            "isActive": true
        },
        {
            "code": "TRAINING_WEBINAR",
            "label": "Training - Webinar",
            "description": null,
            "isActive": true
        },
        {
            "code": "TRAVEL",
            "label": "Travel",
            "description": null,
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "ffsType",
    "label": "FFS Type",
    "description": "FFS Type",
    "module": "accounts",
    "values": [
        {
            "code": "PER_HOUR",
            "label": "per Hour",
            "description": null,
            "isActive": true
        },
        {
            "code": "PER_SESSION",
            "label": "per Session",
            "description": null,
            "isActive": true
        },
        {
            "code": "N/A",
            "label": "N/A",
            "description": null,
            "isActive": true
        }
    ]
}]);