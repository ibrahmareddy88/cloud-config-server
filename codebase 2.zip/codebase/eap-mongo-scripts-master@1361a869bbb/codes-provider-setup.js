/**
 * run script in DB for Provider setup into codes collection
*/

db.codes.remove({
  "_id": {
    $in: ["providerType", "providerGender", "providerRecruitmentStatus", "urgency", "methodSent", "preferenceSetting", "providerState", "practiceType", "acceptingNewPatients", "ethnicOrigin", "language"]
  }
})

db.getCollection('codes').insert([{
  "_id": "providerType",
  "label": "Provider Type",
  "description": "Provider Type",
  "module": "provider",
  "values": [
    {
      "code": "ALL",
      "label": "All",
      "description": "",
      "isActive": true
    },
    {
      "code": "NETWORK_PARTICIPATING",
      "label": "Network Participating",
      "description": "",
      "isActive": true
    },
    {
      "code": "SINGLE_CASE",
      "label": "Single Case",
      "description": "",
      "isActive": true
    },
    {
      "code": "RECRUIT_PENDING",
      "label": "Recruit Pending",
      "description": "",
      "isActive": true
    },
    {
      "code": "REMIT_TO",
      "label": "Remit to",
      "description": "",
      "isActive": true
    },
    {
      "code": "ONSITE_PROVIDER",
      "label": "Onsite Provider",
      "description": "",
      "isActive": true
    },
    {
      "code": "CORE",
      "label": "Core",
      "description": "",
      "isActive": true
    },
    {
      "code": "VENDOR",
      "label": "Vendor",
      "description": "",
      "isActive": true
    },
    {
      "code": "INTERNAL_ASSOCIATE",
      "label": "Internal Associate",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "providerGender",
  "label": "Gender",
  "description": "Gender",
  "module": "provider",
  "values": [
    {
      "code": "MALE",
      "label": "Male",
      "description": "",
      "isActive": true
    },
    {
      "code": "FEMALE",
      "label": "Female",
      "description": "",
      "isActive": true
    },
    {
      "code": "NON_BINARY",
      "label": "Non-Binary",
      "description": "",
      "isActive": true
    },
    {
      "code": "UNDECLARED",
      "label": "Undeclared",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "providerRecruitmentStatus",
  "label": "Provider Recruitment status",
  "description": "Provider Recruitment status",
  "module": "provider",
  "values": [
    {
      "code": "INTERESTED",
      "label": "Interested",
      "description": "",
      "isActive": true
    },
    {
      "code": "APPLICATION_SENT",
      "label": "Application sent",
      "description": "",
      "isActive": true
    },
    {
      "code": "BEING_REVIEWED_OR_PROCESSED",
      "label": "Being Reviewed or Processed",
      "description": "",
      "isActive": true
    },
    {
      "code": "DENIED",
      "label": "Denied",
      "description": "",
      "isActive": true
    },
    {
      "code": "CONTRACTED",
      "label": "Contracted",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "urgency",
  "label": "Urgency",
  "description": "Urgency",
  "module": "provider",
  "values": [
    {
      "code": "NORMAL",
      "label": "Normal",
      "description": "",
      "isActive": true
    },
    {
      "code": "RAPID",
      "label": "Rapid",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "methodSent",
  "label": "Method Sent",
  "description": "Method Sent",
  "module": "provider",
  "values": [
    {
      "code": "FAX",
      "label": "Fax",
      "description": "",
      "isActive": true
    },
    {
      "code": "E_MAIL",
      "label": "E-Mail",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "preferenceSetting",
  "label": "Preference Setting",
  "description": "Preference Setting",
  "module": "provider",
  "values": [
    {
      "code": "EMAIL",
      "label": "Email",
      "description": "",
      "isActive": true
    },
    {
      "code": "FAX",
      "label": "Fax",
      "description": "",
      "isActive": true
    }
  ]
}])

db.codes.insert([{
  "_id": "providerState",
  "label": "State",
  "description": "State",
  "module": "accounts",
  "values": [
      {
          "code": "AL",
          "label": "Alabama",
          "isActive": true
      },
      {
          "code": "AK",
          "label": "Alaska",
          "isActive": true
      },

      {
          "code": "AZ",
          "label": "Arizona",
          "isActive": true
      },
      {
          "code": "AR",
          "label": "Arkansas",
          "isActive": true
      },
      {
          "code": "AS",
          "label": "American Samoa",
          "isActive": true
      },
      {
          "code": "CA",
          "label": "California",
          "isActive": true
      },
      {
          "code": "CO",
          "label": "Colorado",
          "isActive": true
      },
      {
          "code": "CT",
          "label": "Connecticut",
          "isActive": true
      },
      {
          "code": "DE",
          "label": "Delaware",
          "isActive": true
      },
      {
          "code": "DC",
          "label": "District Of Columbia",
          "isActive": true
      },
      {
          "code": "FL",
          "label": "Florida",
          "isActive": true
      },
      {
          "code": "GA",
          "label": "Georgia",
          "isActive": true
      },
      {
          "code": "GU",
          "label": "Guam",
          "isActive": true
      },
      {
          "code": "HI",
          "label": "Hawaii",
          "isActive": true
      },
      {
          "code": "ID",
          "label": "Idaho",
          "isActive": true
      },
      {
          "code": "IL",
          "label": "Illinois",
          "isActive": true
      },
      {
          "code": "IN",
          "label": "Indiana",
          "isActive": true
      },
      {
          "code": "IA",
          "label": "Iowa",
          "isActive": true
      },
      {
          "code": "KS",
          "label": "Kansas",
          "isActive": true
      },

      {
          "code": "KY",
          "label": "Kentucky",
          "isActive": true
      },
      {
          "code": "LA",
          "label": "Louisiana",
          "isActive": true
      },
      {
          "code": "ME",
          "label": "Maine",
          "isActive": true
      },
      {
          "code": "MD",
          "label": "Maryland",
          "isActive": true
      },
      {
          "code": "MA",
          "label": "Massachusetts",
          "isActive": true
      },
      {
          "code": "MI",
          "label": "Michigan",
          "isActive": true
      },
      {
          "code": "MN",
          "label": "Minnesota",
          "isActive": true
      },
      {
          "code": "MS",
          "label": "Mississippi",
          "isActive": true
      },
      {
          "code": "MO",
          "label": "Missouri",
          "isActive": true
      },
      {
          "code": "MT",
          "label": "Montana",
          "isActive": true
      },
      {
          "code": "NE",
          "label": "Nebraska",
          "isActive": true
      },
      {
          "code": "NV",
          "label": "Nevada",
          "isActive": true
      },
      {
          "code": "NH",
          "label": "New Hampshire",
          "isActive": true
      },
      {
          "code": "NJ",
          "label": "New Jersey",
          "isActive": true
      },
      {
          "code": "NM",
          "label": "New Mexico",
          "isActive": true
      },
      {
          "code": "NY",
          "label": "New York",
          "isActive": true
      },
      {
          "code": "NV",
          "label": "North Carolina",
          "isActive": true
      },
      {
          "code": "ND",
          "label": "North Dakota",
          "isActive": true
      },
      {
          "code": "NI",
          "label": "Northern Mariana Is",
          "isActive": true
      },
      {
          "code": "OH",
          "label": "Ohio",
          "isActive": true
      },
      {
          "code": "OK",
          "label": "Oklahoma",
          "isActive": true
      },
      {
          "code": "OR",
          "label": "Oregon",
          "isActive": true
      },
      {
          "code": "PA",
          "label": "Pennsylvania",
          "isActive": true
      },
      {
          "code": "PR",
          "label": "Puetro Rico",
          "isActive": true
      },
      {
          "code": "RI",
          "label": "Rhode Island",
          "isActive": true
      },
      {
          "code": "SC",
          "label": "South Carolina",
          "isActive": true
      },
      {
          "code": "SD",
          "label": "South Dakota",
          "isActive": true
      },
      {
          "code": "TN",
          "label": "Tennessee",
          "isActive": true
      },
      {
          "code": "TX",
          "label": "Texas",
          "isActive": true
      },
      {
          "code": "UT",
          "label": "Utah",
          "isActive": true
      },
      {
          "code": "VT",
          "label": "Vermont",
          "isActive": true
      },
      {
          "code": "VI",
          "label": "Virgian Islands",
          "isActive": true
      },
      {
          "code": "VA",
          "label": "Virginia",
          "isActive": true
      },
      {
          "code": "WA",
          "label": "Washington",
          "isActive": true
      },
      {
          "code": "WV",
          "label": "West Virginia",
          "isActive": true
      },
      {
          "code": "WI",
          "label": "Wisconsin",
          "isActive": true
      },
      {
          "code": "WY",
          "label": "Wyoming",
          "isActive": true
      },
  ]
}])

db.codes.insert([{
  "_id": "practiceType",
  "label": "Practice Type",
  "description": "Practice Type",
  "module": "provider",
  "values": [
    {
      "code": "INDIVIDUAL",
      "label": "Individual",
      "description": "",
      "isActive": true
    }
  ]
}]);

db.codes.insert([{
  "_id": "acceptingNewPatients",
  "label": "Accepting New Patients",
  "description": "Accepting New Patients",
  "module": "provider",
  "values": [
    {
      "code": "YES",
      "label": "Yes",
      "description": "",
      "isActive": true
    },
    {
      "code": "NO",
      "label": "No",
      "description": "",
      "isActive": true
    }
  ]
}]);

db.codes.insert([{
  "_id": "ethnicOrigin",
  "label": "Ethnic Origin",
  "description": "Ethnic Origin",
  "module": "Provider",
  "values": [{
      "code": "AFRICAN_AMERICAN",
      "label": "African-American",
      "description": "",
      "isActive": true
    },
    {
      "code": "ASIAN_INDIAN",
      "label": "Asian Indian",
      "description": "",
      "isActive": true
    },
    {
      "code": "NON_HISPANIC",
      "label": "White, Non-Hispanic",
      "description": "",
      "isActive": true
    },
    {
      "code": "HISPANIC",
      "label": "Hispanic",
      "description": "",
      "isActive": true
    },
    {
      "code": "NATIVE_AMERICAN",
      "label": "Native American",
      "description": "",
      "isActive": true
    },
    {
      "code": "PACIFIC_ASIAN",
      "label": "Pacific-Asian",
      "description": "",
      "isActive": true
    },
  ]
}]);

db.codes.insert([{
  "_id": "language",
  "label": "Language",
  "description": "Language",
  "module": "Provider",
  "values": [{
      "code": "AFRIKAANS",
      "label": "Afrikaans",
      "description": "",
      "isActive": true
    },
    {
      "code": "ALBANIAN",
      "label": "Albanian",
      "description": "",
      "isActive": true
    },
    {
      "code": "AMHARIC",
      "label": "Amharic",
      "description": "",
      "isActive": true
    },
    {
      "code": "ARABIC",
      "label": "Arabic",
      "description": "",
      "isActive": true
    },
    {
      "code": "ARMENIAN",
      "label": "Armenian",
      "description": "",
      "isActive": true
    },
    {
      "code": "AZARI",
      "label": "Azari",
      "description": "",
      "isActive": true
    },
    {
      "code": "BENGALI",
      "label": "Bengali",
      "description": "",
      "isActive": true
    },
    {
      "code": "BROHI",
      "label": "Brohi",
      "description": "",
      "isActive": true
    },
    {
      "code": "BULGARIAN",
      "label": "Bulgarian",
      "description": "",
      "isActive": true
    },
    {
      "code": "BURMESE",
      "label": "Burmese",
      "description": "",
      "isActive": true
    },
    {
      "code": "CAMBODIAN",
      "label": "Cambodian",
      "description": "",
      "isActive": true
    },
    {
      "code": "CANTONESE",
      "label": "Cantonese",
      "description": "",
      "isActive": true
    },
    {
      "code": "CEBUANO",
      "label": "Cebuano",
      "description": "",
      "isActive": true
    },
    {
      "code": "CROATIAN",
      "label": "Croatian",
      "description": "",
      "isActive": true
    },
    {
      "code": "CZECH",
      "label": "Czech",
      "description": "",
      "isActive": true
    },
    {
      "code": "DANISH",
      "label": "Danish",
      "description": "",
      "isActive": true
    },
    {
      "code": "DUTCH",
      "label": "Dutch",
      "description": "",
      "isActive": true
    },
    {
      "code": "EGYPTIAN",
      "label": "Egyptian",
      "description": "",
      "isActive": true
    },
    {
      "code": "ENGLISH",
      "label": "English",
      "description": "",
      "isActive": true
    },
    {
      "code": "ETHIOPIAN",
      "label": "Ethiopian",
      "description": "",
      "isActive": true
    },
    {
      "code": "FILIPINO",
      "label": "Filipino",
      "description": "",
      "isActive": true
    },
    {
      "code": "FINNISH",
      "label": "Finnish",
      "description": "",
      "isActive": true
    },
    {
      "code": "FLEMISH",
      "label": "Flemish",
      "description": "",
      "isActive": true
    },
    {
      "code": "FRENCH",
      "label": "French",
      "description": "",
      "isActive": true
    },
    {
      "code": "GAELIC",
      "label": "Gaelic",
      "description": "",
      "isActive": true
    },
    {
      "code": "GERMAN",
      "label": "German",
      "description": "",
      "isActive": true
    },
    {
      "code": "GHANIAN",
      "label": "Ghanian",
      "description": "",
      "isActive": true
    },
    {
      "code": "GREEK",
      "label": "Greek",
      "description": "",
      "isActive": true
    },
    {
      "code": "GUJARATI",
      "label": "Gujarati",
      "description": "",
      "isActive": true
    },
    {
      "code": "HAITIANCREOLE",
      "label": "HaitianCreole",
      "description": "",
      "isActive": true
    },
    {
      "code": "HAWAIIAN",
      "label": "Hawaiian",
      "description": "",
      "isActive": true
    },
    {
      "code": "HEBREW",
      "label": "Hebrew",
      "description": "",
      "isActive": true
    },
    {
      "code": "HMONG",
      "label": "Hmong",
      "description": "",
      "isActive": true
    },
    {
      "code": "HUNGARIAN",
      "label": "Hungarian",
      "description": "",
      "isActive": true
    },
    {
      "code": "IGBO",
      "label": "Igbo",
      "description": "",
      "isActive": true
    },
    {
      "code": "ICELANDIC",
      "label": "Icelandic",
      "description": "",
      "isActive": true
    },
    {
      "code": "INDIAN_HINDI",
      "label": "Indian/Hindi",
      "description": "",
      "isActive": true
    },
    {
      "code": "INDONESIAN",
      "label": "Indonesian",
      "description": "",
      "isActive": true
    },
    {
      "code": "IRANIAN",
      "label": "Iranian",
      "description": "",
      "isActive": true
    },
    {
      "code": "ITALIAN",
      "label": "Italian",
      "description": "",
      "isActive": true
    },
    {
      "code": "JAPANESE",
      "label": "Japanese",
      "description": "",
      "isActive": true
    },
    {
      "code": "KANNADA",
      "label": "Kannada",
      "description": "",
      "isActive": true
    },
    {
      "code": "KOREAN",
      "label": "Korean",
      "description": "",
      "isActive": true
    },
    {
      "code": "LAOTIAN",
      "label": "Laotian",
      "description": "",
      "isActive": true
    },
    {
      "code": "LATVIAN",
      "label": "Latvian",
      "description": "",
      "isActive": true
    },
    {
      "code": "LEBANESE",
      "label": "Lebanese",
      "description": "",
      "isActive": true
    },
    {
      "code": "LITHUANIAN",
      "label": "Lithuanian",
      "description": "",
      "isActive": true
    },
    {
      "code": "MALAYALAM",
      "label": "Malayalam",
      "description": "",
      "isActive": true
    },
    {
      "code": "MANDARIN",
      "label": "Mandarin",
      "description": "",
      "isActive": true
    },
    {
      "code": "MANKON",
      "label": "Mankon",
      "description": "",
      "isActive": true
    },
    {
      "code": "MARATHI",
      "label": "Marathi",
      "description": "",
      "isActive": true
    },
    {
      "code": "NIGERIAN",
      "label": "Nigerian",
      "description": "",
      "isActive": true
    },
    {
      "code": "NORWEGIAN",
      "label": "Norwegian",
      "description": "",
      "isActive": true
    },
    {
      "code": "ORIYA",
      "label": "Oriya",
      "description": "",
      "isActive": true
    },
    {
      "code": "PAKISTANI",
      "label": "Pakistani",
      "description": "",
      "isActive": true
    },
    {
      "code": "PERSIAN_FARSI",
      "label": "Persian_Farsi",
      "description": "",
      "isActive": true
    },
    {
      "code": "POLISH",
      "label": "Polish",
      "description": "",
      "isActive": true
    },
    {
      "code": "PORTUGUESE",
      "label": "Portuguese",
      "description": "",
      "isActive": true
    },
    {
      "code": "PUNJABI",
      "label": "Punjabi",
      "description": "",
      "isActive": true
    },
    {
      "code": "PASHTO",
      "label": "Pashto",
      "description": "",
      "isActive": true
    },
    {
      "code": "RUMANIAN",
      "label": "Rumanian",
      "description": "",
      "isActive": true
    },
    {
      "code": "RUSSIAN",
      "label": "Russian",
      "description": "",
      "isActive": true
    },
    {
      "code": "SAMOAN",
      "label": "Samoan",
      "description": "",
      "isActive": true
    },
    {
      "code": "SERBO_CROATIAN",
      "label": "Serbo-Croatian",
      "description": "",
      "isActive": true
    },
    {
      "code": "SIGN_LANGUAGE",
      "label": "Sign Language",
      "description": "",
      "isActive": true
    },
    {
      "code": "SINHALA",
      "label": "Sinhala",
      "description": "",
      "isActive": true
    },
    {
      "code": "SOMALI",
      "label": "Somali",
      "description": "",
      "isActive": true
    },
    {
      "code": "SPANISH",
      "label": "Spanish",
      "description": "",
      "isActive": true
    },
    {
      "code": "SRANAN",
      "label": "Sranan",
      "description": "",
      "isActive": true
    },
    {
      "code": "SWAHILI",
      "label": "Swahili",
      "description": "",
      "isActive": true
    },
    {
      "code": "SWEDISH",
      "label": "Swedish",
      "description": "",
      "isActive": true
    },
    {
      "code": "TAGALOG",
      "label": "Tagalog",
      "description": "",
      "isActive": true
    },
    {
      "code": "TAIWANESE",
      "label": "Taiwanese",
      "description": "",
      "isActive": true
    },
    {
      "code": "TAMIL",
      "label": "Tamil",
      "description": "",
      "isActive": true
    },
    {
      "code": "TELUGU",
      "label": "Telugu",
      "description": "",
      "isActive": true
    },
    {
      "code": "THAI",
      "label": "Thai",
      "description": "",
      "isActive": true
    },
    {
      "code": "TURKISH",
      "label": "Turkish",
      "description": "",
      "isActive": true
    },
    {
      "code": "UKRAINIAN",
      "label": "Ukrainian",
      "description": "",
      "isActive": true
    },
    {
      "code": "URDU",
      "label": "Urdu",
      "description": "",
      "isActive": true
    },
    {
      "code": "VIETNAMESE",
      "label": "Vietnamese",
      "description": "",
      "isActive": true
    },
    {
      "code": "YIDDISH",
      "label": "Yiddish",
      "description": "",
      "isActive": true
    },
    {
      "code": "YURUBA",
      "label": "Yuruba",
      "description": "",
      "isActive": true
    },
    {
      "code": "YUGOSLAVIAN",
      "label": "Yugoslavian",
      "description": "",
      "isActive": true
    }
  ]
}]);