/**
* run script in DB for account profile into codes collection
*/
db.codes.remove({
    "_id": {
        $in: ["product", "productType", "plan", "brand", "episodeDuration", "dcbtEligibility", "renewalOptions", "dcbtPortal", "eBlastPromo", "eblastPromotions", "standalone", "eapWebSite", "eapPhone", "followUpCallRequired", "programName", "liveHealthOnlineElig", "engage", "dotSAPPayOpt", "workLife", "legalFinancial", "smokingCessation", "webRegistration", "asstProvSearchReq", "assistedProviderSearchRequired", "totalHealthTotalYou", "sydneyPreferred", "numberOfSessions", "eligibilityFor", "employeeKnownAs", "memberCenter"]
    }
})

db.codes.insert([{
    "_id": "product",
    "label": "Product",
    "description": "Product",
    "module": "accounts",
    "additionalDataLabel": "Product Type",
    "additionalDataSource": "productType",
    "values": [
        {
            "code": "PRODUCT_BASIC",
            "label": "Basic",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "PRODUCT_BASIC_CUSTOM",
            "label": "Basic-Custom",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "BASIC_BHA",
            "label": "Basic & BHA",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "BASIC_BHR",
            "label": "Basic & BHR",
            "description": "Behavioral Health Access",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "BHA_EMOTIONAL_WELLBEING",
            "label": "Basic & Emotional Wellbeing Resources",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "ENHANCED",
            "label": "Enhanced",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "ENHANCED_CUSTOM",
            "label": "Enhanced-Custom",
            "description": "",
            "additionalData": ["BSVEA"],
            "isActive": true
        },
        {
            "code": "ENHANCED_BHA",
            "label": "Enhanced & BHA",
            "description": "",
            "additionalData": ["BSVCC"],
            "isActive": true
        },
        {
            "code": "ENHANCED_BHR",
            "label": "Enhanced & BHR",
            "description": "",
            "additionalData": ["BSVCC"],
            "isActive": true
        },
        {
            "code": "FFS_SESSIONS",
            "label": "FFS Sessions",
            "description": "",
            "additionalData": [],
            "isActive": true
        },
        {
            "code": "INTERNATIONAL",
            "label": "INTERNATIONAL",
            "description": "",
            "additionalData": [],
            "isActive": true
        },
        {
            "code": "ONLINE_ONLY",
            "label": "Online Only",
            "description": "",
            "additionalData": ["BSEAT"],
            "isActive": true
        },
        {
            "code": "SPECIAL_CIRCUMSTANCES",
            "label": "Special Circumstances",
            "description": "",
            "additionalData": [],
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "productType",
    "label": "Product Type",
    "description": "Product Type",
    "module": "accounts",
    "doNotManage": true,
    "values": [
        {
            "code": "BSVEA",
            "label": "BSVEA",
            "description": "",
            "isActive": true
        },
        {
            "code": "BSVCC",
            "label": "BSVCC",
            "description": "",
            "isActive": true
        },
        {
            "code": "BSEAT",
            "label": "BSEAT",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "plan",
    "label": "Plan",
    "description": "Plan",
    "module": "accounts",
    "values": [
        {
            "code": "CA",
            "label": "CA",
            "description": "",
            "isActive": true
        },
        {
            "code": "CO",
            "label": "CO",
            "description": "",
            "isActive": true
        },
        {
            "code": "CT",
            "label": "CT",
            "description": "",
            "isActive": true
        },
        {
            "code": "GA",
            "label": "GA",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTH_LINK",
            "label": "HealthLink",
            "description": "",
            "isActive": true
        },
        {
            "code": "IN",
            "label": "IN",
            "description": "",
            "isActive": true
        },
        {
            "code": "INTERNATIONAL",
            "label": "International",
            "description": "",
            "isActive": true
        },
        {
            "code": "KY",
            "label": "KY",
            "description": "",
            "isActive": true
        },
        {
            "code": "ME",
            "label": "ME",
            "description": "",
            "isActive": true
        },
        {
            "code": "MO",
            "label": "MO",
            "description": "",
            "isActive": true
        },
        {
            "code": "NH",
            "label": "NH",
            "description": "",
            "isActive": true
        },
        {
            "code": "NON_ANTHEM_STATE",
            "label": "Non-Anthem State",
            "description": "",
            "isActive": true
        },
        {
            "code": "NV",
            "label": "NV",
            "description": "",
            "isActive": true
        },
        {
            "code": "NY",
            "label": "NY",
            "description": "",
            "isActive": true
        },
        {
            "code": "OH",
            "label": "OH",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE_ONE_NATION",
            "label": "UniCare/One Nation",
            "description": "",
            "isActive": true
        },
        {
            "code": "VA",
            "label": "VA",
            "description": "",
            "isActive": true
        },
        {
            "code": "WI",
            "label": "WI",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "brand",
    "label": "Brand",
    "description": "Brand",
    "module": "accounts",
    "values": [
        {
            "code": "ANTHEM_BLUE_CROSS",
            "label": "Anthem Blue Cross",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BLUE_CROSS_BLUESHIELD",
            "label": "Anthem Blue Cross Blue Shield",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP",
            "label": "Anthem EAP",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BLUE_CROSS",
            "label": "Empire Blue Cross",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BLUE_CROSS_BLUE_SHIELD",
            "label": "Empire Blue Cross Blue Shield",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTH_LINK",
            "label": "HealthLink",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE",
            "label": "UniCare",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "episodeDuration",
    "label": "Episode Duration",
    "description": "Episode Duration",
    "module": "accounts",
    "values": [
        {
            "code": "12_MONTHS_AFTER_INITIAL_CALL",
            "label": "12 Months after Initial Call",
            "description": "",
            "isActive": true
        },
        {
            "code": "CALENDAR_YEAR",
            "label": "Calendar Year",
            "description": "",
            "isActive": true
        },

        {
            "code": "CONTRACT_YEAR",
            "label": "Contract Year",
            "description": "",
            "isActive": true
        },
        {
            "code": "NA",
            "label": "N/A",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "dcbtEligibility",
    "label": "DCBT Eligibility",
    "description": "DCBT Eligibility",
    "module": "accounts",
    "values": [
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        },
        {
            "code": "OLDMYS",
            "label": "Z OldMyS",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "dcbtPortal",
    "label": "DCBT Portal",
    "description": "DCBT Portal",
    "module": "accounts",
    "values": [
        {
            "code": "EAPWEBSITE",
            "label": "EAP Website",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPWEBSITE_ENGAGE",
            "label": "EAP Website & Engage",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPWEBSITE_SYDNEY",
            "label": "EAP Website & Sydney",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "eapWebSite",
    "label": "EAP Website",
    "description": "EAP Website",
    "module": "accounts",
    "values": [
        {
            "code": "MULTIPLE_URLS",
            "label": "Multiple URLs (see notes)",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_GLOBAL_WEBSITE",
            "label": "www.Anthem.com/eap/Global",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_VERIZON_WEBSITE",
            "label": "www.Anthem.com/eap/verizon",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_LIFE_MATTERS_WEBSITE",
            "label": "www.Anthem.com/LifeMatters",
            "description": "",
            "isActive": true
        },
        {
            "code": "wANTHEM_SOUTHERN_COMPANY_LIFESOURCE_WEBSITE",
            "label": "www.Anthem.com/SouthernCompanyLifeSOurce",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_SWLR_WEBSITE",
            "label": "www.Anthem.com/swlr",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_WLS_WEBSITE",
            "label": "www.Anthem.com/wls",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_WEBSITE",
            "label": "www.AnthemEAP.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "EDJEAP_WEBSITE",
            "label": "www.edjeap.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_EAP_WEBSITE",
            "label": "www.EmpireEAP.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "FERGUSON_RESOURCES_FOR_LIFE_WEBSITE",
            "label": "ferguson.resourcesforyourlife.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTHLINK_EAP_WEBSITE",
            "label": "www.HealthLinkEAP.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "HIIHERO_WEBSITE",
            "label": "www.HIIHERO.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "MEMBER_LIFECARE_WEBSITE",
            "label": "member.lifecare.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "MEMBER_ASSISSTANCE_PROGRAM_WEBSITE",
            "label": "www.MemberAssistanceProgram.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "STUDENT_SUPPORT_RESOURCES_WEBSITE",
            "label": "www.studentsupportresources.com",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE_YOUREAPWEBSITE",
            "label": "www.UniCare.com/youreap",
            "description": "",
            "isActive": true
        },
        {
            "code": "WEBSITE_NOT_APPLICABLE",
            "label": "WWW.WEBSITE NOT APPLICABLE",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "eblastPromotions",
    "label": "EBlast Promotions",
    "description": "EBlast Promotions",
    "module": "accounts",
    "values": [
        {
            "code": "ANTHEM_BC_GOLDEN_STATE_FOODS",
            "label": "Anthem BC Golden State Foods",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BC_HUNTINGTON_II",
            "label": "Anthem BC Huntington II",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCMHA",
            "label": "Anthem BC MHA",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BC_PRISM",
            "label": "Anthem BC PRISM",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BC_RELIANCE_STEEL_ALUMINIUM",
            "label": "Anthem BC Reliance Steel & Aluminum",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCSD",
            "label": "Anthem BC SD",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCSD_MAP",
            "label": "Anthem BC SD- MAP",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BC_SECURITAS_LIFE_MATTERS",
            "label": "Anthem BC Securitas Life Matters",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BC_TECH_BENEFITS_PROGRAM",
            "label": "Anthem BC Tech Benefits Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_360_DV",
            "label": "Anthem BCBS 360 DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_ADVANCE_AUTO_PARTS",
            "label": "Anthem BCBS Advance Auto Parts",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_AEP",
            "label": "Anthem BCBS AEP",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_BANK_OF_AMERICA",
            "label": "Anthem BCBS Bank of America ",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_BOYD_GAMING",
            "label": "Anthem BCBS Boyd Gaming",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_CAPITAL_ONE",
            "label": "Anthem BCBS Capital One",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_COVA",
            "label": "Anthem BCBS COVA",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_DANA_INC",
            "label": "Anthem BCBS Dana Inc",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBSDV",
            "label": "Anthem BCBS DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_DVMAP",
            "label": "Anthem BCBS DV MAP",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_EAP_BHRDV",
            "label": "Anthem BCBS EAP/BHR DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_EXIDE_TECHNOLOGIES",
            "label": "Anthem BCBS Exide Technologies",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_FERGUSON",
            "label": "Anthem BCBS Ferguson",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_HHHUNT_CORPORATION",
            "label": "Anthem BCBS HHHunt Corporation",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_HOUSE",
            "label": "Anthem BCBS House",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_LILLY",
            "label": "Anthem BCBS Lilly",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_LINDT_SPRUNGLI",
            "label": "Anthem BCBS Lindt & Sprungli",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_MEABT",
            "label": "Anthem BCBS MEABT",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_MHA",
            "label": "Anthem BCBS MHA",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_NH",
            "label": "Anthem BCBS NH",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_OLD_CASTLE",
            "label": "Anthem BCBS OLDCASTLE",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_OWENS_MINOR",
            "label": "Anthem BCBS Owens & Minor",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_PARKER",
            "label": "Anthem BCBS PARKER",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_QUAD_GRAPHICS",
            "label": "Anthem BCBS QuadGraphics",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_SD",
            "label": "Anthem BCBS SD",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBSS_ENTRY",
            "label": "Anthem BCBS Sentry",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_SOI",
            "label": "Anthem BCBS SOI",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_SOUTHERN_CO",
            "label": "Anthem BCBS Southern Co",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_VA",
            "label": "Anthem BCBS VA",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_VERIZON",
            "label": "Anthem BCBS Verizon",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_BCBS_ZIMMER_BIOMET",
            "label": "Anthem BCBS Zimmer Biomet",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_DV",
            "label": "Anthem EAP DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_NH",
            "label": "Anthem EAP NH",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_SD",
            "label": "Anthem EAP SD",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_TRADER_JOE",
            "label": "Anthem EAP Trader Joe's",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_EAP_VA",
            "label": "Anthem EAP VA",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BCNH",
            "label": "Empire BC NH",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BCSD",
            "label": "Empire BC SD",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BCBS_DV",
            "label": "Empire BCBS DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPIRE_BCBS_SD",
            "label": "Empire BCBS SD",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTH_LINK",
            "label": "HealthLink",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE_COSTCO",
            "label": "UniCare COSTCO",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE_DV",
            "label": "UniCare DV",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNICARE_NH",
            "label": "UniCare NH",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "programName",
    "label": "Program Name",
    "description": "Program Name",
    "module": "accounts",
    "values": [
        {
            "code": "EMPLOYEE_ASSISTANCE_PROGRAM",
            "label": "Employee Assistance Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "CARE_NETWORK",
            "label": "Care Network",
            "description": "",
            "isActive": true
        },
        {
            "code": "CARE_PROGRAM",
            "label": "CARE Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "HERO",
            "label": "HERO",
            "description": "",
            "isActive": true
        },
        {
            "code": "MEMBER_ASSISTANCE_PROGRAM",
            "label": "Member Assistance Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "SECURITAS_LIFE_MATTERS_PROGRAM",
            "label": "Securitas LifeMatters Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "SENTRY_WORK_LIFE_RESOURCES",
            "label": "Sentry Work Life Resources",
            "description": "",
            "isActive": true
        },
        {
            "code": "SOUTHERN_COMPANY_LIFE_SOURCE_PROGRAM",
            "label": "Southern Company LifeSOurce Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "STUDENT_CONNECT_PROGRAM",
            "label": "Student Connect Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "TEAMMATE_ASSISTANCE_PROGRAM",
            "label": "Teammate Assistance Program",
            "description": "",
            "isActive": true
        },
        {
            "code": "WORK_LIFE_SOLUTIONS",
            "label": "Work-Life Solutions",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "liveHealthOnlineElig",
    "label": "Live Health Online Eligibility",
    "description": "Live Health Online Eligibility",
    "module": "accounts",
    "values": [
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "sydneyPreferred",
    "label": "Sydney Preferred",
    "description": "Sydney Preferred",
    "module": "accounts",
    "values": [
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        }
    ]

}]);
db.codes.insert([{
    "_id": "standalone",
    "label": "Standalone",
    "description": "Standalone",
    "module": "accounts",
    "values": [
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        },
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        }
    ]

}]);
db.codes.insert([{
    "_id": "totalHealthTotalYou",
    "label": "Total Health Total You",
    "description": "Total Health Total You",
    "module": "accounts",
    "values": [
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "engage",
    "label": "Engage",
    "description": "Engage",
    "module": "accounts",
    "values": [
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "dotSAPPayOpt",
    "label": "DOT SAP PayOpt",
    "description": "DOT SAP PayOpt",
    "module": "accounts",
    "values": [
        {
            "code": "CAPITATED",
            "label": "Capitated",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPLOYEE_PAYS",
            "label": "Employee Pays",
            "description": "",
            "isActive": true
        },
        {
            "code": "FFS",
            "label": "FFS",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "workLife",
    "label": "Work Life",
    "description": "Work Life",
    "module": "accounts",
    "values": [
        {
            "code": "BASIC",
            "label": "Basic",
            "description": "",
            "isActive": true
        },
        {
            "code": "CUSTOM",
            "label": "Custom",
            "description": "",
            "isActive": true
        },
        {
            "code": "ENHANCED",
            "label": "Enhanced",
            "description": "",
            "isActive": true
        },
        {
            "code": "NO_SERVICE",
            "label": "No Service",
            "description": "",
            "isActive": true
        },
        {
            "code": "OTHER_VENDOR",
            "label": "Other Vendor",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "legalFinancial",
    "label": "Legal Financial",
    "description": "Legal Financial",
    "module": "accounts",
    "values": [
        {
            "code": "CUSTOM",
            "label": "Custom",
            "description": "",
            "isActive": true
        },
        {
            "code": "NO_SERVICE",
            "label": "No Service",
            "description": "",
            "isActive": true
        },
        {
            "code": "OTHER_VENDOR",
            "label": "Other Vendor",
            "description": "",
            "isActive": true
        },
        {
            "code": "STANDARD",
            "label": "Standard",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "smokingCessation",
    "label": "Smoking Cessation",
    "description": "Smoking Cessation",
    "module": "accounts",
    "values": [
        {
            "code": "CUSTOM",
            "label": "Custom",
            "description": "",
            "isActive": true
        },
        {
            "code": "STANDARD",
            "label": "Standard",
            "description": "",
            "isActive": true
        },
        {
            "code": "NO_SERVICE",
            "label": "No Service",
            "description": "",
            "isActive": true
        },
        {
            "code": "OTHER_VENDOR",
            "label": "Other Vendor",
            "description": "",
            "isActive": true
        },
        {
            "code": "LIVE_TOBACCO_FREE_PROGRAM",
            "label": "Live Tobacco Free program",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "memberCenter",
    "label": "Member Center",
    "description": "Member Center",
    "module": "accounts",
    "values": [
        {
            "code": "NO_SERVICE",
            "label": "No Service",
            "description": "",
            "isActive": true
        },
        {
            "code": "STANDARD",
            "label": "Standard",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "followUpCallRequired",
    "label": "Follow Up Call Required",
    "description": "Follow Up Call Required",
    "module": "accounts",
    "values": [
        {
            "code": "1_DAY",
            "label": "1 Day",
            "description": "",
            "isActive": true
        },
        {
            "code": "2_DAYS",
            "label": "2 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "3_DAYS",
            "label": "3 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "4_DAYS",
            "label": "4 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "5_DAYS",
            "label": "5 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "6_DAYS",
            "label": "6 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "7_DAYS",
            "label": "7 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "8_DAYS",
            "label": "8 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "9_DAYS",
            "label": "9 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "10_DAYS",
            "label": "10 Days",
            "description": "",
            "isActive": true
        },
        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "assistedProviderSearchRequired",
    "label": "Assistance Provider Search Required",
    "description": "Assistance Provider Search Required",
    "module": "accounts",
    "values": [

        {
            "code": "NO",
            "label": "No",
            "description": "",
            "isActive": true
        },
        {
            "code": "YES",
            "label": "Yes",
            "description": "",
            "isActive": true
        }
    ]

}]);
db.codes.insert([{
    "_id": "eligibilityFor",
    "label": "Eligibility For",
    "description": "Eligibility For",
    "module": "accounts",
    "values": [
        {
            "code": "ALL",
            "label": "All",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTH_PLAN_ONLY",
            "label": "Health Plan Only",
            "description": "",
            "isActive": true
        },
        {
            "code": "FULL_TIME",
            "label": "Full Time",
            "description": "",
            "isActive": true
        },
        {
            "code": "PART_TIME",
            "label": "Part Time",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPECIFIC_SUB_GROUPS",
            "label": "Specific Subgroups",
            "description": "",
            "isActive": true
        },
        {
            "code": "UNION",
            "label": "Union",
            "description": "",
            "isActive": true
        },
        {
            "code": "NON_UNION",
            "label": "Non-Union",
            "description": "",
            "isActive": true
        },
        {
            "code": "COBRA",
            "label": "COBRA",
            "description": "",
            "isActive": true
        },
        {
            "code": "RETIREES",
            "label": "Retirees",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "numberOfSessions",
    "label": "Number Of Sessions",
    "description": "Number Of Sessions",
    "module": "accounts",
    "values": [
        {
            "code": "1_3",
            "label": "1-3",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_4",
            "label": "1-4",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_5",
            "label": "1-5",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_6",
            "label": "1-6",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_7",
            "label": "1-7",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_8",
            "label": "1-8",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_9",
            "label": "1-9",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_10",
            "label": "1-10",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_12",
            "label": "1-12",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_20",
            "label": "1-20",
            "description": "",
            "isActive": true
        },
        {
            "code": "1_25",
            "label": "1-25",
            "description": "",
            "isActive": true
        },
        {
            "code": "NONE",
            "label": "None",
            "description": "",
            "isActive": true
        },
        {
            "code": "VARIES_BY_SUBGROUP",
            "label": "Varies By Subgroup",
            "description": "",
            "isActive": true
        }

    ]

}]);
db.codes.insert([{
    "_id": "renewalOptions",
    "label": "Renewal Options",
    "description": "Renewal Options",
    "module": "accounts",
    "values": [
        {
            "code": "ALLIED_PROGRAMS",
            "label": "Allied Programs",
            "description": "",
            "isActive": true
        },
        {
            "code": "BROKER_INFORMATION",
            "label": "Broker Information",
            "description": "",
            "isActive": true
        },
        {
            "code": "ACCOUNT_EMPLOYER_BENEFITS",
            "label": "Account Employer Benefits",
            "description": "",
            "isActive": true
        },
        {
            "code": "VENDOR_INTEGRATION",
            "label": "Vendor Integration",
            "description": "",
            "isActive": true
        },
        {
            "code": "UTILIZATION_REPORTING",
            "label": "Utilization Reporting",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPECIAL_INSTRUCTIONS",
            "label": "Special Instructions",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "eapPhone",
    "label": "EAP Phone",
    "description": "EAP Phone",
    "module": "accounts",
    "values": [
        {
            "code": "EAPPHONE_1",
            "label": "Advance Auto Parts : 844-430-0324",
            "description": "",
            "isActive": true
        },

        {
            "code": "EAPPHONE_3",
            "label": "American Electric Power (AEP) : 833-600-4758",
            "description": "",
            "isActive": true
        },

        {
            "code": "EAPPHONE_5",
            "label": "Bank of America : 855-873-4935",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_10",
            "label": "Boyd Gaming : 855-383-7229",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_11",
            "label": "Capital Group : 844-627-1641",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_12",
            "label": "Capital One : 855-383-7222",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_16",
            "label": "County of Kern : 844-416-6386",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_17",
            "label": "County of San Diego : 888-777-6665",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_18",
            "label": "COVA/TLC : 855-223-9277",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_19",
            "label": "CSAC : 833-954-1067",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_20",
            "label": "Dana Inc : 844-879-5720",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_21",
            "label": "Delta Retirees : 833-839-7920",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_22",
            "label": "Den Cl Ctr : 800-865-1044",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_23",
            "label": "Den Cl Ctr : 800-647-9151",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_24",
            "label": "Denver Disaster line : 877-208-8240",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_25",
            "label": "Denver RC BHR ONLY : 866-621-0554",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_26",
            "label": "Denver RC BHR/EAP : 855-873-4932",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_28",
            "label": "EAP House : 877-361-7974",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_30",
            "label": "Eli Lilly : 833-335-4559",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_31",
            "label": "eSAP, OnCall EAP : 800-801-7835",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_32",
            "label": "Exchange Grps (CA) : 855-871-5646",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_34",
            "label": "Exchange Grps (IN) : 855-873-4923",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_35",
            "label": "FedEx : 866-621-0130",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_36",
            "label": "Ferguson Enterprises : 833-606-4280",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_38",
            "label": "HealthLink EAP  : 800-753-0526",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_39",
            "label": "Huntington Ingalls Industries : 855-400-9185",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_42",
            "label": "International WPO : 000-000-0000",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_44",
            "label": "LODA - VA : 844-271-7688",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_45",
            "label": "Luxottica : 833-914-0267",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_46",
            "label": "MEABT : 855-686-5615",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_47",
            "label": "Mercer Health Advantage : 855-229-7820",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_53",
            "label": "Oldcastle : 800-841-5144",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_54",
            "label": "Owens & Minor : 833-855-5823",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_55",
            "label": "Parker Hannifin : 866-260-9579",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_56",
            "label": "QuadGraphics : 877-367-7126",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_57",
            "label": "Reliance Steel & Aluminum : 855-873-4925",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_58",
            "label": "Resource Advisor : 888-209-7840",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_60",
            "label": "San Diego disaster line : 800-765-4446",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_62",
            "label": "SAP Albany State University   : 833-855-0083",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_63",
            "label": "SAP Augusta University   : 833-910-3364",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_64",
            "label": "SAP Clayton State University   : 833-855-0084",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_65",
            "label": "SAP Columbus State University   : 833-910-3363",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_66",
            "label": "SAP Dalton State College   : 833-855-0081",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_67",
            "label": "SAP Georgia College & State University   : 833-855-0085",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_68",
            "label": "SAP Georgia Gwinnett College   : 833-910-3366",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_69",
            "label": "SAP Georgia Highlands College   : 833-855-0082",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_70",
            "label": "SAP Georgia Institute of Technology   : 833-910-3370",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_71",
            "label": "SAP Georgia Southern University   : 833-910-3369",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_72",
            "label": "SAP Georgia State University   : 833-874-0014",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_73",
            "label": "SAP Kennesaw State University   : 833-874-0013",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_74",
            "label": "SAP Middle Georgia State University   : 833-910-3362",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_75",
            "label": "SAP University of Georgia   : 833-910-3371",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_76",
            "label": "SAP University of North Georgia   : 833-910-3368",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_77",
            "label": "SAP University of West Georgia   : 833-910-3367",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_78",
            "label": "SAP University System of Georgia   : 833-855-0079",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_79",
            "label": "SAP Valdosta State University   : 833-910-3365",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_80",
            "label": "SD EAP Cl Ctr : 800-999-7222",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_81",
            "label": "SD Resource Center : 877-657-6060",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_82",
            "label": "Securitas : 855-543-6877",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_83",
            "label": "Sentry Work/Life Resources : 800-647-9047",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_84",
            "label": "Sequoia : 833-600-4763",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_86",
            "label": "Southern Company : 833-820-8992",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_87",
            "label": "State of Indiana : 800-223-7723",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_88",
            "label": "Student Connect Program (General) : 833-434-1217",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_89",
            "label": "TEST : 888-888-8888",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_90",
            "label": "Trader Joe's : 888-441-8671",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_91",
            "label": "VA : 800-346-5484",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_93",
            "label": "Verizon : 888-441-8674",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_96",
            "label": "Wellpower : 855-880-0567",
            "description": "",
            "isActive": true
        },
        {
            "code": "EAPPHONE_97",
            "label": "Zimmer Biomet Holdings : 833-600-4759",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.getCollection('codes').insert([{
    "_id": "employeeKnownAs",
    "label": "Employee Known As",
    "description": "Employee Known As",
    "module": "accounts",
    "values": [
        {
            "code": "ASSOCIATE",
            "label": "Associate",
            "description": "",
            "isActive": true
        },
        {
            "code": "CREW",
            "label": "Crew",
            "description": "",
            "isActive": true
        },
        {
            "code": "EMPLOYEE",
            "label": "Employee",
            "description": "",
            "isActive": true
        },
        {
            "code": "TEAMMATE",
            "label": "Teammate",
            "description": "",
            "isActive": true
        }
    ]
}]);
