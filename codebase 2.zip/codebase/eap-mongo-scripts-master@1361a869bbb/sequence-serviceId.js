db.sequence.update(
	{ "_id" : "serviceId" }, 
	{
		$setOnInsert : {
			"_id" : "serviceId",
			"seq" : NumberInt(199999)
		}
	 }, 
	 {
		 upsert : true
	 }
)