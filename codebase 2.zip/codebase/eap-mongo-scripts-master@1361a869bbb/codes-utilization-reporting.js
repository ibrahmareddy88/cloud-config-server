/**
 * run script in DB for utilization reporting into codes collection
*/

db.codes.remove({
    "_id": {
        $in: ["reportingFrequency", "reportingMonth", "reportType", "subgroup_utilization_reports"]
    }
})

db.codes.insert([{
    "_id": "reportingFrequency",
    "label": "Reporting Frequency",
    "description": "Reporting Frequency",
    "module": "accounts",
    "values": [
        {
            "code": "ANNUAL",
            "label": "Annual",
            "description": "",
            "isActive": true
        },
        {
            "code": "QUARTERLY",
            "label": "Quarterly",
            "description": "",
            "isActive": true
        },
        {
            "code": "SEMI_ANNUAL",
            "label": "Semiannual",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "reportingMonth",
    "label": "Reporting Month",
    "description": "Reporting Month",
    "module": "accounts",
    "values": [
        {
            "code": "JANUARY",
            "label": "January",
            "description": "",
            "isActive": true
        },
        {
            "code": "FEBRUARY",
            "label": "February",
            "description": "",
            "isActive": true
        },
        {
            "code": "MARCH",
            "label": "March",
            "description": "",
            "isActive": true
        },
        {
            "code": "APRIL",
            "label": "April",
            "description": "",
            "isActive": true
        },
        {
            "code": "MAY",
            "label": "May",
            "description": "",
            "isActive": true
        },
        {
            "code": "JUNE",
            "label": "June",
            "description": "",
            "isActive": true
        },
        {
            "code": "JULY",
            "label": "July",
            "description": "",
            "isActive": true
        },
        {
            "code": "AUGUST",
            "label": "August",
            "description": "",
            "isActive": true
        },
        {
            "code": "SEPTEMBER",
            "label": "September",
            "description": "",
            "isActive": true
        },
        {
            "code": "OCTOBER",
            "label": "October",
            "description": "",
            "isActive": true
        },
        {
            "code": "NOVEMBER",
            "label": "November",
            "description": "",
            "isActive": true
        },
        {
            "code": "DECEMBER",
            "label": "December",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "reportType",
    "label": "Report Type",
    "description": "Report Type",
    "module": "accounts",
    "values": [
        {
            "code": "2_YEAR_TRENDS",
            "label": "2 Year Trends",
            "description": "",
            "isActive": true
        },
        {
            "code": "3_YEAR_TRENDS",
            "label": "3 Year Trends",
            "description": "",
            "isActive": true
        },
        {
            "code": "5_YEAR_TRENDS",
            "label": "5 Year Trends",
            "description": "",
            "isActive": true
        },
        {
            "code": "INDUSTRY_COMPARISON",
            "label": "Industry Comparison",
            "description": "",
            "isActive": true
        },
        {
            "code": "MONTHLY_UTILIZATION",
            "label": "Monthly Utilization",
            "description": "",
            "isActive": true
        },
        {
            "code": "SESSION_ACTIVITY",
            "label": "Session Activity",
            "description": "",
            "isActive": true
        }
    ]

}]);
db.codes.insert([{
    "_id": "subgroup_utilization_reports",
    "label": "Subgroup Utilization Reports",
    "description": "Subgroup Utilization Reports",
    "module": "accounts",
    "values": [
        {
            "code": "ALL",
            "label": "All",
            "description": "",
            "isActive": true
        },
        {
            "code": "SELECT_ONLY",
            "label": "Select(only)",
            "description": "",
            "isActive": true
        }
    ]

}]);

