function nextId(fromCollection) {
  var ids = [];
  var obj = db[fromCollection].find({}, { _id: 1 }).forEach(function (item) {
    ids.push(NumberInt(item._id));
  });
  return ids.length > 0
    ? String(
        ids.sort(function (a, b) {
          return b - a;
        })[0] + 1
      )
    : String(1);
}

db.restriction.remove({ resourceCode: { $in:["TRACKING_SYSTEM_SEARCH", "GROUP_SEARCH", "HOME", "ADMIN_MODULE", "REPORTS_MODULE"] }});

db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "TRACKING_SYSTEM_SEARCH",
    "description" : "Read Tracking System Search",
    "accessLevel" : "readonly"
});
db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "TRACKING_SYSTEM_SEARCH",
    "description" : "Hide Tracking System Search",
    "accessLevel" : "hidden"
});
db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "GROUP_SEARCH",
    "description" : "Hide Group Search",
    "accessLevel" : "hidden"
});
db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "HOME",
    "description" : "Hide Home",
    "accessLevel" : "hidden"
});
db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "ADMIN_MODULE",
    "description" : "Read Admin Mobule",
    "accessLevel" : "readonly"
});
db.restriction.insert({
    "_id" : NumberLong(nextId("restriction")),
    "resourceCode" : "REPORTS_MODULE",
    "description" : "Hide Reports",
    "accessLevel" : "hidden"
});