/**
 * run script in DB for Groups into codes collection
*/

db.codes.remove({ "category": { $in: ["groupType", "operationProcess", "state", "termReason", "aliasType", "healthPlanIds", "industry"] } })
db.codes.insert([{
    "_id": "groupType",
    "label": "Group Type",
    "description": "Group Type",
    "module": "accounts",
    "values": [
        {
            "code": "CCH-no BAA",
            "label": "CCH-no BAA",
            "isActive": true
        },
        {
            "code": "CCH-SAP",
            "label": "CCH-SAP",
            "isActive": true
        },
        {
            "code": "Circumstantial",
            "label": "Circumstantial",
            "isActive": true
        },
        {
            "code": "Embedded EAP Benefits - Large Group",
            "label": "Embedded EAP Benefits - Large Group",
            "isActive": true
        },
        {
            "code": "Embedded EAP Benefits - Resource Advisor",
            "label": "Embedded EAP Benefits - Resource Advisor",
            "isActive": true
        },
        {
            "code": "Embedded EAP Benefits - Small Group",
            "label": "Embedded EAP Benefits - Small Group",
            "isActive": true
        },
        {
            "code": "International",
            "label": "International",
            "isActive": true
        },
        {
            "code": "Online Only",
            "label": "Online Only",
            "isActive": true
        },
        {
            "code": "Standard",
            "label": "Standard",
            "isActive": true
        },
        {
            "code": "Testing",
            "label": "Testing",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "operationProcess",
    "label": "Operation Process",
    "description": "Operation Process",
    "module": "accounts",
    "values": [
        {
            "code": "Clinical First Answer",
            "label": "Clinical First Answer",
            "isActive": true
        },
        {
            "code": "Custom",
            "label": "Custom",
            "isActive": true
        },

        {
            "code": "Standard",
            "label": "Standard",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "state",
    "label": "State",
    "description": "State",
    "module": "accounts",
    "values": [
        {
            "code": "AL",
            "label": "Alabama",
            "isActive": true
        },
        {
            "code": "AK",
            "label": "Alaska",
            "isActive": true
        },

        {
            "code": "AZ",
            "label": "Arizona",
            "isActive": true
        },
        {
            "code": "AR",
            "label": "Arkansas",
            "isActive": true
        },
        {
            "code": "CA",
            "label": "California",
            "isActive": true
        },
        {
            "code": "CO",
            "label": "Colorado",
            "isActive": true
        },
        {
            "code": "CT",
            "label": "Connecticut",
            "isActive": true
        },
        {
            "code": "DE",
            "label": "Delaware",
            "isActive": true
        },
        {
            "code": "FL",
            "label": "Florida",
            "isActive": true
        },
        {
            "code": "GA",
            "label": "Georgia",
            "isActive": true
        },
        {
            "code": "HI",
            "label": "Hawaii",
            "isActive": true
        },
        {
            "code": "ID",
            "label": "Idaho",
            "isActive": true
        },
        {
            "code": "IL",
            "label": "Illinois",
            "isActive": true
        },
        {
            "code": "IN",
            "label": "Indiana",
            "isActive": true
        },
        {
            "code": "IA",
            "label": "Iowa",
            "isActive": true
        },
        {
            "code": "KS",
            "label": "Kansas",
            "isActive": true
        },

        {
            "code": "KY",
            "label": "Kentucky",
            "isActive": true
        },
        {
            "code": "LA",
            "label": "Louisiana",
            "isActive": true
        },
        {
            "code": "ME",
            "label": "Maine",
            "isActive": true
        },
        {
            "code": "MD",
            "label": "Maryland",
            "isActive": true
        },
        {
            "code": "MA",
            "label": "Massachusetts",
            "isActive": true
        },
        {
            "code": "MI",
            "label": "Michigan",
            "isActive": true
        },
        {
            "code": "MN",
            "label": "Minnesota",
            "isActive": true
        },
        {
            "code": "MS",
            "label": "Mississippi",
            "isActive": true
        },
        {
            "code": "MO",
            "label": "Missouri",
            "isActive": true
        },
        {
            "code": "MT",
            "label": "Montana",
            "isActive": true
        },
        {
            "code": "NE",
            "label": "Nebraska",
            "isActive": true
        },
        {
            "code": "NV",
            "label": "Nevada",
            "isActive": true
        },
        {
            "code": "NH",
            "label": "New Hampshire",
            "isActive": true
        },
        {
            "code": "NJ",
            "label": "New Jersey",
            "isActive": true
        },
        {
            "code": "NM",
            "label": "New Mexico",
            "isActive": true
        },
        {
            "code": "NY",
            "label": "New York",
            "isActive": true
        },
        {
            "code": "NV",
            "label": "North Carolina",
            "isActive": true
        },
        {
            "code": "ND",
            "label": "North Dakota",
            "isActive": true
        },
        {
            "code": "OH",
            "label": "Ohio",
            "isActive": true
        },
        {
            "code": "OK",
            "label": "Oklahoma",
            "isActive": true
        },
        {
            "code": "OR",
            "label": "Oregon",
            "isActive": true
        },
        {
            "code": "PA",
            "label": "Pennsylvania",
            "isActive": true
        },
        {
            "code": "RI",
            "label": "Rhode Island",
            "isActive": true
        },
        {
            "code": "SC",
            "label": "South Carolina",
            "isActive": true
        },
        {
            "code": "SD",
            "label": "South Dakota",
            "isActive": true
        },
        {
            "code": "TN",
            "label": "Tennessee",
            "isActive": true
        },
        {
            "code": "TX",
            "label": "Texas",
            "isActive": true
        },
        {
            "code": "UT",
            "label": "Utah",
            "isActive": true
        },
        {
            "code": "VT",
            "label": "Vermont",
            "isActive": true
        },

        {
            "code": "VA",
            "label": "Virginia",
            "isActive": true
        },
        {
            "code": "WA",
            "label": "Washington",
            "isActive": true
        },
        {
            "code": "WV",
            "label": "West Virginia",
            "isActive": true
        },
        {
            "code": "WI",
            "label": "Wisconsin",
            "isActive": true
        },
        {
            "code": "WY",
            "label": "Wyoming",
            "isActive": true
        },
    ]
}]);

db.codes.insert([{
    "_id": "termReason",
    "label": "Term Reason",
    "description": "Term Reason",
    "module": "accounts",
    "values": [
        {
            "code": "Acquisition/Merger",
            "label": "Acquisition/Merger",
            "isActive": true
        },
        {
            "code": "Administratively Closed",
            "label": "Administratively Closed",
            "isActive": true
        },
        {
            "code": "Business Closed",
            "label": "Business Closed",
            "isActive": true
        },
        {
            "code": "Consolidation of Carriers",
            "label": "Consolidation of Carriers",
            "isActive": true
        },
        {
            "code": "Embedded EAP offered",
            "label": "Embedded EAP offered",
            "isActive": true
        },
        {
            "code": "Fell Below case size requirement",
            "label": "Fell Below case size requirement",
            "isActive": true
        },
        {
            "code": "Networks",
            "label": "Networks",
            "isActive": true
        },
        {
            "code": "Non-Payment",
            "label": "Non-Payment",
            "isActive": true
        },
        {
            "code": "Not Known",
            "label": "Not Known",
            "isActive": true
        },
        {
            "code": "Other",
            "label": "Other",
            "isActive": true
        },
        {
            "code": "Quality of Service",
            "label": "Quality of Service",
            "isActive": true
        },
        {
            "code": "Rates too high",
            "label": "Rates too high",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "aliasType",
    "label": "Alias Type",
    "description": "Alias Type",
    "module": "accounts",
    "values": [
        {
            "code": "Alias",
            "label": "Alias",
            "isActive": true
        },
        {
            "code": "DBA - Doing Business As ",
            "label": "DBA - Doing Business As ",
            "isActive": true
        },
        {
            "code": "Old Name",
            "label": "Old Name",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "healthPlanIds",
    "label": "Health Plan Id",
    "description": "Health Plan Id",
    "module": "accounts",
    "values": [
        {
            "code": "Plan 1",
            "label": "Plan 1",
            "isActive": true
        },
        {
            "code": "Plan 2",
            "label": "Plan 2",
            "isActive": true
        },
        {
            "code": "Plan 3",
            "label": "Plan 3",
            "isActive": true
        },
        {
            "code": "Plan 4",
            "label": "Plan 4",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "industry",
    "label": "Industry",
    "description": "Industry",
    "module": "accounts",
    "values": [
        {
            "code": "Agriculture",
            "label": "Agriculture",
            "isActive": true
        },
        {
            "code": "Automotive",
            "label": "Automotive",
            "isActive": true
        },
        {
            "code": "Construction",
            "label": "Construction",
            "isActive": true
        },
        {
            "code": "Education",
            "label": "Education",
            "isActive": true
        },
        {
            "code": "Energy",
            "label": "Energy",
            "isActive": true
        },
        {
            "code": "Financial Services",
            "label": "Financial Services",
            "isActive": true
        },
        {
            "code": "Food & Beverage",
            "label": "Food & Beverage",
            "isActive": true
        },
        {
            "code": "Government",
            "label": "Government",
            "isActive": true
        },
        {
            "code": "Healthcare",
            "label": "Healthcare",
            "isActive": true
        },
        {
            "code": "Hospitality",
            "label": "Hospitality",
            "isActive": true
        },
        {
            "code": "Manufacturing",
            "label": "Manufacturing",
            "isActive": true
        },
        {
            "code": "Mass Media",
            "label": "Mass Media",
            "isActive": true
        },
        {
            "code": "Mining",
            "label": "Mining",
            "isActive": true
        },
        {
            "code": "Retail",
            "label": "Retail",
            "isActive": true
        },
        {
            "code": "Telecommunications",
            "label": "Telecommunications",
            "isActive": true
        },
        {
            "code": "Other",
            "label": "Other",
            "isActive": true
        }
    ]
}]);
