/**
 * run script in DB for User Setup into codes collection
*/

db.codes.remove({ "_id": "gender" });

db.codes.insert([{
  "_id": "gender",
  "label": "Gender",
  "description": "Gender",
  "module": "admin",
  "values": [
    {
      "code": "MALE",
      "label": "Male",
      "isActive": true
    },
    {
      "code": "FEMALE",
      "label": "Female",
      "isActive": true
    },
    {
      "code": "BOTH",
      "label": "Both",
      "isActive": true
    }
  ]
}])