/**
 * run script in DB for Provider Sanction action types into codes collection
*/

db.codes.remove({ "_id": "sanctionActionType" });

db.getCollection('codes').insert([{
"_id": "sanctionActionType",
"module": "Provider",
"label": "Sanction Action Type",
"description": "Sanction Action Type",
"values": [
{
"code": "STATE_LIMITATIONS",
"label": "State Limitations",
"description": "",
"isActive": true
},
{
"code": "STATE_RESTRICTIONS",
"label": "State Restrictions",
"description": "",
"isActive": true
},
{
"code": "STATE_REVOCATIONS",
"label": "State Revocations",
"description": "",
"isActive": true
},
{
"code": "STATE_SUSPENSIONS",
"label": "State Suspensions",
"description": "",
"isActive": true
},
{
"code": "STATE_SURRENDER",
"label": "State Surrender",
"description": "",
"isActive": true
},
{
"code": "OIG_LIMITATIONS",
"label": "OIG Limitations",
"description": "",
"isActive": true
},
{
"code": "OIG_RESTRICTIONS",
"label": "OIG Restrictions",
"description": "",
"isActive": true
},
{
"code": "OIG_REVOCATIONS",
"label": "OIG Revocations",
"description": "",
"isActive": true
},
{
"code": "OIG_SUSPENSIONS",
"label": "OIG Suspensions",
"description": "",
"isActive": true
},
{
"code": "OIG_SURRENDER",
"label": "OIG Surrender",
"description": "",
"isActive": true
},
{
"code": "NO_ACTION",
"label": "No Action",
"description": "",
"isActive": true
}
]
}
]);
