/**
* run script in DB for employer service delivery into codes collection
*/
db.codes.remove({
    "_id": {
        $in: [ "trainingCategory", "cirReason", "checkType"]
    }
})
db.codes.insert([{
    "_id": "trainingCategory",
    "label": "Training Category",
    "description": "Training Category",
    "module": "accounts",
    "values": [
        {
            "code": "AGING_ADULT",
            "label": "Aging Adult",
            "description": null,
            "isActive": true
        },
        {
            "code": "FINANCIAL",
            "label": "Financial",
            "description": null,
            "isActive": true
        },
        {
            "code": "HEALTH_AND_WELLNESS",
            "label": "Health and Wellness",
            "description": null,
            "isActive": true
        },
        {
            "code": "LEADERSHIP",
            "label": "Leadership",
            "description": null,
            "isActive": true
        },
        {
            "code": "LEGAL",
            "label": "Legal",
            "description": null,
            "isActive": true
        },
        {
            "code": "PARENTING AND FAMILY",
            "label": "Parenting and Family",
            "description": null,
            "isActive": true
        },
        {
            "code": "PERSONAL GROWTH",
            "label": "Personal Growth",
            "description": null,
            "isActive": true
        },
        {
            "code": "RISK MANAGEMENT TOPICS",
            "label": "Risk Management Topics",
            "description": null,
            "isActive": true
        },
        {
            "code": "WORKPLACE",
            "label": "Workplace",
            "description": null,
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "cirReason",
    "label": "CIR Reason",
    "description": "CIR Reason",
    "module": "accounts",
    "values": [
        {
            "code": "COMPANY_TRAUMA_DISASTER",
            "label": "Company Trauma/Disaster",
            "description": null,
            "isActive": true
        },
        {
            "code": "DEATH",
            "label": "Death",
            "description": null,
            "isActive": true
        },
        {
            "code": "NATURAL_DISASTER",
            "label": "Natural Disaster",
            "description": null,
            "isActive": true
        },
	{
            "code": "OTHER",
            "label": "Other",
            "description": null,
            "isActive": true
        },
        {
            "code": "REGIONAL_TRAGEDY",
            "label": "Regional Tragedy",
            "description": null,
            "isActive": true
        },
        {
            "code": "RIF_REORGANIZATION",
            "label": "RIF / Reorganization",
            "description": null,
            "isActive": true
        },
	{
            "code": "ROBBERY",
            "label": "Robbery",
            "description": null,
            "isActive": true
        },
        {
            "code": "TERMINAL_ILLNESS",
            "label": "Terminal Illness",
            "description": null,
            "isActive": true
        },
        {
            "code": "THREAT",
            "label": "Threat",
            "description": null,
            "isActive": true
        },
        {
            "code": "WITNESSING_TRAGEDY",
            "label": "Witnessing Tragedy",
            "description": null,
            "isActive": true
        },
        {
            "code": "WORKPLACE_SHOOTING",
            "label": "Workplace Shooting",
            "description": null,
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "checkType",
    "label": "Check Type",
    "description": "Check Type",
    "module": "accounts",
    "values": [
        {
            "code": "CORRECTION",
            "label": "Correction",
            "description": null,
            "isActive": true
        },
        {
            "code": "EXTRA PAYMENT",
            "label": "Extra Payment",
            "description": null,
            "isActive": true
        },
        {
            "code": "ORIGINAL",
            "label": "Original",
            "description": null,
            "isActive": true
        },
        {
            "code": "PENALTY",
            "label": "Penalty",
            "description": null,
            "isActive": true
        },
        {
            "code": "REPLACEMENT",
            "label": "Replacement",
            "description": null,
            "isActive": true
        }]
}]);
