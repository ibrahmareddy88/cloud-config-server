function nextId(fromCollection) {
  var ids = [];
  var obj = db[fromCollection].find({}, { _id: 1 }).forEach(function (item) {
    ids.push(NumberInt(item._id));
  });
  return ids.length > 0
    ? String(
        ids.sort(function (a, b) {
          return b - a;
        })[0] + 1
      )
    : String(1);
}

db.resource.remove({ code: { $in:["TRACKING_SYSTEM_SEARCH", "GROUP_SEARCH", "HOME", "ADMIN_MODULE", "REPORTS_MODULE"] }});

db.resource.insert({
    "_id" : NumberLong(nextId("resource")),
    "code" : "TRACKING_SYSTEM_SEARCH",
    "description" : "Tracking System Search"
});
db.resource.insert({
    "_id" : NumberLong(nextId("resource")),
    "code" : "GROUP_SEARCH",
    "description" : "Group Search"
});
db.resource.insert({
    "_id" : NumberLong(nextId("resource")),
    "code" : "HOME",
    "description" : "Home"
});
db.resource.insert({
    "_id" : NumberLong(nextId("resource")),
    "code" : "ADMIN_MODULE",
    "description" : "Admin Mobule"
});
db.resource.insert({
    "_id" : NumberLong(nextId("resource")),
    "code" : "REPORTS_MODULE",
    "description" : "Reports"
});