/**
 * run script in DB for Dropdown Setup into codes collection
*/

db.codes.remove({ "_id": "module" });

db.codes.insert([{
  "_id": "module",
  "description": "Module",
  "label": "Module",
  "values": [
    {
      "code": "accounts",
      "label": "Accounts",
      "isActive": true
    },
    {
      "code": "admin",
      "label": "Admin",
      "isActive": true
    },
    {
      "code": "memberDetailsAndServices",
      "label": "Member Details and Services",
      "isActive": true
    },
    {
      "code": "managementReferrals",
      "label": "Management Referrals",
      "isActive": true
    },
    {
      "code": "managementConsultation",
      "label": "Management Consultation",
      "isActive": true
    },
    {
      "code": "provider",
      "label": "Provider",
      "isActive": true
    }
  ]
}])