/**
* run script in DB for account profile into codes collection
*/
db.codes.remove({
    "_id": {
        $in: ["degreeName", "institutionstate"]
    }
})

db.codes.insert([{
    "_id": "degreeName",
    "label": "Degree Name",
    "description": "Degree Name",
    "module": "Provider",
    "values": [
        {
            "code": "PhD",
            "label": "PhD",
            "description": "",
            "isActive": true
        },
        {
            "code": "Psy",
            "label": "Psy",
            "description": "",
            "isActive": true
        },
        {
            "code": "MS",
            "label": "MS",
            "description": "",
            "isActive": true
        }, {
            "code": "MA",
            "label": "MA",
            "description": "",
            "isActive": true
        }, {
            "code": "EDD",
            "label": "EDD",
            "description": "",
            "isActive": true
        }, {
            "code": "MSW",
            "label": "MSW",
            "description": "",
            "isActive": true
        }, {
            "code": "MSSW",
            "label": "MSSW",
            "description": "",
            "isActive": true
        }, {
            "code": "MSN",
            "label": "MSN",
            "description": "",
            "isActive": true
        },

    ]

}]);


db.codes.insert([{
    "_id": "institutionstate",
    "label": "Institution State",
    "description": "Institution State",
    "module": "Provider",
    "values": [
        {
            "code": "ALASKA",
            "label": "Alaska",
            "description": "",
            "isActive": true
        },
        {
            "code": "ALABAMA",
            "label": "Alabama",
            "description": "",
            "isActive": true
        },
        {
            "code": "ARKANSAS",
            "label": "Arkansas",
            "description": "",
            "isActive": true
        }, {
            "code": "AMERICAN_SAMOA",
            "label": "American Samoa",
            "description": "",
            "isActive": true
        }, {
            "code": "ARIZONA",
            "label": "Arizona",
            "description": "",
            "isActive": true
        }, {
            "code": "CALIFORNIA",
            "label": "California",
            "description": "",
            "isActive": true
        }, {
            "code": "COLORADO",
            "label": "Colorado",
            "description": "",
            "isActive": true
        }, {
            "code": "CONNECTICUT",
            "label": "Connecticut",
            "description": "",
            "isActive": true
        }, {
            "code": "DISTRICT_OF_COLUMBIA",
            "label": "District Of Columbia",
            "description": "",
            "isActive": true
        }, {
            "code": "DELAWARE",
            "label": "Delaware",
            "description": "",
            "isActive": true
        }, {
            "code": "FLORIDA",
            "label": "Florida",
            "description": "",
            "isActive": true
        }, {
            "code": "GEORGIA",
            "label": "Georgia",
            "description": "",
            "isActive": true
        }, {
            "code": "GUAM",
            "label": "Guam",
            "description": "",
            "isActive": true
        }, {
            "code": "HAWAII",
            "label": "Hawaii",
            "description": "",
            "isActive": true
        }, {
            "code": "IOWA",
            "label": "Iowa",
            "description": "",
            "isActive": true
        }, {
            "code": "IDAHO",
            "label": "Idaho",
            "description": "",
            "isActive": true
        }, {
            "code": "ILLINOIS",
            "label": "Illinois",
            "description": "",
            "isActive": true
        }, {
            "code": "INDIANA",
            "label": "Indiana",
            "description": "",
            "isActive": true
        }, {
            "code": "KANSAS",
            "label": "Kansas",
            "description": "",
            "isActive": true
        }, {
            "code": "KENTUCKY",
            "label": "Kentucky",
            "description": "",
            "isActive": true
        }, {
            "code": "LOUISIANA",
            "label": "Louisiana",
            "description": "",
            "isActive": true
        }, {
            "code": "MASSACHUSETTS",
            "label": "Massachusetts",
            "description": "",
            "isActive": true
        }, {
            "code": "MARYLAND",
            "label": "Maryland",
            "description": "",
            "isActive": true
        }, {
            "code": "MAINE",
            "label": "Maine",
            "description": "",
            "isActive": true
        }, {
            "code": "MICHIGAN",
            "label": "Michigan",
            "description": "",
            "isActive": true
        }, {
            "code": "MINNESOTA",
            "label": "Minnesota",
            "description": "",
            "isActive": true
        }, {
            "code": "MISSOURI",
            "label": "Missouri",
            "description": "",
            "isActive": true
        }, {
            "code": "MISSISSIPPI",
            "label": "Mississippi",
            "description": "",
            "isActive": true
        }, {
            "code": "MONTANA",
            "label": "Montana",
            "description": "",
            "isActive": true
        }, {
            "code": "NORTH_CAROLINA",
            "label": "North Carolina",
            "description": "",
            "isActive": true
        }, {
            "code": "NORTH_DAKOTA",
            "label": "North Dakota",
            "description": "",
            "isActive": true
        }, {
            "code": "NEBRASKA",
            "label": "Nebraska",
            "description": "",
            "isActive": true
        }, {
            "code": "NEW_HAMPSHIRE",
            "label": "New Hampshire",
            "description": "",
            "isActive": true
        }, {
            "code": "NEW_JERSEY",
            "label": "New Jersey",
            "description": "",
            "isActive": true
        }, {
            "code": "NEW_MEXICO",
            "label": "New Mexico",
            "description": "",
            "isActive": true
        }, {
            "code": "NORTHERN_MARIANA_IS",
            "label": "Northern Mariana Is",
            "description": "",
            "isActive": true
        }, {
            "code": "NEVADA",
            "label": "Nevada",
            "description": "",
            "isActive": true
        }, {
            "code": "NEW_YORK",
            "label": "New York",
            "description": "",
            "isActive": true
        }, {
            "code": "OHIO",
            "label": "Ohio",
            "description": "",
            "isActive": true
        }, {
            "code": "OKLAHOMA",
            "label": "Oklahoma",
            "description": "",
            "isActive": true
        }, {
            "code": "OREGON",
            "label": "Oregon",
            "description": "",
            "isActive": true
        }, {
            "code": "PENNSYLVANIA",
            "label": "Pennsylvania",
            "description": "",
            "isActive": true
        }, {
            "code": "PUERTO_RICO",
            "label": "Puetro Rico",
            "description": "",
            "isActive": true
        }, {
            "code": "RHODE_ISLAND",
            "label": "Rhode Island",
            "description": "",
            "isActive": true
        }, {
            "code": "SOUTH_CAROLINA",
            "label": "South Carolina",
            "description": "",
            "isActive": true
        }, {
            "code": "SOUTH_DAKOTA",
            "label": "South Dakota",
            "description": "",
            "isActive": true
        }, {
            "code": "TENNESSEE",
            "label": "Tennesse",
            "description": "",
            "isActive": true
        }, {
            "code": "TEXAS",
            "label": "Texas",
            "description": "",
            "isActive": true
        }, {
            "code": "UTAH",
            "label": "Utah",
            "description": "",
            "isActive": true
        }, {
            "code": "VIRGINIA",
            "label": "Virginia",
            "description": "",
            "isActive": true
        }, {
            "code": "VIRGIN_ISLANDS",
            "label": "Virgian Islands",
            "description": "",
            "isActive": true
        }, {
            "code": "VERMONT",
            "label": "Vermont",
            "description": "",
            "isActive": true
        }, {
            "code": "WASHINGTON",
            "label": "Washington",
            "description": "",
            "isActive": true
        }, {
            "code": "WISCONSIN",
            "label": "Wisconsin",
            "description": "",
            "isActive": true
        }, {
            "code": "WEST_VIRGINIA",
            "label": "West Virginia",
            "description": "",
            "isActive": true
        }, {
            "code": "WYOMING",
            "label": "Wyoming",
            "description": "",
            "isActive": true
        }

    ]

}]);