/**
 * run script in DB for account profile Finance terms into codes collection
*/

db.codes.remove({
    "_id": {
        $in: ["subGroupRatesVary", "subGroupContactsVary", "billingFrequency", "billingMonth", "adminFeeType", "billBy", "billingSystem", "regionalDept", "fundingType", "mbu", "groupCode", "lob"]
    }
})

db.codes.insert([{
    "_id": "billingFrequency",
    "label": "List of Billing Frequency supported by the system",
    "description": "List of Billing Frequency supported by the system",
    "module": "accounts",
    "values": [
        {
            "code": "ANNUALLY",
            "label": "Annually",
            "description": "",
            "isActive": true
        },
        {
            "code": "MONTHLY",
            "label": "Monthly",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "billingMonth",
    "label": "Billing Month",
    "description": "Billing Month",
    "module": "accounts",
    "values": [
        {
            "code": "JANUARY",
            "label": "January",
            "description": "",
            "isActive": true
        },
        {
            "code": "FEBRUARY",
            "label": "February",
            "description": "",
            "isActive": true
        },
        {
            "code": "MARCH",
            "label": "March",
            "description": "",
            "isActive": true
        },
        {
            "code": "APRIL",
            "label": "April",
            "description": "",
            "isActive": true
        },
        {
            "code": "MAY",
            "label": "May",
            "description": "",
            "isActive": true
        },
        {
            "code": "JUNE",
            "label": "June",
            "description": "",
            "isActive": true
        },
        {
            "code": "JULY",
            "label": "July",
            "description": "",
            "isActive": true
        },
        {
            "code": "AUGUST",
            "label": "August",
            "description": "",
            "isActive": true
        },
        {
            "code": "SEPTEMBER",
            "label": "September",
            "description": "",
            "isActive": true
        },
        {
            "code": "OCTOBER",
            "label": "October",
            "description": "",
            "isActive": true
        },
        {
            "code": "NOVEMBER",
            "label": "November",
            "description": "",
            "isActive": true
        },
        {
            "code": "DECEMBER",
            "label": "December",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "adminFeeType",
    "label": "Admin Fee Type",
    "description": "Admin Fee Type",
    "module": "accounts",
    "values": [
        {
            "code": "ANNUALLY",
            "label": "Annually",
            "description": "",
            "isActive": true
        },
        {
            "code": "MONTHLY",
            "label": "Monthly",
            "description": "",
            "isActive": true
        },
        {
            "code": "QUARTERLY",
            "label": "Quarterly",
            "description": "",
            "isActive": true
        },
        {
            "code": "SEMI_ANNUAL",
            "label": "Semiannual",
            "description": "",
            "isActive": true
        }
    ]

}]);

db.codes.insert([{
    "_id": "billBy",
    "label": "Bill By",
    "description": "Bill By",
    "module": "accounts",
    "values": [
        {
            "code": "HEALTH_PLAN",
            "label": "Health Plan",
            "description": "",
            "isActive": true
        },
        {
            "code": "RMB",
            "label": "RMB",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "billingSystem",
    "label": "Billing System",
    "description": "Billing System",
    "module": "accounts",
    "values": [
        {
            "code": "WGS",
            "label": "Wgs",
            "description": "",
            "isActive": true
        },
        {
            "code": "QUICKBOOKS_ABH_FINANCE",
            "label": "Quickbooks (ABH Finance)",
            "description": "",
            "isActive": true
        },
        {
            "code": "NASCO",
            "label": "Nasco",
            "description": "",
            "isActive": true
        },
        {
            "code": "FACETS",
            "label": "Facets",
            "description": "",
            "isActive": true
        },
        {
            "code": "CS90",
            "label": "Cs90",
            "description": "",
            "isActive": true
        },
        {
            "code": "CHIPS",
            "label": "Chips",
            "description": "",
            "isActive": true
        }
    ]
}]);
db.codes.insert([{
    "_id": "regionalDept",
    "label": "Regional Department",
    "description": "Regional Department",
    "module": "accounts",
    "values": [
        {
            "code": "EAST",
            "label": "East",
            "description": "",
            "isActive": true
        },
        {
            "code": "NORTH",
            "label": "North",
            "description": "",
            "isActive": true
        },
        {
            "code": "SOUTH",
            "label": "South",
            "description": "",
            "isActive": true
        },
        {
            "code": "WEST",
            "label": "West",
            "description": "",
            "isActive": true
        }

    ]
}]);

db.codes.insert([{
    "_id": "fundingType",
    "label": "Funding Type",
    "description": "Funding Type",
    "module": "accounts",
    "values": [
        {
            "code": "ASO",
            "label": "ASO",
            "description": "",
            "isActive": true
        },
        {
            "code": "NON_ASO",
            "label": "Non-ASO",
            "description": "",
            "isActive": true
        }
    ]
}]);
db.codes.insert([{
    "_id": "mbu",
    "description": "Marketing/Medical Business Unit",
    "label": "Marketing/Medical Business Unit",
    "module": "accounts",
    "values": [
        {
            "code": "BHSAZZ",
            "label": "BHSAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "DNSRGA",
            "label": "DNSRGA",
            "description": "",
            "isActive": true
        },
        {
            "code": "DNSRMO",
            "label": "DNSRMO",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRCO",
            "label": "DVSRCO",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRCT",
            "label": "DVSRCT",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRIN",
            "label": "DVSRIN",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRNV",
            "label": "DVSRNV",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRVA",
            "label": "DVSRVA",
            "description": "",
            "isActive": true
        },
        {
            "code": "DVSRWI",
            "label": "DVSRWI",
            "description": "",
            "isActive": true
        },
        {
            "code": "EDCAZZ",
            "label": "EDCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYCAZZ",
            "label": "KYCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYCOZZ",
            "label": "KYCOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYCTZZ",
            "label": "KYCTZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYGAZZ",
            "label": "KYGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYINZZ",
            "label": "KYINZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYKYZZ",
            "label": "KYKYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYMEZZ",
            "label": "KYMEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYMOZZ",
            "label": "KYMOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYNHZZ",
            "label": "KYNHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYNVZZ",
            "label": "KYNVZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYNYZZ",
            "label": "KYNYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYOHZZ",
            "label": "KYOHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYVAZZ",
            "label": "KYVAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "KYWIZZ",
            "label": "KYWIZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "LTCASV",
            "label": "LTCASV",
            "description": "",
            "isActive": true
        },
        {
            "code": "LTCAZZ",
            "label": "LTCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "M1MEZZ",
            "label": "M1MEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "M2MEZZ",
            "label": "M2MEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCAMC",
            "label": "MJCAMC",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCAPL",
            "label": "MJCAPL",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCAZZ",
            "label": "MJCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCOZZ",
            "label": "MJCOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCTZ1",
            "label": "MJCTZ1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJCTZ2",
            "label": "MJCTZ2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJGAZZ",
            "label": "MJGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJING1",
            "label": "MJING1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJING2",
            "label": "MJING2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJKYG1",
            "label": "MJKYG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJKYG2",
            "label": "MJKYG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJMEZZ",
            "label": "MJMEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJMOG1",
            "label": "MJMOG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJMOG2",
            "label": "MJMOG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJMOZZ",
            "label": "MJMOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJNHG1",
            "label": "MJNHG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJNHG2",
            "label": "MJNHG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJNHZZ",
            "label": "MJNHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJNVZZ",
            "label": "MJNVZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJNYZZ",
            "label": "MJNYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJOHG1",
            "label": "MJOHG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJOHG2",
            "label": "MJOHG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJUNEA",
            "label": "MJUNEA",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJVAZZ",
            "label": "MJVAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJWIG1",
            "label": "MJWIG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJWIG2",
            "label": "MJWIG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "MJWIZZ",
            "label": "MJWIZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "MUCAWP",
            "label": "MUCAWP",
            "description": "",
            "isActive": true
        },
        {
            "code": "MUVAMC",
            "label": "MUVAMC",
            "description": "",
            "isActive": true
        },
        {
            "code": "NAH00000",
            "label": "NAH00000",
            "description": "",
            "isActive": true
        },
        {
            "code": "NCGAZZ",
            "label": "NCGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "NLWIZZ",
            "label": "NLWIZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTCOCR",
            "label": "NTCOCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTCTCR",
            "label": "NTCTCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTINCR",
            "label": "NTINCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTKYCR",
            "label": "NTKYCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTNVCR",
            "label": "NTNVCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTNYCR",
            "label": "NTNYCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTOHCR",
            "label": "NTOHCR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NTVACR",
            "label": "NTVACR",
            "description": "",
            "isActive": true
        },
        {
            "code": "NWHLMO",
            "label": "NWHLMO",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBCAZZ",
            "label": "PBCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBCTZZ",
            "label": "PBCTZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBGAZZ",
            "label": "PBGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBINZZ",
            "label": "PBINZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBMEME",
            "label": "PBMEME",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBNHZZ",
            "label": "PBNHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBNYZZ",
            "label": "PBNYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBVAG1",
            "label": "PBVAG1",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBVAG2",
            "label": "PBVAG2",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBVAST",
            "label": "PBVAST",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBVAZZ",
            "label": "PBVAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "PBWIZZ",
            "label": "PBWIZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGCANO",
            "label": "SGCANO",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGCASO",
            "label": "SGCASO",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGCOZZ",
            "label": "SGCOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGCTZZ",
            "label": "SGCTZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGGAZZ",
            "label": "SGGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGINZZ",
            "label": "SGINZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGKYZZ",
            "label": "SGKYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGMEZZ",
            "label": "SGMEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGMOZZ",
            "label": "SGMOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGNHZZ",
            "label": "SGNHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGNVZZ",
            "label": "SGNVZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGNYZZ",
            "label": "SGNYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGOHZZ",
            "label": "SGOHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGUNTX",
            "label": "SGUNTX",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGVA50",
            "label": "SGVA50",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGVAZZ",
            "label": "SGVAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SGWIZZ",
            "label": "SGWIZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPCANC",
            "label": "SPCANC",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPCAZZ",
            "label": "SPCAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPGAZZ",
            "label": "SPGAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPINZZ",
            "label": "SPINZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPKYZZ",
            "label": "SPKYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPMEZZ",
            "label": "SPMEZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPMONC",
            "label": "SPMONC",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPMOZZ",
            "label": "SPMOZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPNVZZ",
            "label": "SPNVZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPNYZZ",
            "label": "SPNYZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPOHZZ",
            "label": "SPOHZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPUNCE",
            "label": "SPUNCE",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPUNSO",
            "label": "SPUNSO",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPVAZZ",
            "label": "SPVAZZ",
            "description": "",
            "isActive": true
        },
        {
            "code": "SPWIZZ",
            "label": "SPWIZZ",
            "description": "",
            "isActive": true
        }, {
            "code": "SRGANA",
            "label": "SRGANA",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "lob",
    "description": "Line Of Business",
    "label": "Line Of Business",
    "module": "accounts",
    "values": [
        {
            "code": "31CA1E3X",
            "label": "31CA1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "654X1E3X",
            "label": "654X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "658X1E3X",
            "label": "658X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "661X1E3X",
            "label": "661X1E3X",
            "description": "",
            "isActive": true
        },

        {
            "code": "662X1E3X",
            "label": "662X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "663X1E3X",
            "label": "663X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "665X1E3X",
            "label": "665X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "666X1E3X",
            "label": "666X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "667X1E3X",
            "label": "667X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "668X1E3X",
            "label": "668X1E3X",
            "description": "",
            "isActive": true
        },
        {
            "code": "NACX1E3X",
            "label": "NACX1E3X",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "groupCode",
    "description": "Group Code",
    "label": "Group Code",
    "module": "accounts",
    "values": [
        {
            "code": "G0200",
            "label": "G0200",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0261",
            "label": "G0261",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0262",
            "label": "G0262",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0264",
            "label": "G0264",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0360",
            "label": "G0360",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0365",
            "label": "G0365",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0385",
            "label": "G0385",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0386",
            "label": "G0386",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0422",
            "label": "G0422",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0423",
            "label": "G0423",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0434",
            "label": "G0434",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0528",
            "label": "G0528",
            "description": "",
            "isActive": true
        },
        {
            "code": "G0529",
            "label": "G0529",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1400",
            "label": "G1400",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1525",
            "label": "G1525",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1605",
            "label": "G1605",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1608",
            "label": "G1608",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1700",
            "label": "G1700",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1728",
            "label": "G1728",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1800",
            "label": "G1800",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1820",
            "label": "G1820",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1822",
            "label": "G1822",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1850",
            "label": "G1850",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1921",
            "label": "G1921",
            "description": "",
            "isActive": true
        },
        {
            "code": "G1922",
            "label": "G1922",
            "description": "",
            "isActive": true
        },
        {
            "code": "G2001",
            "label": "G2001",
            "description": "",
            "isActive": true
        },
        {
            "code": "G9999",
            "label": "G9999",
            "description": "",
            "isActive": true
        }
    ]
}]);