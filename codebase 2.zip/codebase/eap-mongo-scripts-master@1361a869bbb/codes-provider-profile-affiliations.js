
db.codes.remove({
    "_id": {
        $in: ["clinicalOrientation","clients","employerServices","affiliation","wheelChairAccess"]
    }
})



db.codes.insert([
{
    "_id" : "clinicalOrientation",
    "label" : "Clinical Orientation",
    "description" : "Treatment Modalities",
    "module" : "provider",
    "values" : [ 
        {
            "code" : "BEHAVIORAL",
            "label" : "Behavioral",
            "description" : "",
            "sortOrder" : 1,
            "isActive" : true
        }, 
        {
            "code" : "BEHAVIOR_MODIFICATION",
            "label" : "Behavior Modification",
            "description" : "",
            "sortOrder" : 2,
            "isActive" : true
        },
         {
            "code" : "BIOLOGICAL_OR_MEDICAL",
            "label" : "Biological/Medical",
            "description" : "",
            "sortOrder" : 3,
            "isActive" : true
        }, 
        {
            "code" : "BRIEF_SOLUTION_FOCUSED",
            "label" : "Brief Solution Focused",
            "description" : "",
            "sortOrder" : 4,
            "isActive" : true
        },
         {
            "code" : "CHRISTIAN_COUNSELING",
            "label" : "Christian Counseling",
            "description" : "",
            "sortOrder" : 5,
            "isActive" : true
        }, 
        {
            "code" : "COGNITIVE_BEHAVIORAL",
            "label" : "Cognitive Behavioral",
            "description" : "",
            "sortOrder" : 6,
            "isActive" : true
        }, {
            "code" : "DIALECTICAL_BEHAVIORAL_THERAPY",
            "label" : "Dialectical Behavioral Therapy",
            "description" : "",
            "sortOrder" : 7,
            "isActive" : true
        }, 
        {
            "code" : "EMDR",
            "label" : "EMDR",
            "description" : "",
            "sortOrder" : 8,
            "isActive" : true
        },
         {
            "code" : "FAMILY_THERAPY",
            "label" : "Family Therapy",
            "description" : "",
            "sortOrder" : 9,
            "isActive" : true
        }, 
        {
            "code" : "PLAY_THERAPY",
            "label" : "Play Therapy",
            "description" : "",
            "sortOrder" : 10,
            "isActive" : true
        },
         {
            "code" : "PSYCHODYNAMIC",
            "label" : "Psychodynamic",
            "description" : "",
            "sortOrder" : 11,
            "isActive" : true
        }, 
        {
            "code" : "SYSTEMS",
            "label" : "Systems",
            "description" : "",
            "sortOrder" : 12,
            "isActive" : true
        }
    ]
}
]);





db.codes.insert([
{
    "_id" : "clients",
    "label" : "Clients",
    "description" : "Clients",
    "module" : "provider",
    "values" : [ 
        {
            "code" : "CHILDREN",
            "label" : "Children",
            "description" : "",
            "sortOrder" : 1,
            "isActive" : true
        }, 
        {
            "code" : "ADOLESCENT",
            "label" : "Adolescents (Ages 13-17)",
            "description" : "",
            "sortOrder" : 2,
            "isActive" : true
        },
         {
            "code" : "ADULTS",
            "label" : "Adults (Ages 18+)",
            "description" : "",
            "sortOrder" : 3,
            "isActive" : true
        }, 
        {
            "code" : "SENIOR_ADULTS",
            "label" : "Senior Adults (Ages 60+)",
            "description" : "",
            "sortOrder" : 4,
            "isActive" : true
        },
         {
            "code" : "DEAF_OR_HEARING_IMPAIRED",
            "label" : "Deaf/Hearing Impaired",
            "description" : "",
            "sortOrder" : 5,
            "isActive" : true
        }, 
        {
            "code" : "DISABLED_PERSONS",
            "label" : "Disabled Persons",
            "description" : "",
            "sortOrder" : 6,
            "isActive" : true
        }, {
            "code" : "EMERGENCY_RESPONDERS",
            "label" : "Emergency Responders",
            "description" : "",
            "sortOrder" : 7,
            "isActive" : true
        }
    ]
}
])





db.codes.insert([
{
    "_id" : "employerServices",
    "label" : "Employer Services",
    "description" : "Employer Services",
    "module" : "provider",
    "values" : [ 
        {
            "code" : "EAP_COUNSELING",
            "label" : "EAP Counseling",
            "description" : "",
            "sortOrder" : 1,
            "isActive" : true
        }, 
        {
            "code" : "CASE_MANAGEMENT",
            "label" : "Case Management",
            "description" : "",
            "sortOrder" : 2,
            "isActive" : true
        },
         {
            "code" : "FORMAL_OR_MANDATORY_REFERRALS",
            "label" : "Formal/Mandatory Referrals",
            "description" : "",
            "sortOrder" : 3,
            "isActive" : true
        }, 
        {
            "code" : "MANAGEMENT_CONSULTATIONS",
            "label" : "Management Consultations",
            "description" : "",
            "sortOrder" : 4,
            "isActive" : true
        },
         {
            "code" : "CRITICAL_INCIDENT_RESPONSE",
            "label" : "Critical Incident Response",
            "description" : "",
            "sortOrder" : 5,
            "isActive" : true
        }, 
        {
            "code" : "CIR_CONTRACTED",
            "label" : "CIR Contracted",
            "description" : "",
            "sortOrder" : 6,
            "isActive" : true
        }, {
            "code" : "EAP_EMPLOYEE_ORIENTATIONS",
            "label" : "EAP Employee Orientations",
            "description" : "",
            "sortOrder" : 7,
            "isActive" : true
        },
        {
            "code" : "EAP_TRAINING",
            "label" : "EAP Training",
            "description" : "",
            "sortOrder" : 8,
            "isActive" : true
        }, 
        {
            "code" : "CEAP",
            "label" : "CEAP",
            "description" : "",
            "sortOrder" : 9,
            "isActive" : true
        },
         {
            "code" : "SAP",
            "label" : "SAP",
            "description" : "",
            "sortOrder" : 10,
            "isActive" : true
        }, 
        {
            "code" : "EXECUTIVE_COACHING",
            "label" : "Executive Coaching",
            "description" : "",
            "sortOrder" : 11,
            "isActive" : true
        },
         {
            "code" : "ORGANIZATIONAL_DEVELOPMENT",
            "label" : "Organizational Development",
            "description" : "",
            "sortOrder" : 12,
            "isActive" : true
        }, 
        {
            "code" : "WORKPLACE_MEDIATION",
            "label" : "Workplace Meditation",
            "description" : "",
            "sortOrder" : 13,
            "isActive" : true
        }, {
            "code" : "WORKSHOPS_OR_SEMINARS",
            "label" : "Workshops/Seminars",
            "description" : "",
            "sortOrder" : 14,
            "isActive" : true
        }
    ]
}
]);



db.codes.insert([
{
    "_id" : "affiliation",
    "label" : "Affiliation",
    "description" : "Affiliation",
    "module" : "provider",
    "values" : [ 
        {
            "code" : "BC_BS",
            "label" : "BC/BS",
            "description" : "",
            "sortOrder" : 0,
            "isActive" : true
        }, 
        {
            "code" : "CA_BC",
            "label" : "CA-BC",
            "description" : "",
             "sortOrder" : 1,
            "isActive" : true
        },
         {
            "code" : "ALT_NET",
            "label" : "AltNet",
            "description" : "",
             "sortOrder" : 2,
            "isActive" : true
        }, 
        {
            "code" : "AETNA",
            "label" : "Aetna",
            "description" : "",
            "sortOrder" : 3,
            "isActive" : true
        }
    ]
}
]);

db.codes.insert([{
    "_id": "wheelChairAccess",
    "label": "Wheel Chair Access",
    "description": "Wheel Chair Access",
    "module": "provider",
    "values": [{
            "code": "Y",
            "label": "Y",
            "description": "",
            "sortOrder": 0,
            "isActive": true
        },
        {
            "code": "N",
            "label": "N",
            "description": "",
            "sortOrder": 1,
            "isActive": true
        },
    ]
}]);