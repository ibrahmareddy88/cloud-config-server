
/**
 * run script in DB for Complaint Log into codes collection
*/

db.codes.remove({
  "_id": {
    $in: ["complaintAbout", "activityType"]
  }
})

db.codes.insert([{
  "_id": "complaintAbout",
  "label": "Complaint About",
  "description": "Complaint About",
  "module": "accounts",
  "values": [
    {
      "code": "BILLING_FINANCE_CLAIMS",
      "label": "Billing/Finance/Claims",
      "isActive": true
    },
    {
      "code": "BLI_TRAINER",
      "label": "BLI - Trainer",
      "isActive": true
    },
    {
      "code": "BLI_TRAINING_MATERIALS",
      "label": "BLI - Training Materials",
      "isActive": true
    },
    {
      "code": "BROKER_CONSULTANT",
      "label": "Broker/Consultant",
      "isActive": true
    },
    {
      "code": "EAP_NETWORK_ACCESS",
      "label": "EAP Network Access",
      "isActive": true
    },
    {
      "code": "EAP_NETWORK_PROVIDER",
      "label": "EAP Network Provider",
      "isActive": true
    },
    {
      "code": "EMOTIONAL_WELLBEING_RESOURCE",
      "label": "Emotional Wellbeing Resource",
      "isActive": true
    },
    {
      "code": "MARKETING",
      "label": "Marketing",
      "isActive": true
    },
    {
      "code": "OPERATIONS_AFTER_HOURS",
      "label": "Operations - After Hours",
      "isActive": true
    },
    {
      "code": "OPERATIONS_CCR",
      "label": "Operations - CCR",
      "isActive": true
    },
    {
      "code": "OPERATIONS_CONSULTANTS",
      "label": "Operations - Consultants",
      "isActive": true
    },
    {
      "code": "OPERATIONS_OTHER",
      "label": "Operations - Other",
      "isActive": true
    },
    {
      "code": "OPERATIONS_VENDOR_LANGUAGE_LINE",
      "label": "Operations Vendor - Language Line",
      "isActive": true
    },
    {
      "code": "OPERATIONS_VENDOR_R3",
      "label": "Operations Vendor - R3",
      "isActive": true
    },
    {
      "code": "REPORTING",
      "label": "Reporting",
      "isActive": true
    },
    {
      "code": "OTHER_NOTE_REQUIRED",
      "label": "Other (note required)",
      "isActive": true
    },
    {
      "code": "UNDERWRITING",
      "label": "Underwriting",
      "isActive": true
    },
    {
      "code": "WPO_CIR",
      "label": "WPO - CIR",
      "isActive": true
    },
    {
      "code": "WPO_DAILY_LIVING",
      "label": "WPO - Daily Living",
      "isActive": true
    },
    {
      "code": "WPO_DEPENDENT_CARE",
      "label": "WPO - Dependent Care",
      "isActive": true
    },
    {
      "code": "WPO_FINANCIAL",
      "label": "WPO - Financial",
      "isActive": true
    },
    {
      "code": "WPO_INTERNATIONAL_EAP",
      "label": "WPO - International EAP",
      "isActive": true
    },
    {
      "code": "WPO_LEGAL",
      "label": "WPO - Legal",
      "isActive": true
    },
    {
      "code": "WPO_MEMBER_CENTER",
      "label": "WPO - Member Center",
      "isActive": true
    },
    {
      "code": "WPO_OTHER",
      "label": "WPO - Other",
      "isActive": true
    },
    {
      "code": "WPO_PROVIDER_FINDER",
      "label": "WPO - Provider Finder",
      "isActive": true
    },
    {
      "code": "WPO_TOBACCO_CESSATION",
      "label": "WPO - Tobacco Cessation",
      "isActive": true
    },
    {
      "code": "WPO_TRAINER",
      "label": "WPO - Trainer",
      "isActive": true
    },
    {
      "code": "WPO_TRAINING_MATERIALS",
      "label": "WPO - Training Materials",
      "isActive": true
    },
    {
      "code": "WPO_WEBSITE_GENERAL",
      "label": "WPO - Website (general)",
      "isActive": true
    },
  ]
}])

db.codes.insert([{
  "_id": "activityType",
  "label": "Activity Type",
  "description": "Activity Type",
  "module": "accounts",
  "values": [
    {
      "code": "ACCESS_TO_SERVICE",
      "label": "Access to Service",
      "isActive": true
    },
    {
      "code": "OTHER_COMPLAINT_ISSUE",
      "label": "Other Complaint Issue",
      "isActive": true
    },
    {
      "code": "QUALITY_OF_SERVICE",
      "label": "Quality of Service",
      "isActive": true
    },
    {
      "code": "TIMELINESS",
      "label": "Timeliness",
      "isActive": true
    }
  ]
}])
