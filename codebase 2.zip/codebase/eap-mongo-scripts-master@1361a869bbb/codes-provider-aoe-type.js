/**
 * run script in DB for Provider Area of expertise (AOE) types into codes collection
*/

db.codes.remove({ "_id": "providerAOEType" });

db.getCollection('codes').insert([{
"_id": "providerAOEType",
"module": "Provider",
"label": "AOE Types",
"description": "AOE Types",
"values": [
{
"code": "ABUSE_ASSAULT_TRAUMA_SURVIVORS",
"label": "Abuse/Assault/Trauma Survivors",
"description": "",
"isActive": true
},
{
"code": "ADD_ADHD",
"label": "ADD/ADHD",
"description": "",
"isActive": true
},
{
"code": "ADOPTION",
"label": "Adoption",
"description": "",
"isActive": true
},
{
"code": "ANXIETY_AND_PANIC_DISORDERS",
"label": "Anxiety and Panic Disorders",
"description": "",
"isActive": true
},
{
"code": "AUTISM_AUTISM_SPECTRUM_DISORDERS",
"label": "Autism/Autism Spectrum Disorders",
"description": "",
"isActive": true
},
{
"code": "BIPOLAR",
"label": "Bipolar",
"description": "",
"isActive": true
},
{
"code": "CHEMICAL_DEPENDENCY",
"label": "Chemical Dependency",
"description": "",
"isActive": true
},
{
"code": "CHRISTIAN_COUNSELING",
"label": "Christian Counseling",
"description": "",
"isActive": true
},
{
"code": "COMPULSIVE_GAMBLING",
"label": "Compulsive Gambling",
"description": "",
"isActive": true
},
{
"code": "CULTURAL_ETHNIC_ISSUES",
"label": "Cultural/Ethnic Issues",
"description": "",
"isActive": true
},
{
"code": "DEPRESSIVE_DISORDERS",
"label": "Depressive Disorders",
"description": "",
"isActive": true
},
{
"code": "DIVORCE_BLENDED_FAMILY_ISSUES",
"label": "Divorce/Blended Family Issues",
"description": "",
"isActive": true
},
{
"code": "DOMESTIC_VIOLENCE",
"label": "Domestic Violence",
"description": "",
"isActive": true
},
{
"code": "EATING_DISORDER",
"label": "Eating Disorder",
"description": "",
"isActive": true
},
{
"code": "FAMILY_CONFLICT",
"label": "Family Conflict",
"description": "",
"isActive": true
},
{
"code": "GENDER_ISSUES",
"label": "Gender Issues",
"description": "",
"isActive": true
},
{
"code": "GRIEF_END_OF_LIFE",
"label": "Grief/End of Life",
"description": "",
"isActive": true
},
{
"code": "HIV_AIDS_RELATED_ISSUES",
"label": "HIV/AIDS Related Issues",
"description": "",
"isActive": true
},
{
"code": "HOARDING",
"label": "Hoarding",
"description": "",
"isActive": true
},
{
"code": "INFERTILITY",
"label": "Infertility",
"description": "",
"isActive": true
},
{
"code": "LGBTQ_IA",
"label": "LGBTQ-IA",
"description": "",
"isActive": true
},
{
"code": "MEDICAL_CONDITIONS",
"label": "Medical Conditions",
"description": "",
"isActive": true
},
{
"code": "MEN_S_ISSUE",
"label": "Men's Issue",
"description": "",
"isActive": true
},
{
"code": "OBSESSION_COMPULSIVE_DISORDER",
"label": "Obsession Compulsive Disorder",
"description": "",
"isActive": true
},
{
"code": "PAIN_MANAGEMENT",
"label": "Pain Management",
"description": "",
"isActive": true
},
{
"code": "PERSONALITY_DISORDERS",
"label": "Personality Disorders",
"description": "",
"isActive": true
},
{
"code": "POSTPARTUM_ISSUES",
"label": "Postpartum Issues",
"description": "",
"isActive": true
},
{
"code": "PRENATAL_ISSUES",
"label": "Prenatal Issues",
"description": "",
"isActive": true
},
{
"code": "SCHIZOPHRENIA_SCHIZOAFFECTIVE_DISORDER",
"label": "Schizophrenia/Schizoaffective Disorder",
"description": "",
"isActive": true
},
{
"code": "SEXUAL_ABUSE",
"label": "Sexual Abuse",
"description": "",
"isActive": true
},
{
"code": "SEXUAL_ADDICTION",
"label": "Sexual Addiction",
"description": "",
"isActive": true
},
{
"code": "TECHNOLOGY_ABUSE",
"label": "Technology Abuse",
"description": "",
"isActive": true
},
{
"code": "UNION",
"label": "Union",
"description": "",
"isActive": true
},
{
"code": "WOMEN_ISSUES",
"label": "Women Issues",
"description": "",
"isActive": true
}
]
}
]);
