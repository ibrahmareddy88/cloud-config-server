/**
 * run script in DB for Broker Commission into codes collection
*/

db.codes.remove({
    "_id": {
        $in: ["commissionSchedule", "commissionType", "commissionPaidBy"]
    }
})

db.codes.insert([{
    "_id": "commissionSchedule",
    "label": "Commission Schedule",
    "description": "Commission Schedule",
    "module": "accounts",
    "values": [
        {
            "code": "ANNUAL",
            "label": "Annual",
            "description": "",
            "isActive": true
        },
        {
            "code": "MONTHLY",
            "label": "Monthly",
            "description": "",
            "isActive": true
        },
        {
            "code": "QUARTERLY",
            "label": "Quarterly",
            "description": "",
            "isActive": true
        },
        {
            "code": "SEMI_ANNUAL",
            "label": "Semi-Annual",
            "description": "",
            "isActive": true
        }
    ]

}]);
db.codes.insert([{
    "_id": "commissionType",
    "label": "Commission Type",
    "description": "Commission Type",
    "module": "accounts",
    "values": [
        {
            "code": "%_OF_PREMIUM",
            "label": "% of Premium",
            "description": "",
            "isActive": true
        },
        {
            "code": "PEPY",
            "label": "PEPY",
            "description": "",
            "isActive": true
        },
        {
            "code": "PEPM",
            "label": "PEPM",
            "description": "",
            "isActive": true
        }
    ]
}]);

db.codes.insert([{
    "_id": "commissionPaidBy",
    "label": "Commission PaidBy",
    "description": "Commission PaidBy",
    "module": "accounts",
    "values": [
        {
            "code": "BROKER_COMMISSION_TEAM",
            "label": "Broker Commission Team",
            "description": "",
            "isActive": true
        },
        {
            "code": "ANTHEM_HEALTH_PLAN",
            "label": "Anthem Health Plan",
            "description": "",
            "isActive": true
        }
    ]

}]);


