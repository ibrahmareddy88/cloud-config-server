/**
 * run script in DB for Vendor Type into codes collection
*/

db.codes.remove({ "_id": "vendorType" });

db.getCollection('codes').insert([{
    "_id": "vendorType",
    "label": "Vendor Type As",
    "description": "Vendor Type As",
    "module": "accounts",
    "values": [
        {
            "code": "ADOPTION",
            "label": "Adoption",
            "description": "",
            "isActive": true
        },
        {
            "code": "COLLEGE_COACH",
            "label": "College Coach",
            "description": "",
            "isActive": true
        },
        {
            "code": "DISABILITY",
            "label": "Disability",
            "description": "",
            "isActive": true
        },
        {
            "code": "EDUCATION",
            "label": "Education",
            "description": "",
            "isActive": true
        },
        {
            "code": "FINANCIAL",
            "label": "Financial",
            "description": "",
            "isActive": true
        },
        {
            "code": "HEALTHCARE",
            "label": "HealthCare",
            "description": "",
            "isActive": true
        },
        {
            "code": "ID_THEFT_CREDIT_MONITORING",
            "label": "ID Theft/Credit Monitoring",
            "description": "",
            "isActive": true
        },
        {
            "code": "LEGAL",
            "label": "Legal",
            "description": "",
            "isActive": true
        },
        {
            "code": "LOA",
            "label": "LOA",
            "description": "",
            "isActive": true
        },
        {
            "code": "OTHER",
            "label": "Other",
            "description": "",
            "isActive": true
        },
        {
            "code": "SMOKING_CESSATION",
            "label": "Smoking Cessation",
            "description": "",
            "isActive": true
        },
        {
            "code": "WEIGHT_MANAGEMENT",
            "label": "Weight Management",
            "description": "",
            "isActive": true
        },
        {
            "code": "WELLNESS_ADVISOR_COACH",
            "label": "Wellness Advisor/Coach",
            "description": "",
            "isActive": true
        },
        {
            "code": "WORKER'S_COMPENSATION",
            "label": "Worker's Compensation",
            "description": "",
            "isActive": true
        },
        {
            "code": "WORKLIFE",
            "label": "WorkLife",
            "description": "",
            "isActive": true
        },
        {
            "code": "WORKPLACE_SPECIALTY_PROGRAM",
            "label": "Workplace Specialty Program",
            "description": "",
            "isActive": true
        }
    ]
}]);
