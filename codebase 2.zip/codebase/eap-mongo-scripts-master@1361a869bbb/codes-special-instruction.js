/**
 * run script in DB for Special Instructions into codes collection
*/
db.codes.remove({ "_id": "specialInstructions" });

db.codes.insert([{
    "_id": "specialInstructions",
    "label": "Special Instructions",
    "description": "Special Instructions",
    "module": "accounts",
    "values": [
        {
            "code": "1_CUSTOM_GROUP_SERVICES",
            "label": "1- CUSTOM GROUP SERVICES",
            "isActive": true
        },
        {
            "code": "CHEMICAL_DEPENDENCY_PROTOCOLS",
            "label": "Chemical Dependency Protocols",
            "isActive": true
        },
        {
            "code": "CIR_POLICIES_AND_PROCEDURES",
            "label": "CIR Policies & Procedures",
            "isActive": true
        },
        {
            "code": "DISABILITY",
            "label": "Disability",
            "isActive": true
        },
        {
            "code": "DISASTER_RELIEF_PROGRAMS",
            "label": "Disaster Relief Programs",
            "isActive": true
        },
        {
            "code": "HEALTH_SERVICES_ONSITE",
            "label": "Health Services (Onsite)",
            "isActive": true
        },
        {
            "code": "INTERNATIONAL_EAP_SERVICES",
            "label": "International EAP Services",
            "isActive": true
        },
        {
            "code": "MANDATORY_DRUG_TESTING",
            "label": "Mandatory Drug Testing",
            "isActive": true
        },
        {
            "code": "ONSITE_PROVIDER",
            "label": "Onsite Provider",
            "isActive": true
        },
        {
            "code": "ORGANIZATIONAL_CHANGES",
            "label": "Organizational Changes",
            "isActive": true
        },
        {
            "code": "OTHER",
            "label": "Other",
            "isActive": true
        },
        {
            "code": "PROVIDER_REQUIREMENTS",
            "label": "Provider Requirements",
            "isActive": true
        },
        {
            "code": "SAFETY_AND_SECURITY",
            "label": "Safety and Security",
            "isActive": true
        },
        {
            "code": "SEXUAL_HARASSMENT_POLICIES_AND_PROCEDURES",
            "label": "Sexual Harassment Policies & Procedures",
            "isActive": true
        },
        {
            "code": "SMOKING_CESSATION",
            "label": "Smoking Cessation",
            "isActive": true
        },
        {
            "code": "SUPERVISOR_REFERRAL",
            "label": "Supervisor Referral",
            "isActive": true
        },
        {
            "code": "UNION",
            "label": "Union",
            "isActive": true
        },
        {
            "code": "VIOLENCE_WORKPLACE SAFETY",
            "label": "Violence/Workplace Safety",
            "isActive": true
        }
    ]
}])
