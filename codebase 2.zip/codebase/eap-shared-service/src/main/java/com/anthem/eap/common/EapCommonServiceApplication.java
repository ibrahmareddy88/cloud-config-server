package com.anthem.eap.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

@SpringBootApplication
@EnableCaching
@ComponentScan({"com.anthem.eap"})
@EnableReactiveMongoRepositories({"com.anthem.eap.repository", "com.anthem.eap.common.repository"})
public class EapCommonServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(EapCommonServiceApplication.class, args);
  }
}
