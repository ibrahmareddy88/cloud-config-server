package com.anthem.eap.common;

import com.mongodb.reactivestreams.client.MongoDatabase;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.ReactiveMongoOperations;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

/** @author Rajesh Bandarupalli */
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
public abstract class AbstractPersistableUnitTests {

  @Autowired protected ReactiveMongoTemplate mongoTemplate;
  @Autowired protected ReactiveMongoOperations operations;
  @Autowired protected WebTestClient webClient;

  @BeforeEach
  protected void setUp() {
    this.clean();
  }

  @AfterEach
  protected void clean() {
    mongoTemplate.getMongoDatabase().flatMapMany(MongoDatabase::drop).blockLast();
  }
}
